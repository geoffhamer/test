# SwiftMgmt
Swift Management Module (SMM)

This project handles the following two flows

incoming (SWIFTNet -> SAA -> AMOS -> SMM -> HABS)
- [SWIFT_SMM_IN.Q] --> SMM --> [SWIFT_MX_IN.Q]

outgoing (SWIFTNet <- SAA <- SMM <- HABS)
- [SWIFT_SMM_OUT.Q] <-- SMM <-- [SWIFT_MX_OUT.Q]

## Dev Only APIs
To facilitate testing, we have added to this service, a few end-points to facilitate a few tasks.
Those end-points are only available when the spring profile dev or qa is set to be active.
In order to activate a profile, you simply add an environment variable to your running container.
Example:
-Dspring.profiles.active=dev
or
-Dspring.profiles.active=qa

## Local Profile
In anticipation of the move to developing SMM as a pure SpringBoot application, an embedded instance
of Apache ActiveMQ Artemis is deployed if the 'local' spring profile is used.

-Dspring.profiles.active=local

The following configuration parameter is used for two purposes. It is used to configure the endpoint 
for the JMS connection factories and, when using the 'local' profile, it is used to configure the 
embedded Artemis broker. Failure to connect to an Artemis broker instance will result in a continuous
"Failed to create session factory" error.

spring.artemis.broker-url=tcp://localhost:61616