package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.OUTGOING_MESSAGE_TYPE_HEADER_KEY;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import ca.bankofcanada.smm.exception.SMMPersistenceException;
import ca.bankofcanada.smm.msg.SwiftMessageFactory;
import ca.bankofcanada.smm.repositories.SwiftMessageRepository;
import java.io.IOException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.ContextConfiguration;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {OutgoingMessagePostProcessorTest.class, SwiftMessagePersistService.class})
public class OutgoingMessagePostProcessorTest {

  private final SwiftMessageFactory messageFactory = new SwiftMessageFactory();
  @Autowired
  private OutgoingMessagePostProcessor outgoingMessagePostProcessor;
  @Mock
  private SwiftMessagePersistService swiftMessagePersistService;

  @Test
  @DisplayName("routingServiceActivatorTest")
  public void routingServiceActivatorTest() throws IOException, SMMPersistenceException {
    String inputMessage = loadMessage("messages/outgoing/09/saa_pacs009_outgoing.xml");

    Message<?> inMes = MessageBuilder.withPayload(inputMessage).setHeader(
        OUTGOING_MESSAGE_TYPE_HEADER_KEY, "admi.004.001.02").build();
    Message<?> outMes = outgoingMessagePostProcessor.dispatchMessageToDestinationQueue(inMes);
    assertTrue(
        outMes.getPayload().toString().contains("<Saa:UserReference>85501</Saa:UserReference>"));
  }

  @Test
  @DisplayName("SMM failed to persist a swift message")
  public void failedToPersistOutgoingMessage() throws IOException {
    String inputMessage = loadMessage("messages/outgoing/09/saa_pacs009_outgoing.xml");
    Message<?> inMes = MessageBuilder.withPayload(inputMessage).setHeader(
        OUTGOING_MESSAGE_TYPE_HEADER_KEY, "pacs.009.001.08").build();

    assertThrows(SMMPersistenceException.class,
        () -> outgoingMessagePostProcessor.dispatchMessageToDestinationQueue(inMes));
  }

  @Bean
  OutgoingMessagePostProcessor messageRoutingServiceActivator(){
    return new OutgoingMessagePostProcessor(swiftMessagePersistService, messageFactory);
  }

  @Bean
  SwiftMessageRepository swiftMessageRepository(){
    return Mockito.mock(SwiftMessageRepository.class);
  }

}