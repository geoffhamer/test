package ca.bankofcanada.smm.msg;

import static org.junit.jupiter.api.Assertions.*;

import ca.bankofcanada.smm.TestUtils;
import ca.bankofcanada.smm.entity.SwiftMessage;
import java.io.IOException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class SwiftMessageFactoryTest {

  SwiftMessageFactory swiftMessageFactory = new SwiftMessageFactory();

  @Test
  public void testCreateIncomingSwiftMessage() throws IOException {
    // arrange
    String payload = TestUtils.loadMessage("messages/incoming/09/pacs.009.cbpr.valid-and-unsigned.xml");

    // act
    SwiftMessage swiftMessage = swiftMessageFactory.createIncomingMessage(payload);

    // assert
    Assertions.assertEquals(payload, swiftMessage.getMessageContentTxt());
  }

  @Test
  public void testCreateOutgoingSwiftMessage() throws IOException {
    // arrange
    String payload = TestUtils.loadMessage("messages/outgoing/09/signed_pacs009_outgoing.xml");

    // act
    SwiftMessage swiftMessage = swiftMessageFactory.createOutgoingMessage(payload);

    // assert
    Assertions.assertEquals(payload, swiftMessage.getMessageContentTxt());
    Assertions.assertEquals(85501, swiftMessage.getBusinessTransactionFk());
  }

}