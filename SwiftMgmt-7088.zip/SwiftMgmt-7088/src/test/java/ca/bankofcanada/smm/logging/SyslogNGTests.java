package ca.bankofcanada.smm.logging;

import static ca.bankofcanada.smm.TestUtils.clearLog;
import static ca.bankofcanada.smm.TestUtils.getLog;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SyslogNGTests {

  @BeforeEach
  public void clear() throws IOException {
    clearLog();
  }

  @Test
  public void testOutgoingFailureNotification() throws IOException {
    String guid = UUID.randomUUID().toString();

    SysLogNGLog.triggerNotification("1234", guid);

    String log = getLog();

    assertEquals(System.getProperty("logfile.location"), "local");
    assertTrue(log.contains("MessageKey: 1234 Description: " + guid));
  }

  @Test
  public void testOutgoingFailureNotificationUnkown() throws IOException {
    String guid = UUID.randomUUID().toString();

    SysLogNGLog.triggerNotification(null, guid);

    String log = getLog();

    assertEquals(System.getProperty("logfile.location"), "local");
    assertTrue(log.contains("MessageKey: UNKNOWN Description: " + guid));
  }
}
