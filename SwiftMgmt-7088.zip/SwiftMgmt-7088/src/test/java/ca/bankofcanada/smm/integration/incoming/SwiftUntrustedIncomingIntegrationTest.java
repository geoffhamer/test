package ca.bankofcanada.smm.integration.incoming;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class SwiftUntrustedIncomingIntegrationTest extends SwiftIncomingIntegrationBaseTest {

  @Test
  @DisplayName("A valid and signed MX message generates a clean, error-free SMM message")
  public void validAndSigned() throws Exception {

    validateIncomingWithExpectedOutgoing("messages/incoming/08/pacs.008.valid-and-signed.xml",
        "integration/expected/pacs.008.valid-and-signed.SMM-output.xml");
  }

  @Test
  @DisplayName("A valid and unsigned MX message generates an SMM message indicating a signing error")
  public void validAndUnsigned() throws Exception {

    validateIncomingWithExpectedOutgoing("messages/incoming/08/pacs.008.valid-and-unsigned.xml",
        "integration/expected/pacs.008.valid-and-unsigned.untrusted-SMM-output.xml");
  }

  @Test
  @DisplayName("A valid and unsigned pacs.009 CBPR message generates an SMM message indicating a signing error")
  public void pac009CBPRValidAndUnsigned() throws Exception {
    validateIncomingWithExpectedOutgoing(
        "messages/incoming/09/pacs.009.cbpr.valid-and-unsigned.xml",
        "integration/expected/pacs.009.cpbr.valid-and-unsigned.untrusted-SMM-output.xml");
  }

  @Test
  @DisplayName("A valid and unsigned ack message generates an SMM message indicating a signing error")
  public void ackValidAndUnsigned() throws Exception {
    validateIncomingWithExpectedOutgoing("messages/incoming/acknack/saa_pacs009_ack_from_swift.xml",
        "messages/incoming/acknack/saa_pacs009_ack_from_swift.untrusted-SMM-output.xml");
  }

  @Test
  @DisplayName("A valid and unsigned xsys message generates an SMM message indicating a signing error")
  public void xsysValidAndUnsigned() throws Exception {
    validateIncomingWithExpectedOutgoing(
        "messages/incoming/xsys/saa_pacs009_xsys002_from_swift.xml",
        "integration/expected/saa_pacs009_xsys002_from_swift.untrusted-SMM-output.xml");
  }
}
