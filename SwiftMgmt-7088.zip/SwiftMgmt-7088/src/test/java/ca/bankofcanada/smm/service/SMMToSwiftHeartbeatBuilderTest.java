package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.common.CommonConstants.SMM_HEARTBEAT_EVT_DESC;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;

import ca.bankofcanada.smm.config.HeartbeatProperties;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SMMToSwiftHeartbeatBuilderTest {
  @InjectMocks
  SMMToSwiftHeartbeatBuilder heartbeatBuilder;
  @Mock
  HeartbeatProperties heartbeatProperties;

  @Test
  void buildSmmAdmi004Message_buildsSuccessfully() {
    String bic = "BCANCAW0XXX";
    Mockito.when(heartbeatProperties.getBic()).thenReturn(bic);

    String message = heartbeatBuilder.buildSmmAdmi004Message();

    Assertions.assertTrue(message.contains("<BICFI>" + bic + "</BICFI>"));
    Assertions.assertTrue(message.contains("<MessageType>" + MESSAGETYPE_ADMI_004 + "</MessageType>"));
    Assertions.assertTrue(message.contains("<EvtDesc>" + SMM_HEARTBEAT_EVT_DESC + "</EvtDesc>"));
  }
}
