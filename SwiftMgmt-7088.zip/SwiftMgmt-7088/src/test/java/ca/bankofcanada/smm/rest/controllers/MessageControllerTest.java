package ca.bankofcanada.smm.rest.controllers;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static io.restassured.module.mockmvc.RestAssuredMockMvc.given;
import static io.restassured.module.mockmvc.RestAssuredMockMvc.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.repositories.SwiftMessageRepository;
import ca.bankofcanada.smm.util.XMLUtil;
import io.restassured.http.ContentType;
import java.io.IOException;
import java.util.Optional;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.RandomStringUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

class MessageControllerTest extends RestControllerBaseTest {

  @Autowired
  private RestExceptionHandler restExceptionHandler;

  @MockBean
  SwiftMessageRepository swiftMessageRepository;

  @Test
  public void testValidSwiftMessage200() throws IOException {
    SwiftMessage sm = new SwiftMessage();
    String body = "<swift><referenceId>1</referenceId></swift>";
    Long id = new Long(1);
    sm.setMessageContentTxt(body);
    Mockito.when(swiftMessageRepository.getReferenceById(id))
        .thenReturn(sm);
    when().
        get("/api/swift-messages/1").
    then().
        statusCode( HttpServletResponse.SC_OK)
        .contentType("application/xml") //validate content type
        .body("swift.referenceId", Matchers.equalTo("1"));
  }

  @Test
  public void testNotFoundSwiftMessage404() throws IOException {
    SwiftMessage sm = null;
    Long id = new Long(1);
    Mockito.when(swiftMessageRepository.getReferenceById(id))
        .thenReturn(sm);
    when().
        get("/api/messages/swift/1").
        then().
        statusCode( HttpServletResponse.SC_NOT_FOUND);
  }
}