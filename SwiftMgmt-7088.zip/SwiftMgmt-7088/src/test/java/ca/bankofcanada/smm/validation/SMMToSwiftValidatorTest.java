package ca.bankofcanada.smm.validation;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import ca.bankofcanada.smm.config.SmmInitializer;
import ca.bankofcanada.smm.exception.C24ValidationException;
import ca.bankofcanada.smm.exception.MaximumMXPayloadSizeException;
import ca.bankofcanada.smm.exception.UnparsableSMMMessageException;
import ca.bankofcanada.smm.util.XMLUtil;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SMMToSwiftValidator.class, SmmInitializer.class})
class SMMToSwiftValidatorTest {

   @Autowired
   private SMMToSwiftValidator smmToSwiftValidator;

   @Test
   @DisplayName("Test message received from HABS is parsable")
   public void testPACS09OutgoingParsingNoErrors() throws Exception {
      String testFile = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");
      smmToSwiftValidator.validateStructure(testFile);
   }

   @Test
   @DisplayName("Test unparsable message from HABS resulted in UnparsableSMMMessageException")
   public void testPACS09FromHABSWithStructuralErrors() throws Exception {
      String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-unparsable-from-HABS.xml");
      assertThrows(UnparsableSMMMessageException.class, () -> smmToSwiftValidator.validateStructure(testFile));
   }
   
   @Test
   @DisplayName("Test the validation of a PACS09 message that has no errors")
   public void testPACS09OutgoingValidationNoErrors() throws Exception {
      String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-valid.xml");
      smmToSwiftValidator.validate(testFile);
   }

   @Test
   @DisplayName("Test the validation of a PACS09 message with validation errors.")
   public void testPACS09OutgoingValidationWithValidationErrors() throws Exception {
      String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-invalid.xml");
      assertThrows(C24ValidationException.class, () -> smmToSwiftValidator.validate(testFile));
   }

   @Test
   @DisplayName("Test the validation of a PACS09 message with structural errors (no MsgId)")
   public void testPACS09OutgoingValidationWithStructuralErrors() throws Exception {
      String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-invalid-grphdr.xml");
      assertThrows(UnparsableSMMMessageException.class, () -> smmToSwiftValidator.validate(testFile));
   }

   @Test
   @DisplayName("Test the maximum payload size exceeds limit")
   public void testPACS09OutgoingValidationWithMaxSizeExceedsLimit() throws Exception {
      // arrange
      try (MockedStatic<XMLUtil> xmlUtilsMockedStatic = Mockito.mockStatic(XMLUtil.class)) {
         xmlUtilsMockedStatic.when(() -> XMLUtil.writeObjectToOneLine(any())).thenReturn(
             RandomStringUtils.random(40001));
         String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-invalid.xml");
         assertThrows(MaximumMXPayloadSizeException.class,
             () -> smmToSwiftValidator.validate(testFile));
      }
   }

}
