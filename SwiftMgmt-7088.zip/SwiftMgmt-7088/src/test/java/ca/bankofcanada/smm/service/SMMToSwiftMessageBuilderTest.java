package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.bankofcanada.smm.config.SaaConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SMMToSwiftMessageBuilderTest.class})
public class SMMToSwiftMessageBuilderTest {

  private final SaaConfig saaConfig = mock(SaaConfig.class);

  @Autowired
  private SMMToSwiftMessageBuilder smmToSwiftMessageBuilder;

  @Test
  @DisplayName("Create outgoing pacs009 message")
  public void pacs009OutgoingMXMessageCreation() throws Exception {
    // arrange
    when(saaConfig.getNetworkServiceName("paymentsca.lynx.01")).thenReturn("paymentscanada.lynx!p");
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");
    String outMesPayload = smmToSwiftMessageBuilder.createSMMToSwiftMXMessage(inputMessage, "1234");
    assertTrue(outMesPayload.contains("UserReference"));
  }

  @Test
  @DisplayName("Create outgoing pacs009 message with structural error in the Document")
  public void pacs009WithStructuralErrorNotCheckedDuringOutgoingMessageCreation() throws Exception {
    // arrange
    when(saaConfig.getNetworkServiceName("paymentsca.lynx.01")).thenReturn("paymentscanada.lynx!p");
    String inputMessage = loadMessage("messages/outgoing/09/pacs.009-outgoing-invalid-grphdr-from-HABS.xml");
    String outMesPayload = smmToSwiftMessageBuilder.createSMMToSwiftMXMessage(inputMessage, "1234");
    assertTrue(outMesPayload.contains("UserReference"));
  }

  @Test
  @DisplayName("Create outgoing pacs004 message with 8 digits BIC")
  public void pacs004With8DigitsBICHasSAAHeaderWithFullBIC() throws Exception {
    // arrange
    when(saaConfig.getNetworkServiceName("paymentsca.lynx.01")).thenReturn("paymentscanada.lynx!p");
    String inputMessage = loadMessage("messages/outgoing/04/pacs004-outgoing-8-digits-BIC.xml");
    String outMesPayload = smmToSwiftMessageBuilder.createSMMToSwiftMXMessage(inputMessage, "1234");
    assertTrue(outMesPayload.contains("ou=xxx,o=bofmcam2,o=swift"));
  }


  @Bean
  SMMToSwiftMessageBuilder serviceActivator() {
    return new SMMToSwiftMessageBuilder(saaConfig);
  }

}
