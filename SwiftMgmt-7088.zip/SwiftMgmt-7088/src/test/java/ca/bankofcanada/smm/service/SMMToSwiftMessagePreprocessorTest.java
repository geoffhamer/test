package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.OUTGOING_MESSAGE_TYPE_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Objects;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SMMToSwiftMessagePreprocessor.class})
public class SMMToSwiftMessagePreprocessorTest {

  @Autowired
  private SMMToSwiftMessagePreprocessor smmToSwiftMessagePreprocessor;

  @Test
  public void testExtractMessageKeyAndType() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");
    Message<?> inMes = MessageBuilder.withPayload(inputMessage).build();

    // act
    Message<?> outMes = smmToSwiftMessagePreprocessor.extractMessageKeyAndType(inMes);

    // assert
    assertEquals("85501", Objects.toString(outMes.getHeaders().get(SMM_MESSAGE_PK_HEADER_KEY)));
    assertEquals("pacs.009.001.08", Objects.toString(outMes.getHeaders().get(OUTGOING_MESSAGE_TYPE_HEADER_KEY)));
  }

}
