package ca.bankofcanada.smm.security;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import ca.bankofcanada.common.security.apsec.ApsecException;
import ca.bankofcanada.common.security.apsec.xml.EntrustXmlSignatureManager;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.ReflectionUtils;

@ExtendWith(SpringExtension.class)
@TestPropertySource(value = {"classpath:smm-test.properties"})
@ContextConfiguration(classes = {MessageSecurityServiceTest.class})
class MessageSecurityServiceTest {
  private static final String MSG_TO_SIGN = "messages/incoming/09/PACS09-Sample-good.xml";

  @Autowired
  private MessageSecurityService securityService;
  @Value("${smm.xml.signature.parent.qualified.name:Saa:LAU}")
  private String lau;

  @Bean
  MessageSecurityService securityService() {
    return new MessageSecurityService();
  }

  @Test
  void test_verify_swift_mx_message() throws IOException {
    String xmlMessage = loadMessage("messages/incoming/08/pacs.008.signed.xml");
    assertTrue(securityService.verifyXMLMessage(xmlMessage));
  }

  @Test
  void test_sign_swift_mx_message() throws IOException, ApsecException {
    String xmlMessage = loadMessage(MSG_TO_SIGN);

    Pattern LAU_PATTERN = Pattern
        .compile("^(.+)(<" + lau + ".*?>.*</" + lau + ">)(.*?)$", Pattern.DOTALL);

    Matcher matcher = LAU_PATTERN.matcher(xmlMessage);
    if (matcher.find()) {
      String msg = matcher.group(1);
      String msg2 = matcher.group(3);
      xmlMessage = msg + msg2;
    }

    // Make sure that the <Saa:LAU> element has been removed
    assertFalse(xmlMessage.contains("<" + lau + ">"));
    // Sign message
    String signedMessage = securityService.signXMLMessage(xmlMessage);
    // Confirm that the message has been signed
    assertTrue(LAU_PATTERN.matcher(signedMessage).find());
  }

  @Test
  void testFailedToVerifySwiftMXMessageSignature() throws Exception {
    // arrange
    MessageSecurityService messageSecurityService = new MessageSecurityService();
    EntrustXmlSignatureManager xmlSignatureManager = configureEntrustXmlSignatureManager(
        messageSecurityService);
    Mockito.when(xmlSignatureManager.verifyXMLMessage(anyString())).thenThrow(
        new ApsecException("Failed to verify"));

    // assert
    assertThrows(RuntimeException.class,
        () -> messageSecurityService.verifyXMLMessage("test xml message"));
  }

  @Test
  void testFailedToSignSwiftMXMessage() throws Exception {
    // arrange
    MessageSecurityService messageSecurityService = new MessageSecurityService();
    EntrustXmlSignatureManager xmlSignatureManager = configureEntrustXmlSignatureManager(
        messageSecurityService);
    Mockito.when(xmlSignatureManager.signXMLMessage(anyString(), any(), any())).thenThrow(
        new ApsecException("Failed to sign"));

    // assert
    assertThrows(ApsecException.class,
        () -> messageSecurityService.signXMLMessage("test xml message"));
  }

  @Test
  void testFailedSAASignatureCheck() throws Exception {
    // arrange
    MessageSecurityService messageSecurityService = new MessageSecurityService();
    EntrustXmlSignatureManager xmlSignatureManager = configureEntrustXmlSignatureManager(
        messageSecurityService);
    Mockito.when(xmlSignatureManager.verifyXMLMessage(anyString())).thenReturn(false);

    // assert
    assertThrows(ApsecException.class,
        () -> messageSecurityService.saaMessageSignatureCheck("test xml message"));
  }

  @Test
  void testPassSAASignatureCheck() throws Exception {
    // arrange
    MessageSecurityService messageSecurityService = new MessageSecurityService();
    EntrustXmlSignatureManager xmlSignatureManager = configureEntrustXmlSignatureManager(
        messageSecurityService);
    Mockito.when(xmlSignatureManager.verifyXMLMessage(anyString())).thenReturn(true);

    // assert
    assertEquals("test xml message",
        messageSecurityService.saaMessageSignatureCheck("test xml message"));
  }

  private EntrustXmlSignatureManager configureEntrustXmlSignatureManager(
      MessageSecurityService messageSecurityService) throws Exception {
    EntrustXmlSignatureManager xmlSignatureManager = Mockito.mock(EntrustXmlSignatureManager.class);
    Field signatureManagerField = MessageSecurityService.class.getDeclaredField("signatureManager");
    signatureManagerField.setAccessible(true);
    ReflectionUtils.setField(Objects.requireNonNull(signatureManagerField), messageSecurityService,
        xmlSignatureManager);
    return xmlSignatureManager;
  }
}
