package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static ca.bankofcanada.smm.common.CommonConstants.HEARTBEAT_SOURCE_HABS;
import static ca.bankofcanada.smm.common.CommonConstants.HEARTBEAT_SOURCE_SMM;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_XSYS_012;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.bankofcanada.smm.entity.Heartbeat;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Optional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessagingException;

@ExtendWith(MockitoExtension.class)
class SAAHeartbeatServiceTest {

  @Mock
  private JmsQueueService jmsQueueService;

  @Mock
  private HeartbeatService heartbeatService;

  @InjectMocks
  private SAAHeartbeatService saaHeartbeatService;

  @Test
  void submitHeartbeatMessage_throwsIllegalArgumentException_whenNegativeDelayGiven() {
    assertThrows(IllegalArgumentException.class, () -> saaHeartbeatService.submitHeartbeatMessage("", -1));
  }

  @Test
  void submitHeartbeatMessage_submitsMessage_whenNoSmmHeartbeatRecordExists() {
    doNothing().when(jmsQueueService).sendMessage(any(), any(), any());
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.empty());

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.submitHeartbeatMessage("", 0);

    verify(jmsQueueService, times(1)).sendMessage(any(), any(), any());
  }

  @Test
  void submitHeartbeatMessage_submitsMessage_whenSmmHeartbeatRecordExist() {
    doNothing().when(jmsQueueService).sendMessage(any(), any(), any());

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(heartbeat));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.submitHeartbeatMessage("", 0);

    verify(jmsQueueService, times(1)).sendMessage(any(), any(), any());
  }

  /**
   * A two second buffer is applied to account for time desyncs. This test verifies that the
   * buffer is applied correctly.
   */
  @ParameterizedTest
  @ValueSource(ints = {0, 1_000, 2_000})
  void submitHeartbeatMessage_submitsMessage_whenLastHeartbeatMessageTimestampWithinDelayBounds(
      int delayMs) {
    doNothing().when(jmsQueueService).sendMessage(any(), any(), any());

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(heartbeat));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.submitHeartbeatMessage("", delayMs);

    verify(jmsQueueService, times(1)).sendMessage(any(), any(), any());
  }

  @ParameterizedTest
  @ValueSource(ints = {2_999, 60_000})
  @DisplayName("Verify that a heartbeat is not sent if duration between now"
      + " and when the last heartbeat has not exceeded the delay")
  void submitHeartbeat_doesNotSubmitMessage_whenLastHeartbeatMessageTimestampDoesNotExceedDelay(int delayMs) {
    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(heartbeat));

    saaHeartbeatService.submitHeartbeatMessage("", delayMs);

    verify(heartbeatService, never()).save(any(Heartbeat.class));
    verify(jmsQueueService, never()).sendMessage(any(), any(), any());
  }

  @Test
  void submitHeartbeatMessageUnconditionally_submitsMessage_whenNoSmmHeartbeatRecordsExist() {
    doNothing().when(jmsQueueService).sendMessage(any(), any(), any());
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.empty());

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.submitHeartbeatMessageUnconditionally("");

    verify(jmsQueueService, times(1)).sendMessage(any(), any(), any());
    verify(heartbeatService, times(1)).save(any(Heartbeat.class));
  }

  @Test
  void submitHeartbeatMessageUnconditionally_submitsMessage_whenSmmHeartbeatRecordExists() {
    doNothing().when(jmsQueueService).sendMessage(any(), any(), any());

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(heartbeat));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.submitHeartbeatMessageUnconditionally("");

    verify(jmsQueueService, times(1)).sendMessage(any(), any(), any());
    verify(heartbeatService, times(1)).save(any(Heartbeat.class));
  }

  @Test
  void submitHeartbeatMessageUnconditionally_submitsMessage_noDelayConstraints() {
    doNothing().when(jmsQueueService).sendMessage(any(), any(), any());

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    heartbeat.setLastSentTimestamp(Timestamp.from(Instant.now()));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.submitHeartbeatMessageUnconditionally("");
    saaHeartbeatService.submitHeartbeatMessageUnconditionally("");

    verify(heartbeatService, times(2)).save(any());
    verify(jmsQueueService, times(2)).sendMessage(any(), any(), any());
  }

  @Test
  void receiveHeartbeatMessage_throwsIllegalStateException_whenNoExistingHeartbeatRecordExists() {
    Message<?> message = MessageBuilder.withPayload("")
        .setHeader(MESSAGE_TYPE_HEADER_KEY, MESSAGETYPE_ADMI_004)
        .build();

    assertThrows(IllegalStateException.class,
        () -> saaHeartbeatService.receiveHeartbeatMessage(message));
  }

  @Test
  void receiveHeartbeatMessage_updatesExistingHeartbeatRecord() {
    Message<?> message = MessageBuilder.withPayload("")
        .setHeader(MESSAGE_TYPE_HEADER_KEY, MESSAGETYPE_ADMI_004)
        .build();
    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(heartbeat));
    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(heartbeat);

    saaHeartbeatService.receiveHeartbeatMessage(message);

    verify(heartbeatService, times(1)).save(any(Heartbeat.class));
  }

  @Test
  void receiveHeartbeat_throwsIllegalArgumentException_whenNonAdmi004MessageGiven() {
    Message<?> message = MessageBuilder.withPayload("")
        .setHeader(MESSAGE_TYPE_HEADER_KEY, MESSAGETYPE_XSYS_012)
        .build();

    assertThrows(IllegalArgumentException.class,
        () -> saaHeartbeatService.receiveHeartbeatMessage(message));
  }

  @ParameterizedTest
  @ValueSource(strings = {MESSAGETYPE_XSYS_012, ""})
  void detectHeartbeatSource_doesNotAppendMessageHeader_whenMessageIsNotAdmi004(
      String incomingMessageType) throws IOException {
    String inputMessage = loadMessage("messages/incoming/xsys/saa_pacs008_xsys012_from_swift.xml");
    Message<?> message = MessageBuilder.withPayload(inputMessage)
        .setHeader(MESSAGE_TYPE_HEADER_KEY, incomingMessageType)
        .build();

    Message<?> result = saaHeartbeatService.detectHeartbeatSource(message);

    assertFalse(
        result.getHeaders().containsKey(SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY));
  }

  @Test
  void detectHeartbeatSource_doesNotAppendMessageHeader_whenIncomingMessageTypeHeaderMissing()
      throws IOException {
    String inputMessage = loadMessage("messages/incoming/admi/saa_admi_004_smm_heartbeat.xml");
    Message<?> message = MessageBuilder.withPayload(inputMessage)
        .build();

    Message<?> result = saaHeartbeatService.detectHeartbeatSource(message);

    assertFalse(
        result.getHeaders().containsKey(SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY));
  }

  @Test
  void detectHeartbeatSource_appendsMessageHeader_whenMessageIsSmmSubmittedAdmi004()
      throws IOException {
    String inputMessage = loadMessage("messages/incoming/admi/saa_admi_004_smm_heartbeat.xml");
    Message<?> message = MessageBuilder.withPayload(inputMessage)
        .setHeader(MESSAGE_TYPE_HEADER_KEY, MESSAGETYPE_ADMI_004)
        .build();

    Message<?> result = saaHeartbeatService.detectHeartbeatSource(message);

    assertTrue(
        result.getHeaders().containsKey(SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY));
    assertEquals(HEARTBEAT_SOURCE_SMM,
        result.getHeaders().get(SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY));
  }

  @Test
  void detectHeartbeatSource_appendsMessageHeader_whenMessageIsHabsSubmittedAdmi004()
      throws IOException {
    String inputMessage = loadMessage("messages/incoming/admi/saa_admi_004_bypass_persistence.xml");
    Message<?> message = MessageBuilder.withPayload(inputMessage)
        .setHeader(MESSAGE_TYPE_HEADER_KEY, MESSAGETYPE_ADMI_004)
        .build();

    Message<?> result = saaHeartbeatService.detectHeartbeatSource(message);

    assertTrue(
        result.getHeaders().containsKey(SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY));
    assertEquals(HEARTBEAT_SOURCE_HABS,
        result.getHeaders().get(SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY));
  }

  @Test
  void detectHeartbeatSource_throws_whenInvalidAdmi004MessageEncountered() {
    Message<?> message = MessageBuilder.withPayload("asdf")
        .setHeader(MESSAGE_TYPE_HEADER_KEY, MESSAGETYPE_ADMI_004)
        .build();

    assertThrows(MessagingException.class,
        () -> saaHeartbeatService.detectHeartbeatSource(message));
  }
}
