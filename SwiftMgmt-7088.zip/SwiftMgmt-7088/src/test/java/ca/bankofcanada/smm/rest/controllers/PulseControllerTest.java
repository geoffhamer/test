package ca.bankofcanada.smm.rest.controllers;

import org.junit.jupiter.api.Test;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.when;
import static org.hamcrest.Matchers.equalTo;

class PulseControllerTest extends RestControllerBaseTest {

  @Test
  public void pulseCheck() {
    when().
        get("/api/pulse").
    then().
        statusCode(200).
        body(equalTo("Hello from SMM!"));
  }
}