package ca.bankofcanada.smm.rest.controllers;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

import ca.bankofcanada.smm.service.SAAHeartbeatService;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.util.UriComponentsBuilder;



class HeartbeatControllerTest extends RestControllerBaseTest {

  @MockBean
  private SAAHeartbeatService saaHeartbeatService;

  @Test
  void testValidRequestResponseBody() {
    String uri = UriComponentsBuilder.fromPath("/api/heartbeats/saa/messages").toUriString();

    doNothing().when(saaHeartbeatService).submitHeartbeatMessageUnconditionally(any());

    String responseBody = when().post(uri).then().extract().body().asString();

    Assertions.assertEquals("Heartbeat message has been sent", responseBody);
  }

  @Test
  void testValidRequest_StatusCode202() {
    String uri = UriComponentsBuilder.fromPath("/api/heartbeats/saa/messages").toUriString();

    doNothing().when(saaHeartbeatService).submitHeartbeatMessageUnconditionally(any());

    when().post(uri).then().statusCode(HttpServletResponse.SC_ACCEPTED);
  }

  @Test
  void testValidRequestButHeartbeatServiceFails_StatusCode500() {
    String uri = UriComponentsBuilder.fromPath("/api/heartbeats/saa/messages").toUriString();

    doThrow(new RuntimeException("test")).when(saaHeartbeatService).
        submitHeartbeatMessageUnconditionally(any());

    when().post(uri).then().statusCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
  }
}