package ca.bankofcanada.smm;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Enumeration;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.RollingFileAppender;
import org.springframework.util.ResourceUtils;

public final class TestUtils {

  private TestUtils(){}

  private static final Logger logger = Logger.getLogger("sysLogNG");

  public static String loadMessage(String filename) throws IOException {
    File inputFile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + filename);
    return FileUtils.readFileToString(inputFile, StandardCharsets.UTF_8);
  }

  public static String getLog() throws IOException {
    Enumeration<?> appenders = logger.getAllAppenders();
    RollingFileAppender appender = (RollingFileAppender) appenders.nextElement();
    Path path = Paths.get(appender.getFile());
    return new String(Files.readAllBytes(path));
  }

  public static String getRootLog() throws IOException {
    RollingFileAppender appender = (RollingFileAppender) Logger.getRootLogger().getAppender(
        "rollingLog");
    Path path = Paths.get(appender.getFile());
    return new String(Files.readAllBytes(path));
  }

  public static void clearRootLog() throws IOException {
    RollingFileAppender appender = (RollingFileAppender) Logger.getRootLogger().getAppender(
        "rollingLog");
    Path path = Paths.get(appender.getFile());
    Files.write(path, new byte[0]);
  }

  public static void clearLog() throws IOException {
    Enumeration<?> appenders = logger.getAllAppenders();
    RollingFileAppender appender = (RollingFileAppender) appenders.nextElement();
    Path path = Paths.get(appender.getFile());
    Files.write(path, new byte[0]);
  }
}
