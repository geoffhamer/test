package ca.bankofcanada.smm.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Locale;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.context.NoSuchMessageException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SmmMessageResource.class})
public class SmmMessageResourceTest {

  @Test
  @DisplayName("Test that the Smm message resource successfully loads the resource bundle")
  public void testResourceBundleLoaded() {

    SmmMessageResource messageResource = SmmMessageResource.getInstance();
    assertNotNull(messageResource.getBilingualMessageSource());
  }


  @Test
  @DisplayName("Test that a sample message can be accessed")
  public void testReturnOfBundleValue() {

    SmmMessageResource messageResource = SmmMessageResource.getInstance();
    String sampleMessage = messageResource.getBilingualMessageSource().getMessage("test.sample", null, Locale.getDefault());
    assertEquals("The bundle has been loaded successfully", sampleMessage);
  }


  @Test
  @DisplayName("Test NoSuchMessageException is thrown when key is not valid")
  public void testNoSuchMessageExceptionThrownWhenKeyInvalid() {

    SmmMessageResource messageResource = SmmMessageResource.getInstance();
    assertThrows(NoSuchMessageException.class, () ->
      messageResource.getBilingualMessageSource().getMessage("non-existent.test.sample", null, Locale.getDefault())
    );

  }

}
