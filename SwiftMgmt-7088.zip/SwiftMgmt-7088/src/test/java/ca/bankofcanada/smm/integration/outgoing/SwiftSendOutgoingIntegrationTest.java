package ca.bankofcanada.smm.integration.outgoing;

import static ca.bankofcanada.smm.TestUtils.clearLog;
import static ca.bankofcanada.smm.TestUtils.getLog;
import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import ca.bankofcanada.common.security.apsec.ApsecException;
import ca.bankofcanada.common.security.apsec.xml.EntrustXmlSignatureManager;
import ca.bankofcanada.smm.security.MessageSecurityService;
import ca.bankofcanada.smm.util.XMLUtil;
import java.io.IOException;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

@TestPropertySource(properties = { "smm.saa.paymentscalynx.service=paymentscanada.lynx"})
public final class SwiftSendOutgoingIntegrationTest extends SwiftOutgoingIntegrationBaseTest {

  @Autowired
  private MessageSecurityService messageSecurityService;

  @BeforeEach
  public void clear() throws IOException {
    clearLog();
  }

  @Test
  @DisplayName("A valid HABS message is signed and sent to SAA.")
  public void singAndSendOutgoingMessage() throws IOException {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");
    String expectedOutputMessage = loadMessage("messages/outgoing/09/signed_pacs009_outgoing.xml");

    // act
    String signedMsg = sendMessage(inputMessage);

    // assert
    assertNotNull(signedMsg);
    signedMsg = signedMsg.substring(("<?xml version=\"1.0\" encoding=\"UTF-8\"?>").length()); // cleanup extra xml declaration
    assertEquals(normalizeEOLs(expectedOutputMessage), normalizeEOLs(signedMsg));
  }

  @Test
  @DisplayName("A valid HABS pacs.004 message with 8 digits BIC is signed and sent to SAA.")
  public void singAndSendPacs004WithShortBICMessage() throws IOException {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/04/pacs004-outgoing-8-digits-BIC.xml");
    String expectedOutputMessage = loadMessage("messages/outgoing/04/signed_pacs004-outgoing-8-digits-BIC.xml");

    // act
    String signedMsg = sendMessage(inputMessage);

    // assert
    signedMsg = signedMsg.substring(("<?xml version=\"1.0\" encoding=\"UTF-8\"?>").length()); // cleanup extra xml declaration
    assertEquals(normalizeEOLs(expectedOutputMessage), normalizeEOLs(signedMsg));
  }

  @Test
  @DisplayName("The NetworkService in SAA header is set to config property smm.saa.paymentscalynx.service")
  public void verifySaaServiceSetToConfigurationProperty() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");

    // act
    String signedMsg = sendMessage(inputMessage);

    // assert
    assertTrue(signedMsg.contains("<Saa:Service>paymentscanada.lynx</Saa:Service>"));
  }

  @Test
  @DisplayName("The outgoing message failed maximum payload size check")
  public void maximumPayloadSizeCheckFailed() throws Exception {
    // arrange
    MockedStatic<XMLUtil> xmlUtilsMockedStatic = Mockito.mockStatic(XMLUtil.class);
    xmlUtilsMockedStatic.when(() -> XMLUtil.writeObjectToOneLine(any()))
        .thenReturn(RandomStringUtils.random(40001));
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing_invalid_BizSvc.xml");

    // act
    sendMessage(inputMessage);
    xmlUtilsMockedStatic.close();

    // assert
    assertTrue(getLog().contains("The following process failed: Validation of an outgoing message maximum payload size limit of 80,000 bytes"));
  }

  @Test
  @DisplayName("SMM failed to construct the outgoing message")
  public void failedToConstructOutgoingSAADataPDU() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing_invalid_BIC.xml");

    // act
    sendMessage(inputMessage);

    // assert
    assertTrue(getLog().contains("The following process failed: SMM is unable to parse the outgoing message"));
  }

  @Test
  @DisplayName("The outgoing message failed C24 structural check")
  public void c24StructuralCheckFailedBeforeSigning() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing_invalid_grphdr.xml");

    // act
    sendMessage(inputMessage);

    // assert
    assertTrue(getLog().contains("The following process failed: C24 structural validation of an outgoing message"));
  }

  @Test
  @DisplayName("The outgoing message failed C24 rules validation")
  public void c24ValidationFailedBeforeSigning() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing_invalid_BizSvc.xml");

    // act
    sendMessage(inputMessage);

    // assert
    assertTrue(getLog().contains("The following process failed: C24 rules validation of an outgoing message content"));
  }

  @Test
  @DisplayName("SMM failed to sign an outgoing message")
  public void failedToSignAnOutgoingMessage() throws IOException, ApsecException {
    // arrange
    final EntrustXmlSignatureManager xmlSignatureManager = Mockito.mock(EntrustXmlSignatureManager.class);
    final Object realXmlSignatureManager = ReflectionTestUtils.getField(messageSecurityService, "signatureManager");
    ReflectionTestUtils.setField(messageSecurityService, "signatureManager", xmlSignatureManager);
    Mockito.when(xmlSignatureManager.signXMLMessage(anyString(), anyString(), anyString())).thenThrow(
        new ApsecException("signing exception"));
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");

    // act
    sendMessage(inputMessage);
    ReflectionTestUtils.setField(messageSecurityService, "signatureManager", realXmlSignatureManager);

    // assert
    assertTrue(getLog().contains("The following process failed: Sign an outgoing message"));
  }

  @Test
  @DisplayName("The uncaught exception will trigger a generic SysLogNG entry")
  public void uncaughtExceptionTriggerGenericSysLogNGEntry() throws Exception {
    // arrange
    MockedStatic<XMLUtil> xmlUtilsMockedStatic = Mockito.mockStatic(XMLUtil.class);
    xmlUtilsMockedStatic.when(() -> XMLUtil.extractXMLTagText(anyString(), anyString()))
        .thenThrow(new RuntimeException("XMLUtil failed to extract tag"));
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");

    // act
    sendMessage(inputMessage);
    xmlUtilsMockedStatic.close();

    // assert
    assertTrue(getLog().contains("has encountered an unknown error"));
  }

  @Test
  @DisplayName("The outgoing admi message doesn't contain BizSvc")
  public void verifyOutgoingHeartbeatAdmiMessage() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/outgoing/admi/admi004_outgoing.xml");

    // act
    String signedMsg = sendMessage(inputMessage);

    // assert
    assertFalse(signedMsg.contains("<BizSvc>trgt.t2.rtgs.01</BizSvc>"));
  }
}
