package ca.bankofcanada.smm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import ca.bankofcanada.smm.config.HeartbeatProperties;
import ca.bankofcanada.smm.entity.Heartbeat;
import ca.bankofcanada.smm.logging.SysLogNGLog;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class SAAHealthIndicatorTest {
  private static final long MAX_HEALTHY_TIME_DIFFERENCE_MS = 125_000L;

  @Mock
  private HeartbeatService heartbeatService;

  @Mock
  private HeartbeatProperties heartbeatProperties;

  @InjectMocks
  private SAAHealthIndicator saaHealthIndicator;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(saaHealthIndicator, "maxHealthyTimeDifferenceMs",
        MAX_HEALTHY_TIME_DIFFERENCE_MS);
  }

  @Test
  void health_hasStatusOfUnknown_whenNoHeartbeatRecordFound() {
    when(heartbeatService.getHeartbeat()).thenReturn(Optional.empty());

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UNKNOWN, health.getStatus());
    Map<String, Object> details = health.getDetails();

    assertTrue(details.containsKey("message"));
    assertFalse(details.containsKey("heartbeatLastSent"));
    assertFalse(details.containsKey("heartbeatLastReceived"));

    assertEquals("SAA may NOT be available. No successful connectivity verification on record as of yet", details.get("message"));
  }

  @Test
  void health_hasStatusOfUnknown_whenHeartbeatRecordFoundButMissingLastSentTimeStamp() {
    Heartbeat smmHeartbeat = new Heartbeat();
    Timestamp lastReceivedAndSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
    smmHeartbeat.setLastReceivedTimestamp(lastReceivedAndSentTimestamp);
    // Skipping lastSentTimestamp initialization

    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UNKNOWN, health.getStatus());
    Map<String, Object> details = health.getDetails();

    assertTrue(details.containsKey("message"));
    assertFalse(details.containsKey("heartbeatLastSent"));
    assertFalse(details.containsKey("heartbeatLastReceived"));

    assertEquals("SAA may NOT be available. No successful connectivity verification on record as of yet",
        details.get("message"));
  }

  @Test
  void health_hasStatusOfUnknown_whenHeartbeatRecordFoundButMissingLastReceivedTimeStamp() {
    Heartbeat smmHeartbeat = new Heartbeat();
    Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
    smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
    // Skipping lastReceivedTimestamp initialization

    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UNKNOWN, health.getStatus());
    Map<String, Object> details = health.getDetails();

    assertTrue(details.containsKey("message"));
    assertFalse(details.containsKey("heartbeatLastSent"));
    assertFalse(details.containsKey("heartbeatLastReceived"));

    assertEquals("SAA may NOT be available. No successful connectivity verification on record as of yet",
        details.get("message"));
  }

  @Test
  void health_hasStatusOfUp_whenNoTimeDifference() {
    Heartbeat smmHeartbeat = new Heartbeat();
    Timestamp lastReceivedAndSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
    smmHeartbeat.setLastSentTimestamp(lastReceivedAndSentTimestamp);
    smmHeartbeat.setLastReceivedTimestamp(lastReceivedAndSentTimestamp);

    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UP, health.getStatus());
    testHealthDetails(health, lastReceivedAndSentTimestamp, lastReceivedAndSentTimestamp,
        "SAA is available.");
  }

  @Test
  void health_hasStatusOfUp_whenAtMaxHealthyTimeDifference() {
    Heartbeat smmHeartbeat = new Heartbeat();
    Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
    Timestamp lastReceivedTimestamp = getRelativeTimestamp(lastSentTimestamp, MAX_HEALTHY_TIME_DIFFERENCE_MS);
    smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
    smmHeartbeat.setLastReceivedTimestamp(lastReceivedTimestamp);

    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UP, health.getStatus());
    testHealthDetails(health, lastSentTimestamp, lastReceivedTimestamp,
        "SAA is available.");
  }

  @Test
  void health_hasStatusOfUp_whenInMaxHealthyTimeDifferenceRange() {
    Heartbeat smmHeartbeat = new Heartbeat();
    Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
    Timestamp lastReceivedTimestamp = getRelativeTimestamp(lastSentTimestamp,
        MAX_HEALTHY_TIME_DIFFERENCE_MS - 100L);
    smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
    smmHeartbeat.setLastReceivedTimestamp(lastReceivedTimestamp);

    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UP, health.getStatus());
    testHealthDetails(health, lastSentTimestamp, lastReceivedTimestamp,
        "SAA is available.");
  }

  @Test
  void health_hasStatusOfUp_whenHealthyTimeDifferenceWithLastReceivedEarlierThanLastSent() {
    Heartbeat smmHeartbeat = new Heartbeat();
    Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
    Timestamp lastReceivedTimestamp = getRelativeTimestamp(lastSentTimestamp, -MAX_HEALTHY_TIME_DIFFERENCE_MS);
    smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
    smmHeartbeat.setLastReceivedTimestamp(lastReceivedTimestamp);

    when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

    Health health = saaHealthIndicator.health();

    assertEquals(Status.UP, health.getStatus());
    testHealthDetails(health, lastSentTimestamp, lastReceivedTimestamp,
        "SAA is available.");
  }

  @Test
  void health_hasStatusOfUnknown_whenTimeStaledRecently_openBusinessDay() {
    try (MockedStatic<SysLogNGLog> mockedStatic = mockStatic(SysLogNGLog.class)) {
      Heartbeat smmHeartbeat = new Heartbeat();
      Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
      Timestamp lastReceivedTimestamp = getRelativeTimestamp(lastSentTimestamp,
          MAX_HEALTHY_TIME_DIFFERENCE_MS + 100L);
      smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
      smmHeartbeat.setLastReceivedTimestamp(lastReceivedTimestamp);

      when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

      Health health = saaHealthIndicator.health();

      mockedStatic.verify(() -> SysLogNGLog.triggerNotificationWithResourceKey(any(), any()), times(1));

      assertEquals(Status.UNKNOWN, health.getStatus());
      testHealthDetails(health, lastSentTimestamp, lastReceivedTimestamp,
          "SAA may NOT be available.");
    }
  }
  @Test
  void health_hasStatusOfUnknown_whenTimeStaledLongAgo_openBusinessDay() {
    try (MockedStatic<SysLogNGLog> mockedStatic = mockStatic(SysLogNGLog.class)) {
      Heartbeat smmHeartbeat = new Heartbeat();
      Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
      Timestamp lastReceivedTimestamp = getRelativeTimestamp(lastSentTimestamp,
          MAX_HEALTHY_TIME_DIFFERENCE_MS + 10_000_000_000L);
      smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
      smmHeartbeat.setLastReceivedTimestamp(lastReceivedTimestamp);

      when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

      Health health = saaHealthIndicator.health();

      mockedStatic.verify(() -> SysLogNGLog.triggerNotificationWithResourceKey(any(), any()), times(1));

      assertEquals(Status.UNKNOWN, health.getStatus());
      testHealthDetails(health, lastSentTimestamp, lastReceivedTimestamp,
          "SAA may NOT be available.");
    }
  }

  @Test
  void health_hasStatusOfUnknown_whenTimeStaledWithLastReceivedEarlierThanLastSent_openBusinessDay() {
    try (MockedStatic<SysLogNGLog> mockedStatic = mockStatic(SysLogNGLog.class)) {
      Heartbeat smmHeartbeat = new Heartbeat();
      Timestamp lastSentTimestamp = Timestamp.valueOf("2020-10-10 10:00:00");
      Timestamp lastReceivedTimestamp = getRelativeTimestamp(lastSentTimestamp,
          -(MAX_HEALTHY_TIME_DIFFERENCE_MS + 100L));
      smmHeartbeat.setLastSentTimestamp(lastSentTimestamp);
      smmHeartbeat.setLastReceivedTimestamp(lastReceivedTimestamp);

      when(heartbeatService.getHeartbeat()).thenReturn(Optional.of(smmHeartbeat));

      Health health = saaHealthIndicator.health();

      mockedStatic.verify(() -> SysLogNGLog.triggerNotificationWithResourceKey(any(), any()), times(1));

      assertEquals(Status.UNKNOWN, health.getStatus());
      testHealthDetails(health, lastSentTimestamp, lastReceivedTimestamp,
          "SAA may NOT be available.");
    }
  }

  @Test
  void health_hasStatusOfDown_whenExceptionThrown() {
    when(heartbeatService.getHeartbeat()).thenThrow(new RuntimeException());

    Health health = saaHealthIndicator.health();

    assertEquals(Status.DOWN, health.getStatus());
  }

  private void testHealthDetails(Health health, Timestamp lastSentTimestamp,
      Timestamp lastReceivedTimestamp, String messageSubstring) {
    Map<String, Object> details = health.getDetails();
    assertTrue(details.containsKey("message"));
    assertTrue(details.containsKey("heartbeatLastSent"));
    assertTrue(details.containsKey("heartbeatLastReceived"));

    String message = (String) details.get("message");
    String heartbeatLastSent = (String) details.get("heartbeatLastSent");
    String heartbeatLastReceived = (String) details.get("heartbeatLastReceived");

    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssz");

    assertEquals(messageSubstring
        + " Last successful connectivity verification was done on: "
        + simpleDateFormat.format(lastReceivedTimestamp), message);
    assertEquals(simpleDateFormat.format(lastSentTimestamp), heartbeatLastSent);
    assertEquals(simpleDateFormat.format(lastReceivedTimestamp), heartbeatLastReceived);

  }

  private Timestamp getRelativeTimestamp(Timestamp originalTimestamp, long relativeTimeDifferenceMs) {
    Date originalDate = new Date(originalTimestamp.getTime());
    long newTimeMillis = originalDate.getTime() + relativeTimeDifferenceMs;
    return new Timestamp(newTimeMillis);
  }
}
