package ca.bankofcanada.smm.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import swift.saa.xsd.saa.x2.x0.SwAny;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {XMLUtilTest.class})
public class XMLUtilTest {

  private static final String strXML = "<Saa:InterfaceInfo>\n" +
                  "        <Saa:UserReference>85501</Saa:UserReference>\n" +
                  "</Saa:InterfaceInfo>";

  @Test
  @DisplayName("Extracted XML tag matched with tagName")
  public void extractXMLTagText() {
    XMLUtil.extractXMLTagText(strXML, "Saa:UserReference").ifPresent(s -> assertEquals("85501", s));
  }

  @Test
  @DisplayName("Extracted XML tag not matched with tagName")
  public void extractXMLTagTextNotMatched() {
    assertFalse(XMLUtil.extractXMLTagText("test", "Saa:UserReference").isPresent());
  }

  @Test
  @DisplayName("ComplexDataObject is converted to one liner string")
  public void convertToOneLinerString() throws Exception {
    SwAny swAny = new SwAny();
    swAny.addElement("any", "AppHdr");
    swAny.addElement("any", "Document");
    String oneLinerStr = XMLUtil.writeObjectToOneLine(swAny);
    assertFalse(oneLinerStr.contains("\n"));
  }

}
