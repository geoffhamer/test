package ca.bankofcanada.smm.msg;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ValidationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class OutgoingSAAHeaderTest {

  @Test
  public void validPACS009OutgoingSAAHeader() throws ValidationException {
    OutgoingSAAHeader outgoingSAAHeader = OutgoingSAAHeader.builder() //
        .withMessageIdentifier("pacs.009.001.08") //
        .withSender("BCANCAW2XXX") //
        .withReceiver("BCANCAW2XXX") //
        .withBTPKFromHABS("123456789")
        .withNetworkInfo("paymentscanada.lynx!p") //
        .withRequestSubtypeInfo("paymentsca.lynx.cov.01") //
        .build(); //
    C24.validate(outgoingSAAHeader);
  }

  @Test
  public void validPACS009ShortBICOutgoingSAAHeader() throws ValidationException {
    OutgoingSAAHeader outgoingSAAHeader = OutgoingSAAHeader.builder() //
        .withMessageIdentifier("pacs.009.001.08") //
        .withSender("BCANCAW2") //
        .withReceiver("BCANCAW2") //
        .withBTPKFromHABS("123456789")
        .withNetworkInfo("paymentscanada.lynx!p") //
        .withRequestSubtypeInfo("paymentsca.lynx.cov.01") //
        .build(); //
    C24.validate(outgoingSAAHeader);
  }
  
  @Test
  public void validADMI001OutgoingSAAHeader() throws ValidationException {
    OutgoingSAAHeader outgoingSAAHeader = AdmiOutgoingSAAHeader.builder() //
        .withMessageIdentifier("admi.004.001.02") //
        .withSender("BCANCAW2XXX") //
        .withReceiver("BCANCAW2XXX") //
        .withBTPKFromHABS("HBT123456789")
        .withNetworkInfo("swift.tst2.iast!p") //
        .withRequestSubtypeInfo("") //
        .build(); //
    C24.validate(outgoingSAAHeader);
  }

  @Test
  public void invalidSenderInOutgoingSAAHeader() {
    IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
      AdmiOutgoingSAAHeader.builder() //
          .withMessageIdentifier("pacs.004.001.09") //
          .withSender("BOFMCAM") //
          .withReceiver("BCANCAW2XXX") //
          .withBTPKFromHABS("123456789") //
          .withNetworkInfo("paymentsca.lynx.02!p") //
          .withRequestSubtypeInfo("paymentsca.lynx.cov.01") //
          .build(); //
      });
    Assertions.assertEquals("Sender BIC must be 8 digits or 11 digits.", exception.getMessage());
  }

  @Test
  public void invalidReceiverInOutgoingSAAHeader() {
    IllegalArgumentException exception = Assertions.assertThrows(IllegalArgumentException.class, () -> {
      AdmiOutgoingSAAHeader.builder() //
          .withMessageIdentifier("pacs.004.001.09") //
          .withSender("BCANCAW2XXX") //
          .withReceiver("BOFMCAM") //
          .withBTPKFromHABS("123456789") //
          .withNetworkInfo("paymentsca.lynx.02!p") //
          .withRequestSubtypeInfo("paymentsca.lynx.cov.01") //
          .build(); //
    } );
    Assertions.assertEquals("Receiver BIC must be 8 digits or 11 digits.", exception.getMessage());
  }


}
