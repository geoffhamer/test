package ca.bankofcanada.smm.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

public class SaaConfigTest {

  private static final SaaConfig saaConfig = new SaaConfig();

  private static final String DEFAULT_LYNX_SAA_SERVICE = "paymentscanada.lynx!p";
  private static final String DEFAULT_CBPRPLUS_SAA_SERVICE = "swift.finplus!pf";
  private static final String DEFAULT_HEARTBEAT_SAA_SERVICE = "swift.tst2.iast!p";


  @BeforeAll
  static void setup() {
    ReflectionTestUtils.setField(saaConfig, "paymentscaLynxService", DEFAULT_LYNX_SAA_SERVICE);
    ReflectionTestUtils.setField(saaConfig, "cbprplusService", DEFAULT_CBPRPLUS_SAA_SERVICE);
    ReflectionTestUtils.setField(saaConfig, "admiService", DEFAULT_HEARTBEAT_SAA_SERVICE);
    ReflectionTestUtils.invokeMethod(saaConfig, "init");
  }

  @Test
  void testBusinessServicePaymentscaLynx02() {
    String networkServiceName = saaConfig.getNetworkServiceName(SaaConfig.PAYMENTSCA_LYNX_02);
    assertEquals(networkServiceName, DEFAULT_LYNX_SAA_SERVICE);
  }

  @Test
  void testBusinessServicePaymentscaLynxCOV02() {
    String networkServiceName = saaConfig.getNetworkServiceName(SaaConfig.PAYMENTSCA_LYNX_COV_02);
    assertEquals(networkServiceName, DEFAULT_LYNX_SAA_SERVICE);
  }

  @Test
  void testBusinessServiceSwiftCbprPlus02() {
    String networkServiceName = saaConfig.getNetworkServiceName(SaaConfig.SWIFT_CBPRPLUS_02);
    assertEquals(networkServiceName, DEFAULT_CBPRPLUS_SAA_SERVICE);
  }

  @Test
  void testBusinessServiceHeartbeat() {
    String networkServiceName = saaConfig.getNetworkServiceNameByMessageIdentifier(SaaConfig.MESSAGETYPE_ADMI_004);
    assertEquals(networkServiceName, DEFAULT_HEARTBEAT_SAA_SERVICE);
  }

  @Test
  void testBusinessServiceUnsupported() {
    String networkServiceName = saaConfig.getNetworkServiceName("Unsupported");
    assertNull(networkServiceName);
  }

}
