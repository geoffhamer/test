package ca.bankofcanada.smm.integration.incoming;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(properties = {"smm.trust.swift=true"})
public class SAAAckNackXsysIntegrationTest extends SwiftIncomingIntegrationBaseTest {

  @Test
  @DisplayName("SAA message with transmissionReport that contains ack/nack is processed")
  public void testSAATransmissionReportAckIsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/acknack/saa_pacs009_ack_from_swift.xml";
    String expectedOutputFile = "integration/expected/testSAATransmissionReportAckIsProcessed-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message with transmissionReport that doesn't contain ack/nack is processed")
  public void testSAATransmissionReportWithoutPseudoAckNackIsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/acknack/saa_pacs009_ack_from_swift_no_pseudoacknack.xml";
    String expectedOutputFile = "integration/expected/testSAATransmissionReportNoAckNackIsProcessed-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message with transmissionReport value of MessageNacked")
  public void testSAATransmissionReportNetworkNackIsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/acknack/saa_pacs009_nack.xml";
    String expectedOutputFile = "integration/expected/testSAATransmissionReportNetworkNacked-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message with transmissionReport value of NetworkAborted")
  public void testSAATransmissionReportNetworkAbortedIsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/acknack/saa_pacs009_nack_network-aborted.xml";
    String expectedOutputFile = "integration/expected/testSAATransmissionReportNetworkNacked-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message with transmissionReport value of NetworkTimedout")
  public void testSAATransmissionReportNetworkTimedoutIsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/acknack/saa_pacs009_nack_network-timedout.xml";
    String expectedOutputFile = "integration/expected/testSAATransmissionReportNetworkNacked-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message that carries xsys.003.001.01 is processed")
  public void testXsys003IsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/xsys/xsys003-signed.xml";
    String expectedOutputFile = "integration/expected/testXsys003IsProcessed-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message that carries xsys.002.001.01 is processed")
  public void testXsys002IsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/xsys/xsys002-signed.xml";
    String expectedOutputFile = "integration/expected/testXsys002IsProcessed-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

  @Test
  @DisplayName("SAA message that carries xsys.012.001.01 is processed")
  public void testXsys012IsProcessed() throws Exception {
    String inputMessageFile = "messages/incoming/xsys/xsys012-signed.xml";
    String expectedOutputFile = "integration/expected/testXsys012IsProcessed-expected-output.xml";
    validateIncomingWithExpectedOutgoing(inputMessageFile, expectedOutputFile);
  }

}
