package ca.bankofcanada.smm.integration.incoming;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(properties = {"smm.trust.swift=true"})
public class MessageValidationIntegrationTest extends SwiftIncomingIntegrationBaseTest {

   @Test
   @DisplayName("A CBPR message is put on the flow with validation errors. Test shows validation is applied")
   public void cbprMessageIsValidated() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-CBPR_Party_Name_Any_BIC_FormalRule.xml";
      String expectedOutputFile = "integration/expected/testCBPRMessageIsValidated-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A valid message doesn't contain empty ErrorList in SMM message header")
   public void testValidCBPRDonotContainEmptyErrorListInSMMMessageHeader() throws Exception {
      String inputMessageFile = "messages/incoming/09cov/pacs.09.cbpr.cov-valid.xml";
      String expectedOutputFile = "integration/expected/testValidCBPRDonotContainEmptyErrorListInSMMMessageHeader-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A CBPR message that will cause a type-2 Structure validation failure")
   public void messageWithBadStructureFailsValidation() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-CBPR-Type02-IntermediaryAgent1AccountRule.xml";
      String expectedOutputFile = "integration/expected/pacs.009.type-02-sturcture-failure-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A CBPR message with bad SAA envelope will cause multiple type-2 validation failures")
   public void messageWithBadXMLThrowsException() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-CBPR_Unparsable_XML.xml";
      String expectedOutputFile = "integration/expected/pacs.009.multiple-type-2-unparsable-failure-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A CBPR message with invalid SAA envelope will cause multiple type-1 validation failures")
   public void messageWithBadSaaEnvelopeThrowsException() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-CBPR_Invalid_SAA_Header.xml";
      String expectedOutputFile = "integration/expected/PACS09-CBPR_Invalid_SAA_Header-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("An XML message that doesn't match any format type-2 validation failure")
   public void messageCompletelyMangledHandledProperly() throws Exception {
      String externalMsgReplacement = "Failed (unexpected element '{}Envelope' on '{urn:swift:saa:xsd:saa.2.0}DocumentRoot')";
      String inputMessageFile = "messages/outgoing/non-pacs-unparsable.xml";
      String expectedOutputFile = "integration/expected/non-pacs-unparsable-expected-output.xml";
      validateIncomingWithExpectedOutgoingContainsExternalMsg( inputMessageFile, expectedOutputFile, externalMsgReplacement);
   }

   @Test
   @DisplayName("An message that doesn't have valid messageType is transformed to UNKNOWN type")
   public void messageTypeNotDetectedIsAssignedUnknownMessageType() throws Exception {
      String inputMessageFile = "messages/incoming/acknack/saa_pacs009_ack_from_swift-unkn-delstat.xml";
      String expectedOutputFile = "integration/expected/testUnknownMessageIsAssignedUnkownType-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile);
   }

   @Test
   @DisplayName("An non-XML message resulted in type-99 runtime error")
   public void nonXMLMessageCreatesType99RuntimeError() throws Exception {
      String inputMessageFile = "messages/incoming/sample-non-XML.xml";
      String expectedOutputFile = "integration/expected/sample-non-XML-expected-SMM-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile);
   }

   @Test
   @DisplayName("The TSInfoForReceiver in pacs008 is extracted and added to constructed message")
   public void tssInfoExtractedPACS008AndAddToConstructedMessageLocal() throws Exception {
      String inputMessageFile = "messages/incoming/08/saa_pacs008_cbpr_with_tss_aok.xml";
      String expectedOutputFile = "integration/expected/testSaaPacs008CbprWithTssAok-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile);
   }

   @Test
   @DisplayName("The TSInfoForReceiver in pacs009 is extracted and added to constructed message")
   public void tssInfoExtractedPACS009AndAddToConstructedMessageLocal() throws Exception {
      String inputMessageFile = "messages/outgoing/09/saa_pacs009_outgoing_with_TSS_NOK.xml";
      String expectedOutputFile = "integration/expected/testSaaPacs009LynxWithTssNok-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile);
   }

   @Test
   @DisplayName("A CBPR PACS.09 message with BizSvc set to swift.cbprplus.01 creates an error of Type 1")
   public void invalidBizSvcOnPACS09GeneratesValidationError() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-CBPR-invalid-bizsvc.xml";
      String expectedOutputFile = "integration/expected/pacs.009.invalid-bizsvc-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A CBPR PACS.09-COV message with BizSvc set to swift.cbprplus.01 creates an error of Type 1")
   public void invalidBizSvcOnPACS09COVGeneratesValidationError() throws Exception {
      String inputMessageFile = "messages/incoming/09cov/pacs.009cov.invalid-bizsvc.xml";
      String expectedOutputFile = "integration/expected/pacs.009COV.invalid-bizsvc-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }
}
