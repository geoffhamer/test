package ca.bankofcanada.smm.integration.incoming;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.integration.test.mock.MockIntegration.messageArgumentCaptor;
import static org.springframework.integration.test.mock.MockIntegration.mockMessageHandler;

import ca.bankofcanada.smm.integration.SwiftIntegrationBaseTest;
import java.util.regex.Pattern;
import javax.annotation.Resource;
import org.junit.jupiter.api.AfterEach;
import org.mockito.ArgumentCaptor;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig(locations = {"/TEST-applicationContext.xml"})
public class SwiftIncomingIntegrationBaseTest extends SwiftIntegrationBaseTest {

  private static final Pattern CREATE_DATE_PATTERN = Pattern.compile("<CreationDate>.*</CreationDate>");
  private static final Pattern ERROR_MESSAGE_PATTERN = Pattern.compile("<ErrorMessage>(.|\\r\\n)*</ErrorMessage>");

  @Resource(name = "swiftMessageDrivenInChannel")
  MessageChannel messageChannel;

  @Resource(name = "incomingExceptionChannel")
  MessageChannel exceptioneChannel;

  @AfterEach
  public void tearDown() {
    this.mockIntegrationContext.resetBeans();
  }

  void validateIncomingWithExpectedOutgoing(String incomingSwiftMessage, String expectedSmmMessage)
      throws Exception {
    validateIncomingStringWithExpectedOutgoing(incomingSwiftMessage, expectedSmmMessage, null);
  }

  void validateIncomingWithExpectedOutgoingContainsExternalMsg(String incomingSwiftMessage,
      String expectedSmmMessage, String externalMsgReplacement) throws Exception {
    validateIncomingStringWithExpectedOutgoing(incomingSwiftMessage, expectedSmmMessage,
        externalMsgReplacement);
  }

  private void validateIncomingStringWithExpectedOutgoing(String incomingSwiftMessage,
      String expectedSmmMessage, String externalMsgReplacement) throws Exception {

    // arrange
    String inputMessage = loadMessage(incomingSwiftMessage);

    ArgumentCaptor<Message<?>> messageArgumentCaptor = messageArgumentCaptor();
    MessageHandler mockMessageHandler = mockMessageHandler(messageArgumentCaptor)
        .handleNext(m -> {
        });
    mockIntegrationContext.substituteMessageHandlerFor("messageOut", mockMessageHandler);

    // act
    try {
      messageChannel.send(MessageBuilder.withPayload(inputMessage).build());
    } catch (Exception ex) {
      // This mocks exceptions thrown during processing being put on the exception channel.
      exceptioneChannel.send(MessageBuilder.withPayload(ex).build());
    }

    Message<?> smmMessage = messageArgumentCaptor.getValue();

    // assert
    String expectedMessage = loadMessage(expectedSmmMessage);
    String actualMessage = scrubSmmMessage(smmMessage);

    if (externalMsgReplacement != null) {
      actualMessage = replaceExternalMsg(actualMessage, externalMsgReplacement);
    }

    assertEquals(normalizeEOLs(expectedMessage), normalizeEOLs(actualMessage));
  }

  String scrubSmmMessage(Message<?> message) {
    // production code should provide the ability to supply Creation Date
    // we scrub it out in the meantime
    return CREATE_DATE_PATTERN.matcher(message.getPayload().toString()).replaceFirst("<CreationDate></CreationDate>");
  }

  String replaceExternalMsg(String actualMsg, String externalMsgReplacement) {
    // C24 validation will generate different column/row number in the returned error message in different test runner
    // we replace it with a generic error msg to avoid test failures due to wrong column/row number match
    return ERROR_MESSAGE_PATTERN.matcher(actualMsg).replaceFirst("<ErrorMessage>" + externalMsgReplacement + "</ErrorMessage>");
  }
}
