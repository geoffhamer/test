package ca.bankofcanada.smm.service;

import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.bankofcanada.smm.common.CommonConstants;
import ca.bankofcanada.smm.config.SmmMessageResource;
import ca.bankofcanada.smm.entity.SystemInterfaceNodeSummary;
import ca.bankofcanada.smm.exception.ResourceNotFoundException;
import ca.bankofcanada.smm.exception.SAAInterfaceException;
import ca.bankofcanada.smm.models.Code;
import ca.bankofcanada.smm.models.SAAInterfaceConnection;
import ca.bankofcanada.smm.repositories.SystemInterfaceNodeRepository;
import ca.bankofcanada.smm.util.SystemPropertyManager;

import java.sql.Timestamp;
import java.util.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import javax.persistence.EntityManager;

/**
 * Unit tests for SAAInterfaceService class
 */
@ExtendWith(MockitoExtension.class)
public class SAAInterfaceServiceTest {
  @InjectMocks
  private SAAInterfaceService saaInterfaceService;

  @Mock
  private SystemInterfaceNodeRepository systemInterfaceNodeRepository;

  @Mock
  private JmsQueueService jmsQueueService;

  @Mock
  private SystemPropertyManager systemPropertyManager;

  @Mock
  private SmmMessageResource smmMessageResource;

  @Mock
  private EntityManager entityManager;

  /**
   * Dummy MessageSource which must be returned when SmmMessageResource.getBilingualMessageSource()
   * is called.
   *
   * Mockito.when( smmMessageResource.getBilingualMessageSource() ).thenReturn(this.messageSource)
   */
  private final MessageSource messageSource = new MessageSource() {
    @Override
    public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
      return null;
    }

    @Override
    public String getMessage(String code, Object[] args, Locale locale)
        throws NoSuchMessageException {
      return null;
    }

    @Override
    public String getMessage(MessageSourceResolvable resolvable, Locale locale)
        throws NoSuchMessageException {
      return null;
    }
  };

  @Test
  @DisplayName("Test success switchToSAAInterface call")
  public void testSwitchToSAAInterface_Success() throws ResourceNotFoundException, SAAInterfaceException {
    Long interfaceId = 1234L; // Interface ID
    SystemInterfaceNodeSummary interfaceNodeSummary = new SystemInterfaceNodeSummary();
    interfaceNodeSummary.setPk(interfaceId);
    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.of(interfaceNodeSummary));

    Mockito.when(systemPropertyManager.getProperty(CommonConstants.SYSTEM_PROPERTY_ENVIRONMENT)).thenReturn("UNIT_TEST");
    Mockito.when(systemInterfaceNodeRepository
            .replaceStatusesByStatusAndCategory(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_SUCCESS);

    Mockito.when(systemInterfaceNodeRepository
            .updateStatusAndSwitchResultByPkAndStatusAndCategory(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_SUCCESS);

    Mockito.doNothing().when(jmsQueueService)
        .sendMessage(Mockito.any(), Mockito.any(), Mockito.any());

    saaInterfaceService.switchToSAAInterface(interfaceId);

    // No assert as it is a void method and will throw an exception in case of failure
  }

  @Test
  @DisplayName("Test failure switchToSAAInterface call caused by an exception thrown while resetting Any InProgress Node Status to Inactive")
  public void testSwitchToSAAInterface_FailureForAllStatusesUpdate() {
    Long interfaceId = 5678L; // Interface ID
    SystemInterfaceNodeSummary interfaceNodeSummary = new SystemInterfaceNodeSummary();
    interfaceNodeSummary.setPk(interfaceId);
    Mockito.when(systemInterfaceNodeRepository
        .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.of(interfaceNodeSummary));

    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.of(interfaceNodeSummary));

    String errorMessage = "Database connection error";
    Mockito.doThrow(new CannotGetJdbcConnectionException(errorMessage))
        .when(systemInterfaceNodeRepository)
        .replaceStatusesByStatusAndCategory(Mockito.any(), Mockito.any(), Mockito.any());

    assertThrows(SAAInterfaceException.class, () -> saaInterfaceService.switchToSAAInterface(interfaceId));
  }

  @Test
  @DisplayName("Test failure switchToSAAInterface call caused by an exception thrown while updating the required interface data")
  public void testSwitchToSAAInterface_FailureForCurrentInterfaceStatusUpdate() {
    Long interfaceId = 5678L; // Interface ID
    SystemInterfaceNodeSummary interfaceNodeSummary = new SystemInterfaceNodeSummary();
    interfaceNodeSummary.setPk(interfaceId);
    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.of(interfaceNodeSummary));

    String errorMessage = "Database connection error";
    Mockito.doThrow(new CannotGetJdbcConnectionException(errorMessage))
        .when(systemInterfaceNodeRepository)
        .updateStatusAndSwitchResultByPkAndStatusAndCategory(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

    Mockito.when(systemInterfaceNodeRepository
            .replaceStatusesByStatusAndCategory(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_SUCCESS);

    assertThrows(SAAInterfaceException.class, () -> saaInterfaceService.switchToSAAInterface(interfaceId));
  }

  @Test
  @DisplayName("Test failure switchToSAAInterface call caused by resource not found during SQL update")
  public void testSwitchToSAAInterface_ResourceNotFoundDuringUpdate() {
    Long interfaceId = 5678L; // Interface ID
    SystemInterfaceNodeSummary interfaceNodeSummary = new SystemInterfaceNodeSummary();
    interfaceNodeSummary.setPk(interfaceId);

    Mockito.when( smmMessageResource.getBilingualMessageSource() ).thenReturn(this.messageSource);
    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.of(interfaceNodeSummary));

    Mockito.when(systemInterfaceNodeRepository
            .replaceStatusesByStatusAndCategory(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_SUCCESS);

    Mockito.when(systemInterfaceNodeRepository
            .updateStatusAndSwitchResultByPkAndStatusAndCategory(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_FAILURE); // No row was updated

    assertThrows(ResourceNotFoundException.class, () -> saaInterfaceService.switchToSAAInterface(interfaceId));
  }

  @Test
  @DisplayName("Test failure switchToSAAInterface call caused by resource not found during message queueing")
  public void testSwitchToSAAInterface_ResourceNotFoundDuringQueuing() {
    Long interfaceId = 5678L; // Interface ID

    Mockito.when( smmMessageResource.getBilingualMessageSource() ).thenReturn(this.messageSource);

    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.empty()); // Pk not found

    assertThrows(ResourceNotFoundException.class, () -> saaInterfaceService.switchToSAAInterface(interfaceId));
  }

  @Test
  @DisplayName("Test success getSAAInterface call")
  public void testGetSAAInterface_Success() throws ResourceNotFoundException, SAAInterfaceException {
    Long interfaceId = 5678L; // Interface ID
    SystemInterfaceNodeSummary interfaceNodeSummaryExpected  = new SystemInterfaceNodeSummary();
    interfaceNodeSummaryExpected.setPk(interfaceId);

    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.of(interfaceNodeSummaryExpected));

    SystemInterfaceNodeSummary interfaceNodeSummaryRetrieved = saaInterfaceService.getSAAInterface(interfaceId);

    Assertions.assertEquals(interfaceNodeSummaryExpected, interfaceNodeSummaryRetrieved);
  }

  @Test
  @DisplayName("Test success findByType call")
  public void testFindByType_Success() throws SAAInterfaceException {

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList = new ArrayList<>();
    SystemInterfaceNodeSummary summary = this.createNodeSummarySkeleton(0,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0);
    sysInterfaceNodeList.add(summary);

    Mockito.when(systemInterfaceNodeRepository
           .findByType(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()) )
           .thenReturn(sysInterfaceNodeList);

    List<SAAInterfaceConnection> connections = saaInterfaceService.getAllSAAInterfacesWithUpdates();
    Assertions.assertEquals(1, connections.size());

    SAAInterfaceConnection conn = connections.get(0);
    Assertions.assertNotNull(conn.getStatus());
    Assertions.assertNotNull(conn.getStatus().getCode());
    Assertions.assertEquals(Code.AVAILABLE, conn.getStatus().getCode());
  }


  @Test
  @DisplayName("Test failure getSAAInterface call caused by resource not found")
  public void testGetSAAInterface_ResourceNotFound() {
    Long interfaceId = 1234L; // Interface ID

    Mockito.when( smmMessageResource.getBilingualMessageSource() ).thenReturn(this.messageSource);
    Mockito.when(systemInterfaceNodeRepository
            .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(Optional.empty()); // Pk not found

    assertThrows(ResourceNotFoundException.class, () -> saaInterfaceService.getSAAInterface(interfaceId));
  }

  @Test
  @DisplayName("Test failure getSAAInterface call caused by Exception during SQL query")
  public void testGetSAAInterface_SAAInterfaceException() {
    Long interfaceId = 1234L; // Interface ID
    String errorMessage = "Database connection error";

    Mockito.doThrow(new CannotGetJdbcConnectionException(errorMessage))
        .when(systemInterfaceNodeRepository)
        .findSystemInterfaceNodeByPk(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any());

    assertThrows(SAAInterfaceException.class, () -> saaInterfaceService.getSAAInterface(interfaceId));
  }


  @Test
  @DisplayName("Test clearing when no nodes in InProgress/Success state")
  public void testHandleInProgressNodes_withNoneInProgress() throws SAAInterfaceException {

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList = new ArrayList<>();
    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(0,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(1,
        SAAInterfaceConstants.API_STATUS_ACTIVE,
        SAAInterfaceConstants.SWITCH_RESULT_SUCCESS,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(2,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(3,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0) );

    List<SystemInterfaceNodeSummary> updatedNodes = saaInterfaceService.updateInProgressInterfaces(sysInterfaceNodeList);

    // No nodes changed
    Assertions.assertEquals(0, updatedNodes.size());
  }


  @Test
  @DisplayName("Test clearing when one node in InProgress/Success state")
  public void testHandleInProgressNodes_withOneInProgress() throws SAAInterfaceException {

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList = new ArrayList<>();
    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(0,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(1,
        SAAInterfaceConstants.API_STATUS_ACTIVATION_REQUESTED,
        SAAInterfaceConstants.SWITCH_RESULT_SUCCESS,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(2,
        SAAInterfaceConstants.API_STATUS_ACTIVE,
        SAAInterfaceConstants.SWITCH_RESULT_SUCCESS,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(3,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0) );

    List<SystemInterfaceNodeSummary> updatedNodes = saaInterfaceService.updateInProgressInterfaces(sysInterfaceNodeList);

    Assertions.assertEquals(2, updatedNodes.size());

    // InProgress node set Active
    Assertions.assertEquals(SAAInterfaceConstants.REPO_STATUS_ACTIVE, sysInterfaceNodeList.get(1).getStatus());
    Assertions.assertEquals(SAAInterfaceConstants.SWITCH_RESULT_SUCCESS, sysInterfaceNodeList.get(1).getSwitchResult());

    // Previous Active node set Inactive
    Assertions.assertEquals(SAAInterfaceConstants.REPO_STATUS_INACTIVE, sysInterfaceNodeList.get(2).getStatus());
    Assertions.assertNull(sysInterfaceNodeList.get(2).getSwitchResult());
  }


  @Test
  @DisplayName("Test clearing when multiple nodes in InProgress/Success state")
  public void testHandleInProgressNodes_withMultipleInProgress() throws SAAInterfaceException {

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList = new ArrayList<>();
    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(0,
        SAAInterfaceConstants.API_STATUS_ACTIVATION_REQUESTED,
        SAAInterfaceConstants.SWITCH_RESULT_SUCCESS, 0));

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(1,
        SAAInterfaceConstants.API_STATUS_AVAILABLE,
        null,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(2,
        SAAInterfaceConstants.API_STATUS_ACTIVE,
        SAAInterfaceConstants.SWITCH_RESULT_SUCCESS,0) );

    sysInterfaceNodeList.add( this.createNodeSummarySkeleton(3,
        SAAInterfaceConstants.API_STATUS_ACTIVATION_REQUESTED,
        SAAInterfaceConstants.SWITCH_RESULT_SUCCESS,-1));

    List<SystemInterfaceNodeSummary> updatedNodes = saaInterfaceService.updateInProgressInterfaces(sysInterfaceNodeList);

    Assertions.assertEquals(3, updatedNodes.size());

    // Node 0 is set Active because it has the earliest date
    Assertions.assertEquals(SAAInterfaceConstants.REPO_STATUS_ACTIVE, sysInterfaceNodeList.get(0).getStatus());
    Assertions.assertEquals(SAAInterfaceConstants.SWITCH_RESULT_SUCCESS, sysInterfaceNodeList.get(0).getSwitchResult());

    // Previous Active node set Inactive
    Assertions.assertEquals(SAAInterfaceConstants.REPO_STATUS_INACTIVE, sysInterfaceNodeList.get(2).getStatus());
    Assertions.assertNull(sysInterfaceNodeList.get(2).getSwitchResult());

    // Older InProgress node set Inactive
    Assertions.assertEquals(SAAInterfaceConstants.REPO_STATUS_INACTIVE, sysInterfaceNodeList.get(3).getStatus());
    Assertions.assertNull(sysInterfaceNodeList.get(3).getSwitchResult());

  }


  @Test
  @DisplayName("Test success setSwitchResultToNull call")
  public void testSetSwitchResultToNull_Success() throws ResourceNotFoundException, SAAInterfaceException {
    Long interfaceId = 1234L; // Interface ID

    Mockito.when(systemInterfaceNodeRepository
            .updateStatusAndSwitchResultByPkAndStatusAndCategory(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_SUCCESS);

    saaInterfaceService.setSwitchResultToNull(interfaceId);

    // No assert as it is a void method and will throw an exception in case of failure
  }


  @Test
  @DisplayName("Test failed setSwitchResultToNull call")
  public void testSetSwitchResultToNull_Failure() {
    Long interfaceId = 1234L; // Interface ID

    Mockito.when( smmMessageResource.getBilingualMessageSource() ).thenReturn(this.messageSource);

    Mockito.when(systemInterfaceNodeRepository
            .updateStatusAndSwitchResultByPkAndStatusAndCategory(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any()))
        .thenReturn(SAAInterfaceService.ROWS_NB_SWITCH_INTERFACE_FAILURE);

    assertThrows(ResourceNotFoundException.class, () -> saaInterfaceService.setSwitchResultToNull(interfaceId));
  }


  /**
   * Used to create a node summary skeleton
   *
   * @param pk The UID of the node summary
   * @param status The UID of the node summary
   * @param switchResult Value of the switch result
   * @param monthOffset Used to create instances with update timestamp in the past/future
   * @return A skeletal SystemInterfaceNodeSummary
   */
  private SystemInterfaceNodeSummary createNodeSummarySkeleton(
      int pk,
      String status,
      String switchResult,
      int monthOffset) {

    SystemInterfaceNodeSummary nodeSummary = new SystemInterfaceNodeSummary();

    nodeSummary.setPk((long) pk);
    nodeSummary.setNameEn("SAA "+pk);
    nodeSummary.setNameFr("SAA "+pk);
    nodeSummary.setDescEn("This is SAA "+pk);
    nodeSummary.setDescFr("C'est SAA "+pk);
    nodeSummary.setLastUpdateBy("HABS");

    GregorianCalendar cal = (GregorianCalendar)GregorianCalendar.getInstance();
    cal.add(Calendar.MONTH, monthOffset);
    nodeSummary.setLastUpdateTimestamp( new Timestamp(cal.getTimeInMillis() ) );

    nodeSummary.setStatus(status);
    nodeSummary.setSwitchResult(switchResult);

    return nodeSummary;
  }

}
