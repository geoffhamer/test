package ca.bankofcanada.smm.integration.outgoing;

import static org.springframework.integration.test.mock.MockIntegration.messageArgumentCaptor;
import static org.springframework.integration.test.mock.MockIntegration.mockMessageHandler;

import ca.bankofcanada.smm.integration.SwiftIntegrationBaseTest;
import ca.bankofcanada.smm.service.SwiftMessagePersistService;
import javax.annotation.Resource;
import org.junit.jupiter.api.AfterEach;
import org.mockito.ArgumentCaptor;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringJUnitConfig(locations = { "/TEST-applicationContext.xml" })
public class SwiftOutgoingIntegrationBaseTest extends SwiftIntegrationBaseTest {


  @Resource(name = "swiftMessageDrivenOutChannel")
  MessageChannel messageChannel;

  @Resource(name = "outgoingExceptionChannel")
  MessageChannel exceptionChannel;

  @MockBean
  private SwiftMessagePersistService swiftMessagePersistService;

  @AfterEach
  public void tearDown() {
    this.mockIntegrationContext.resetBeans();
  }

  protected String sendMessage(String inputMessage) {
    ArgumentCaptor<Message<?>> messageArgumentCaptor = messageArgumentCaptor();
    MessageHandler mockMessageHandler = mockMessageHandler(messageArgumentCaptor).handleNext(m -> {});
    mockIntegrationContext.substituteMessageHandlerFor("smmOut", mockMessageHandler);

    try {
      messageChannel.send(MessageBuilder.withPayload(inputMessage).build());
    } catch (Exception ex) {
      // This mocks exceptions thrown during processing being put on the exception channel.
      exceptionChannel.send(MessageBuilder.withPayload(ex).build());
      return null;
    }
    Message<?> smmMessage = messageArgumentCaptor.getValue();

    return smmMessage.getPayload().toString();
  }
}
