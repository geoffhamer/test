package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.clearLog;
import static ca.bankofcanada.smm.TestUtils.getLog;
import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import biz.c24.io.api.C24;
import biz.c24.io.api.ParserError;
import biz.c24.io.api.ParserException;
import biz.c24.io.api.ValidationResultEnum;
import ca.bankofcanada.common.security.apsec.ApsecException;
import ca.bankofcanada.smm.integration.SwiftIntegrationBaseTest;
import ca.bankofcanada.smm.model.MessageLocal;
import java.io.IOException;
import java.util.GregorianCalendar;
import org.apache.commons.lang3.NotImplementedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig(locations = { "/TEST-applicationContext.xml" })
public class MessageFlowExceptionProcessorTest extends SwiftIntegrationBaseTest {

  @BeforeEach
  public void clear() throws IOException {
    clearLog();
  }

  @Test
  @DisplayName("Incoming parserException is converted to MessageLocal error list")
  public void testIncomingParserException() throws IOException {
    // arrange
    ParserError parserErrorOne = new ParserError(ValidationResultEnum.FAILED, null, null, "parserErrorOne", "parserErrorOne", 0, 0, 0);
    ParserException parserException = new ParserException(ValidationResultEnum.FAILED, new ParserError[]{parserErrorOne});
    String testFile = loadMessage("messages/incoming/09cov/pacs.009cov.invalid-bizsvc.xml");
    MessageLocal smmMessage = getMessageLocal();

    // act
    MessageFlowExceptionProcessor.ParserException.processIncomingException(parserException, smmMessage, testFile);

    // assert
    assertTrue(smmMessage.toString().contains("parserErrorOne"));
  }

  @Test
  @DisplayName("Outgoing parserException processing is not implemented")
  public void testOutgoingParserException() {
    assertThrows(NotImplementedException.class, () -> MessageFlowExceptionProcessor.ParserException.processOutgoingException("90001"));
  }

  @Test
  @DisplayName("Incoming ApsecException is converted to MessageLocal error list")
  public void testIncomingApsecException() throws IOException {
    // arrange
    ApsecException rootCause = new ApsecException("Failed to validate message signature");
    MessageLocal smmMessage = getMessageLocal();
    String testFile = loadMessage("messages/incoming/09cov/pacs.009cov.invalid-bizsvc.xml");

    // act
    MessageFlowExceptionProcessor.ApsecException.processIncomingException(rootCause, smmMessage, testFile);

    // assert
    assertTrue(smmMessage.toString().contains("Failed to validate message signature"));
  }

  @Test
  @DisplayName("Outgoing ApsecException triggers SysLogNG notification")
  public void testOutgoingApsecException() throws IOException {
    MessageFlowExceptionProcessor.ApsecException.processOutgoingException("90001");
    String log = getLog();
    assertTrue(log.contains("The following process failed: Sign an outgoing message"));
  }

  @Test
  @DisplayName("Incoming UnparsableSMMMessageException processing is not implemented")
  public void testIncomingUnparsableSMMMessageException() {
    assertThrows(NotImplementedException.class, () -> MessageFlowExceptionProcessor.UnparsableSMMMessageException.processIncomingException(null, null, ""));
  }

  @Test
  @DisplayName("Outgoing UnparsableSMMMessageException trigger SysLogNG notification")
  public void testOutgoingUnparsableSMMMessageException() throws IOException {
    MessageFlowExceptionProcessor.UnparsableSMMMessageException.processOutgoingException("90001");
    String log = getLog();
    assertTrue(log.contains("The following process failed: C24 structural validation of an outgoing message"));
  }

  @Test
  @DisplayName("Incoming MaximumMXPayloadSizeException processing is not implemented")
  public void testIncomingMaximumMXPayloadSizeException() {
    assertThrows(NotImplementedException.class, () -> MessageFlowExceptionProcessor.MaximumMXPayloadSizeException.processIncomingException(null, null, ""));
  }

  @Test
  @DisplayName("Outgoing MaximumMXPayloadSizeException trigger SysLogNG notification")
  public void testOutgoingMaximumMXPayloadSizeException() throws IOException {
    MessageFlowExceptionProcessor.MaximumMXPayloadSizeException.processOutgoingException("90001");
    String log = getLog();
    assertTrue(log.contains("The following process failed: Validation of an outgoing message maximum payload size limit of 80,000 bytes"));
  }

  @Test
  @DisplayName("Incoming SAADataPDUException processing is not implemented")
  public void testIncomingSAADataPDUException() {
    assertThrows(NotImplementedException.class, () -> MessageFlowExceptionProcessor.SAADataPDUException.processIncomingException(null, null, ""));
  }

  @Test
  @DisplayName("Outgoing SAADataPDUException trigger SysLogNG notification")
  public void testOutgoingSAADataPDUException() throws IOException {
    MessageFlowExceptionProcessor.SAADataPDUException.processOutgoingException("90001");
    String log = getLog();
    assertTrue(log.contains("The following process failed: SMM is unable to parse the outgoing message"));
  }

  @Test
  @DisplayName("Incoming SMMPersistenceException processing is not implemented")
  public void testIncomingSMMPersistenceException() {
    assertThrows(NotImplementedException.class, () -> MessageFlowExceptionProcessor.SMMPersistenceException.processIncomingException(null, null, ""));
  }

  @Test
  @DisplayName("Outgoing SMMPersistenceException trigger SysLogNG notification")
  public void testOutgoingSMMPersistenceException() throws IOException {
    MessageFlowExceptionProcessor.SMMPersistenceException.processOutgoingException("90001");
    String log = getLog();
    assertTrue(log.contains("The following process failed: Persist of an outgoing message in the database"));
  }

  @Test
  @DisplayName("Incoming RuntimeException is converted to MessageLocal error list")
  public void testIncomingRuntimeException() throws IOException {
    // arrange
    RuntimeException rootCause = new RuntimeException("Uncaught runtime exception occurred");
    MessageLocal smmMessage = getMessageLocal();
    String testFile = loadMessage("messages/incoming/09cov/pacs.009cov.invalid-bizsvc.xml");

    // act
    MessageFlowExceptionProcessor.RuntimeException.processIncomingException(rootCause, smmMessage, testFile);

    // assert
    assertTrue(smmMessage.toString().contains("Uncaught runtime exception occurred"));
  }


  @Test
  @DisplayName("Original message is not convertible")
  public void testOriginalMessageIsNotConvertible() {
    // arrange
    try (MockedStatic<C24> ignored = Mockito.mockStatic(C24.class)) {
      RuntimeException rootCause = new RuntimeException("Uncaught runtime exception occurred");
      MessageLocal smmMessage = getMessageLocal();

      // act
      MessageFlowExceptionProcessor.RuntimeException.processIncomingException(rootCause, smmMessage,
          "test");
      // assert
      assertTrue(smmMessage.toString().contains("null"));
    }
  }

  @Test
  @DisplayName("Outgoing RuntimeException trigger SysLogNG notification")
  public void testOutgoingRuntimeException() throws Exception {
    MessageFlowExceptionProcessor.RuntimeException.processOutgoingException("90001");
    String log = getLog();
    assertTrue(log.contains("has encountered an unknown error"));
  }

  private MessageLocal getMessageLocal(){
    MessageLocal smmMessage = new MessageLocal();
    smmMessage.createHeader();
    smmMessage.createBody();
    smmMessage.getHeader().setCreationDate((new GregorianCalendar()).getTime());
    smmMessage.getHeader().setMessageKey("900001");
    smmMessage.getHeader().setMessageType("pacs.009.01.08");
    return smmMessage;
  }
}
