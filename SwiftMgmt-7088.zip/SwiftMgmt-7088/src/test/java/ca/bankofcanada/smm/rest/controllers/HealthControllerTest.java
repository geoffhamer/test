package ca.bankofcanada.smm.rest.controllers;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.given;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.repositories.SwiftMessageRepository;
import io.restassured.http.ContentType;
import java.util.Optional;
import javax.servlet.http.HttpServletResponse;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;


class HealthControllerTest extends RestControllerBaseTest {

  @MockBean
  SwiftMessageRepository swiftMessageRepository;

  @Test
  public void health200() {

    SwiftMessage swiftMessage = new SwiftMessage();
    swiftMessage.setMessagePk(1L);
    Mockito.when(swiftMessageRepository.findFirstByOrderByMessagePkAsc())
        .thenReturn(Optional.of(swiftMessage));

    //@formatter:off
    given()
        .body("").
    when().
        get("/api/health").
    then().
        statusCode(HttpServletResponse.SC_OK);
    //@formatter:on
  }

  @Test
  public void health503() {

    Mockito.when(swiftMessageRepository.findFirstByOrderByMessagePkAsc())
        .thenThrow(new RuntimeException("test"));

    //@formatter:off
    given()
        .body("").
     when().
        get("/api/health").
     then()
        .statusCode(HttpServletResponse.SC_SERVICE_UNAVAILABLE)
        .contentType(ContentType.JSON)
        .body("errors[0].code", Matchers.equalTo(-1),
            "errors[0].message", Matchers.stringContainsInOrder("Database Problem"));
    //@formatter:on
  }
}