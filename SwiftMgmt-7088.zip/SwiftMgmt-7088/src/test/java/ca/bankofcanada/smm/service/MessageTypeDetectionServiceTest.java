package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

public class MessageTypeDetectionServiceTest {

   final MessageTypeDetectionServiceActivator messageTypeDetectionServiceActivator =
       new MessageTypeDetectionServiceActivator();

   @Test
   @DisplayName("Test that the service activator is able to set the CBPR PACS.09 message type properly")
   public void determineCPBR09MessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/09/PACS09-Sample-good.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "pacs.009.001.08", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the CBPR PACS.09COV message type properly")
   public void determineCBPR09COVMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/09cov/pacs.09.cbpr.cov-valid.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "pacs.009.001.08", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the LYNX PACS.09 message type properly")
   public void determineLYNX09MessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/09/PACS09-LYNX-valid.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "pacs.009.001.08", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the LYNX PACS.09 message type to UNKNOWN")
   public void determineLYNX09UnknownMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/09/PACS09-LYNX-valid-unkn-msgid.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "UNKNOWN", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the LYNX PACS.09 message type properly")
   public void determineLYNX09COVMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/09cov/pacs.09.lynx.cov-valid.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "pacs.009.001.08", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the AckNack message type properly")
   public void determineAckNackMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/acknack/saa_pacs009_ack_from_swift.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "NetworkAcked", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the AckNack message type to UNKNOWN")
   public void determineAckNackUnknownMessageTypeTest() throws IOException {

      String inputMessage = loadMessage(
          "messages/incoming/acknack/saa_pacs009_ack_from_swift-unkn-delstat.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "UNKNOWN", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the XSys message type properly")
   public void determineXSysMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/xsys/saa_pacs009_xsys002_from_swift.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "xsys.002.001.01" , (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the CAMT message type properly")
   public void determineCamtMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/camt/saa_camt_057_valid.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "camt.057.001.06", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the CAMT message type to UNKNOWN")
   public void determineCamtUnknownMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/camt/saa_camt_057_valid-unkn-msgid.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "UNKNOWN", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator is able to set the Heartbeat message type properly")
   public void determineHeartbeatMessageTypeTest() throws IOException {

      String inputMessage = loadMessage(
          "messages/incoming/admi/saa_admi_004_bypass_persistence.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( "admi.004.001.02", (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

   @Test
   @DisplayName("Test that the service activator sets the UNKNOWN type properly")
   public void determineUnknownMessageTypeTest() throws IOException {

      String inputMessage = loadMessage("messages/incoming/sample-non-SAA.xml");

      Message<?> inMessage = MessageBuilder.withPayload(inputMessage).build();
      Message<?> outMessage = messageTypeDetectionServiceActivator.detectMessageType( inMessage );

      MessageHeaders headers = outMessage.getHeaders();

      assertEquals( SMMBaseServiceActivator.SMM_MESSAGE_TYPE_UNKNOWN, (headers.get(SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY)) );
   }

}