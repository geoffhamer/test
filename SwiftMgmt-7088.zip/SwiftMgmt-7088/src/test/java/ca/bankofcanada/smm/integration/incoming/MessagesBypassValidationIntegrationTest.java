package ca.bankofcanada.smm.integration.incoming;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(properties = {"smm.trust.swift=true"})
public class MessagesBypassValidationIntegrationTest extends SwiftIncomingIntegrationBaseTest {

   @Test
   @DisplayName("A Lynx message is put on the flow with validation errors. Test shows validation is NOT applied")
   public void lynxMessageNotValidated() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-LYNX_Party_Name_Any_BIC_FormalRule.xml";
      String expectedOutputFile = "integration/expected/testLynxMessageIsValidated-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A Lynx message is put on the flow with structural errors in AppHdr. Test shows structural check is NOT applied")
   public void lynxMessageStructureNotChecked() throws Exception {
      String inputMessageFile = "messages/incoming/09/PACS09-LYNX-miss_BizSvc_in_AppHdr.xml";
      String expectedOutputFile = "integration/expected/testLynxMessageBypassStructuralCheck-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A Camt message with invalid BIC is put on the flow. Test shows validation is NOT applied")
   public void camtMessageBypassValidation() throws Exception {
      String inputMessageFile = "messages/incoming/camt/saa_camt_057_invalid_BIC_from_swift.xml";
      String expectedOutputFile = "integration/expected/testCamtMessageBypassValidation-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

   @Test
   @DisplayName("A Admi message with invalid BIC is put on the flow. Test shows message is NOT persisted and validation is NOT applied")
   public void admiMessageBypassPersistenceAndValidation() throws Exception {
      String inputMessageFile = "messages/incoming/admi/saa_admi_004_bypass_persistence.xml";
      String expectedOutputFile = "integration/expected/testAdmi004BypassPersistenceAndValidation-expected-output.xml";
      validateIncomingWithExpectedOutgoing( inputMessageFile, expectedOutputFile );
   }

}
