package ca.bankofcanada.smm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import ca.bankofcanada.smm.entity.Heartbeat;
import ca.bankofcanada.smm.repositories.HeartbeatRepository;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class HeartbeatServiceTest {

  @Mock
  private HeartbeatRepository repository;

  @InjectMocks
  private HeartbeatService heartbeatService;

  @Test
  void getHeartbeat_throwsIllegalStateException_whenMoreThanOneHeartbeatRecordFound() {
    when(repository.findAll()).thenReturn(Arrays.asList(new Heartbeat(), new Heartbeat()));

    assertThrows(IllegalStateException.class, () -> heartbeatService.getHeartbeat());
  }

  @Test
  void getHeartbeat_returnsEmptyOptional_whenNoHeartbeatRecordFound() {
    when(repository.findAll()).thenReturn(new ArrayList<>());

    Optional<Heartbeat> result = heartbeatService.getHeartbeat();

    assertEquals(Optional.empty(), result);
  }

  @Test
  void getHeartbeat_returnsHeartbeatRecord_whenHeartbeatRecordFound() {
    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setPk(1);

    when(repository.findAll()).thenReturn(Collections.singletonList(heartbeat));

    Optional<Heartbeat> result = heartbeatService.getHeartbeat();

    assertEquals(Optional.of(heartbeat), result);
  }

  @Test
  void save_returnsSavedHeartbeatRecord() {
    Timestamp now = Timestamp.from(Instant.now());
    Heartbeat expectedHeartbeat = new Heartbeat();
    expectedHeartbeat.setPk(1);
    expectedHeartbeat.setLastSentTimestamp(now);

    when(heartbeatService.save(any(Heartbeat.class))).thenReturn(expectedHeartbeat);

    Heartbeat heartbeat = new Heartbeat();
    heartbeat.setLastSentTimestamp(now);

    Heartbeat actualHeartbeat = heartbeatService.save(heartbeat);

    assertEquals(expectedHeartbeat, actualHeartbeat);
  }
}
