package ca.bankofcanada.smm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import ca.bankofcanada.smm.entity.BusinessCycle;
import ca.bankofcanada.smm.repositories.BusinessCycleRepository;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class BusinessCycleServiceTest {

  @Mock
  private BusinessCycleRepository businessCycleRepository;

  @InjectMocks
  private BusinessCycleService businessCycleService;

  @Test
  void getActiveBusinessCycle_returnsEmptyOptional_whenNoBusinessCycleFound() {
    when(businessCycleRepository.getOpenBusinessCycle()).thenReturn(Optional.empty());

    Optional<BusinessCycle> result = businessCycleService.getOpenBusinessCycle();

    assertFalse(result.isPresent());
  }

  @Test
  void getOpenBusinessCycle_returnsBusinessCycle_whenBusinessCycleIsActive() {
    BusinessCycle expectedBusinessCycle = new BusinessCycle();
    expectedBusinessCycle.setPk(1L);

    when(businessCycleRepository.getOpenBusinessCycle()).thenReturn(
        Optional.of(expectedBusinessCycle));

    Optional<BusinessCycle> result = businessCycleService.getOpenBusinessCycle();

    assertTrue(result.isPresent());
    assertEquals(expectedBusinessCycle, result.get());
  }

}
