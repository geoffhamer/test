package ca.bankofcanada.smm.rest.controllers;

import io.restassured.module.mockmvc.RestAssuredMockMvc;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.web.SpringJUnitWebConfig;
import org.springframework.web.context.WebApplicationContext;

@SpringJUnitWebConfig(locations = {"/TEST-applicationContext.xml"})
@TestPropertySource(value = {"classpath:smm-test.properties"})
public class RestControllerBaseTest {

  @Autowired
  protected WebApplicationContext context;

  @BeforeEach
  public void setup() {
    RestAssuredMockMvc.webAppContextSetup(context);
  }

  @AfterEach
  public void reset() {
    RestAssuredMockMvc.reset();
  }

}
