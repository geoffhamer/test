package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertEquals;

import ca.bankofcanada.smm.config.SmmInitializer;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SMMToHABSMessageBuilderTest.class, SmmInitializer.class})
public class SMMToHABSMessageBuilderTest {

  @Autowired
  private SmmInitializer smmInitializer;

  @Autowired
  private SMMToHABSMessageBuilder smmToHABSMessageBuilder;

  @Test
  @DisplayName("Test build ack message")
  public void testBuildAckNackMessage() throws IOException {
    // arrange
    String inputMsgPayloadStr = loadMessage(
        "messages/incoming/acknack/saa_pacs009_ack_from_swift.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildAckNackMessage(inputMsgPayloadStr, "1",
        "NetworkAcked");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/testSAATransmissionReportAckIsProcessed-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(scrubbedPayload), StringUtils.normalizeSpace(expectedOutMsgPayloadStr));
  }

  @Test
  @DisplayName("Test build pacs009 message")
  public void testBuildPacs009Message() throws Exception {
    // arrange
    String inputMsgPayloadStr = loadMessage("messages/incoming/09cov/pacs.09.cbpr.cov-valid.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildGenericMessage(inputMsgPayloadStr, "1",
        "pacs.009.001.08");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/testValidCBPRDonotContainEmptyErrorListInSMMMessageHeader-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(scrubbedPayload), StringUtils.normalizeSpace(expectedOutMsgPayloadStr));
  }

  @Test
  @DisplayName("Test build pacs008 cbpr message with TSInfoForReceiver present in SAA Header")
  public void testBuildPacs009MessageWithTSInfoForReceiverInSAAHeader() throws Exception {
    // arrange
    String inputMsgPayloadStr = loadMessage(
        "messages/incoming/08/saa_pacs008_cbpr_with_tss_aok.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildGenericMessage(inputMsgPayloadStr, "1",
        "pacs.008.001.08");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/testSaaPacs008CbprWithTssAok-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(scrubbedPayload), StringUtils.normalizeSpace(expectedOutMsgPayloadStr));
  }

  @Test
  @DisplayName("Test build unknown message")
  public void testBuildUnknownMessage() throws Exception {
    // arrange
    String inputMsgPayloadStr = loadMessage(
        "messages/incoming/acknack/saa_pacs009_ack_from_swift-unkn-delstat.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildUnknownMessage(inputMsgPayloadStr, "1");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/testUnknownMessageIsAssignedUnkownType-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(scrubbedPayload), StringUtils.normalizeSpace(expectedOutMsgPayloadStr));
  }

  @Test
  @DisplayName("Test build pacs009 message with namespace prefix")
  public void testBuildPacs009MessageWithNamespacePrefix() throws Exception {
    // arrange
    String inputMsgPayloadStr = loadMessage("messages/incoming/09/PACS09-CBPR-Namespace-Prefix.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildGenericMessage(inputMsgPayloadStr, "1",
        "pacs.009.001.08");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/pacs.009.valid-with-namespace-prefix-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(expectedOutMsgPayloadStr), StringUtils.normalizeSpace(scrubbedPayload));
  }

  @Test
  @DisplayName("Test build CAMT message with namespace prefix")
  public void testBuildCAMTMessageWithNamespacePrefix() throws Exception {
    // arrange
    String inputMsgPayloadStr = loadMessage("messages/incoming/camt/saa_camt_057_namespace_prefix.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildGenericMessage(inputMsgPayloadStr, "1",
        "pacs.009.001.08");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/camt.valid-with-namespace-prefix-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(expectedOutMsgPayloadStr), StringUtils.normalizeSpace(scrubbedPayload));
  }

  @Test
  @DisplayName("Test build PACS09 message with mixed namespaces")
  public void testBuildCAMTMessageWithNamespaceMixed() throws Exception {
    // arrange
    String inputMsgPayloadStr = loadMessage(
        "messages/incoming/09/PACS09-CBPR-Namespace-Mixed.xml");

    // act
    String outMessagePayload = smmToHABSMessageBuilder.buildGenericMessage(inputMsgPayloadStr, "1",
        "pacs.009.001.08");
    String scrubbedPayload = scrubSmmMessage(outMessagePayload);

    // assert
    String expectedOutMsgPayloadStr = loadMessage(
        "integration/expected/pacs.009.valid-with-namespace-mixed-expected-output.xml");
    assertEquals(StringUtils.normalizeSpace(expectedOutMsgPayloadStr), StringUtils.normalizeSpace(scrubbedPayload));
  }


  @Bean
  SMMToHABSMessageBuilder smmToHABSMessageBuilder() {
    return new SMMToHABSMessageBuilder(smmInitializer.xmlSourceFactory());
  }

  private String scrubSmmMessage(String payload) {
    // production code should provide the ability to supply Creation Date
    // we scrub it out in the meantime
    return payload.replaceFirst("<CreationDate>.*</CreationDate>",
        "<CreationDate></CreationDate>");
  }

}
