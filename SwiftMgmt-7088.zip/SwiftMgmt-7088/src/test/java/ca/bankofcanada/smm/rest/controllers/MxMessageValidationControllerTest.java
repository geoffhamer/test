package ca.bankofcanada.smm.rest.controllers;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static io.restassured.module.mockmvc.RestAssuredMockMvc.given;
import static io.restassured.module.mockmvc.RestAssuredMockMvc.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import ca.bankofcanada.smm.util.XMLUtil;
import io.restassured.http.ContentType;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.RandomStringUtils;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

class MxMessageValidationControllerTest extends RestControllerBaseTest {

  @Autowired
  private RestExceptionHandler restExceptionHandler;

  @Test
  public void postSimplyReturns200() throws IOException {

    String testFile = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");

    given()
        .body(testFile).
    when().
        post("/api/mx-messages/validations").
    then().
        statusCode( HttpServletResponse.SC_OK );
  }

  @Test
  public void postOfInvalidReturnsOneErrorAnd400() throws IOException {

    String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-invalid-from-HABS.xml");

    given()
        .body(testFile).
    when().
        post("/api/mx-messages/validations").
    then()
        .statusCode( HttpServletResponse.SC_BAD_REQUEST )
        .contentType(ContentType.JSON)
        .body("errors[0].code", Matchers.equalTo(1),
            "errors[0].message", Matchers.stringContainsInOrder("Lynx_Agent_Name_Postal_Address_FormalRule"));

  }

  @Test
  public void postOfInvalidReturnsThreeErrorAnd400() throws IOException {

    String testFile = loadMessage("messages/outgoing/09cov/pacs09COV-outgoing-invalid.xml");

    given()
        .body(testFile).
    when().
        post("/api/mx-messages/validations").
    then()
        .statusCode( HttpServletResponse.SC_BAD_REQUEST )
        .contentType(ContentType.JSON)
        .body("errors[2].code", Matchers.equalTo(1),
            "errors[2].message", Matchers.stringContainsInOrder("Lynx_Party_Name_Any_BIC_FormalRule"));

  }

  @Test
  public void postOfUnparsableRequestReturnsErrorsAnd400() throws IOException {

    String testFile = loadMessage("messages/outgoing/09/pacs.009-outgoing-unparsable-from-HABS.xml");

    given()
        .body(testFile).
    when().
        post("/api/mx-messages/validations").
    then()
        .statusCode( HttpServletResponse.SC_BAD_REQUEST )
        .contentType(ContentType.JSON)
        .body("errors[0].code", Matchers.equalTo(2),
            "errors[0].message", Matchers.stringContainsInOrder("Failed (no date time 'T' delimiter found in data)"));

  }

  @Test
  public void postOfPayloadExceedMaximumSizeReturnsErrorAnd400() throws IOException {
    String testFile = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");
    try (MockedStatic<XMLUtil> xmlUtilsMockedStatic = Mockito.mockStatic(XMLUtil.class)) {
      xmlUtilsMockedStatic.when(() -> XMLUtil.writeObjectToOneLine(any())).thenReturn(
          RandomStringUtils.random(40001));

      given()
          .body(testFile)
      .when()
          .post("/api/mx-messages/validations")
      .then()
          .statusCode(HttpServletResponse.SC_BAD_REQUEST)
          .contentType(ContentType.JSON)
          .body("errors[0].code", Matchers.equalTo(1), "errors[0].message", Matchers.stringContainsInOrder(
              "Message Payload (Business Application Header and Document) is too large. Payload size exceeds maximum limit of 80,000 bytes"));
    }
  }

  @Test
  public void postRequiresRequestBody() {
    when().
        post("/api/mx-messages/validations").
    then().
        statusCode( HttpServletResponse.SC_INTERNAL_SERVER_ERROR );
  }

  @Test
  public void postException() throws Throwable {
    final MxMessageValidationController mockController = Mockito.mock(MxMessageValidationController.class);

    Mockito.when(mockController.validate(anyString())).thenThrow(new RuntimeException("test"));
    given().standaloneSetup(mockController, restExceptionHandler)
        .body("not empty").
    when().
        post("/api/mx-messages/validations").
    then().
        statusCode( HttpServletResponse.SC_INTERNAL_SERVER_ERROR );
  }

  @Test
  public void postOf6DigitsBICRequestReturnsErrorsAnd400() throws IOException {

    String testFile = loadMessage("messages/outgoing/04/pacs004-outgoing-6-digit-invalid-BIC.xml");

    given()
        .body(testFile).
    when().
        post("/api/mx-messages/validations").
    then()
        .statusCode( HttpServletResponse.SC_BAD_REQUEST )
        .contentType(ContentType.JSON)
        .body("errors[0].code", Matchers.equalTo(1),
            "errors[0].message", Matchers.stringContainsInOrder("Receiver BIC must be 8 digits or 11 digits"));

  }
  
}