package ca.bankofcanada.smm.rest.controllers;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.when;

import ca.bankofcanada.smm.config.ErrorCode;
import ca.bankofcanada.smm.exception.ResourceNotFoundException;
import ca.bankofcanada.smm.exception.SAAInterfaceException;
import ca.bankofcanada.smm.models.SAAInterfaceConnection;
import ca.bankofcanada.smm.service.SAAInterfaceService;
import io.restassured.http.ContentType;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Unit/Integration tests for SAAInterfaceController class
 */
public class SAAInterfaceControllerTest extends RestControllerBaseTest {

  @MockBean
  private SAAInterfaceService saaInterfaceService;

  @Test
  @DisplayName("Test successful SAA interface switch POST request")
  public void testValidSwitchToSAAInterface202() throws ResourceNotFoundException, SAAInterfaceException {
    Long interfaceId = 1234L; // Interface ID
    String uri = UriComponentsBuilder.fromPath(SAAInterfaceController.URI_BASE_SAA_INTERFACE_API
            + SAAInterfaceController.INTERFACE_ID_ACTIVATE_SEGMENT)
        .buildAndExpand(interfaceId)
        .toUriString();
    Mockito.doNothing().when(saaInterfaceService).switchToSAAInterface(interfaceId);
    when().
        post(uri).
    then().
        statusCode(HttpServletResponse.SC_ACCEPTED);
  }

  @Test
  @DisplayName("Test invalid/not found Interface Id for SAA interface switch POST request")
  public void testInValidInterfaceIdSwitchToSAAInterface404() throws ResourceNotFoundException, SAAInterfaceException {
    Long interfaceId = 5678L; // Interface ID
    String uri = UriComponentsBuilder.fromPath(SAAInterfaceController.URI_BASE_SAA_INTERFACE_API
            + SAAInterfaceController.INTERFACE_ID_ACTIVATE_SEGMENT)
        .buildAndExpand(interfaceId)
        .toUriString();
    String errorMessage = MessageFormat.format("Resource with ID {0} not found", String.valueOf(interfaceId));
    Mockito.doThrow(new ResourceNotFoundException(errorMessage, null)).when(saaInterfaceService).switchToSAAInterface(interfaceId);
    when().
        post(uri).
        then().
        statusCode(HttpServletResponse.SC_NOT_FOUND)
        .contentType(ContentType.JSON)
        .body("errors[0].code", Matchers.equalTo(ErrorCode.RESOURCE_NOT_FOUND.getValue()),
            "errors[0].message", Matchers.stringContainsInOrder(errorMessage));
  }

  @Test
  @DisplayName("Test Bad Request for SAA interface switch POST request")
  public void testBadRequestSwitchToSAAInterface400() throws ResourceNotFoundException, SAAInterfaceException {
    Long interfaceId = 5678L; // Interface ID
    String uri = UriComponentsBuilder.fromPath(SAAInterfaceController.URI_BASE_SAA_INTERFACE_API
            + SAAInterfaceController.INTERFACE_ID_ACTIVATE_SEGMENT)
        .buildAndExpand(interfaceId)
        .toUriString();
    String errorMessage = "An error occurred";
    Mockito.doThrow(new SAAInterfaceException(errorMessage, null)).when(saaInterfaceService).switchToSAAInterface(interfaceId);
    when().
        post(uri).
        then().
        statusCode(HttpServletResponse.SC_BAD_REQUEST)
        .contentType(ContentType.JSON)
        .body("errors[0].code", Matchers.equalTo(ErrorCode.SAA_INTERFACE_REQUEST_FAILURE.getValue()))
        .body("errors[0].message", Matchers.notNullValue());
  }

  @Test
  @DisplayName("Test successful SAA GET of all interfaces")
  public void testFetchAllSAAInterfaces200() throws SAAInterfaceException {

    String uri = UriComponentsBuilder.fromPath(SAAInterfaceController.URI_BASE_SAA_INTERFACE_API)
        .toUriString();

    List<SAAInterfaceConnection> connections = new ArrayList<>();
    Mockito.doReturn(connections).when(saaInterfaceService).getAllSAAInterfacesWithUpdates();

    when().
        get(uri).
        then().
        statusCode(HttpServletResponse.SC_OK);
  }

}
