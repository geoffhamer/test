package ca.bankofcanada.smm.integration;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.service.PersistenceServiceActivator;
import ca.bankofcanada.smm.service.SwiftMessagePersistService;
import java.util.regex.Pattern;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.test.context.MockIntegrationContext;
import org.springframework.integration.test.context.SpringIntegrationTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

@SpringIntegrationTest(noAutoStartup = {"swiftMessageOut", "swiftMessageIn"})
@ExtendWith(MockitoExtension.class)
@TestPropertySource(value = {"classpath:smm-test.properties"})
public class SwiftIntegrationBaseTest {

  private static final Pattern EOL_PATTERN = Pattern.compile("\\r\\n?");

  @Autowired
  protected MockIntegrationContext mockIntegrationContext;

  @Autowired
  PersistenceServiceActivator persistenceServiceActivator;

  protected SwiftMessagePersistService swiftMessagePersistService;

  @BeforeEach
  public void setupPersistenceMock() {
    if (persistenceServiceActivator == null) {
      return;
    }
    swiftMessagePersistService = Mockito.mock(SwiftMessagePersistService.class);
    ReflectionTestUtils
        .setField(persistenceServiceActivator, "swiftMessagePersistService",
            swiftMessagePersistService);

    Mockito.lenient().when(swiftMessagePersistService.saveSwiftMessage(Mockito.any()))
        .thenAnswer((Answer<SwiftMessage>) invocation -> {
          Object[] args = invocation.getArguments();
          SwiftMessage msg = (SwiftMessage) args[0];
          msg.setMessagePk(1L);
          return msg;
        });
  }

  protected String normalizeEOLs(String string) {
    return EOL_PATTERN.matcher(string).replaceAll("\n");
  }
}
