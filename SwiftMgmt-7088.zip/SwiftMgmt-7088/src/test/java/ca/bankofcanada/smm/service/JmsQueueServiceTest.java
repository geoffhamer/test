package ca.bankofcanada.smm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.bankofcanada.smm.exception.SAAInterfaceException;
import javax.jms.ConnectionFactory;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;

/**
 * Unit tests for JmsQueueService class
 */
public class JmsQueueServiceTest {

  private JmsQueueService jmsQueueService; // Tested class

  private ConnectionFactory mockSmmJmsDSConnFactory;

  private JmsTemplate mockJmsTemplate;

  private JmsTemplateFactory mockJmsTemplateFactory;


  @BeforeEach
  public void setUp() {

    // Mock smmJmsDSConnFactory
    mockSmmJmsDSConnFactory = Mockito.mock(ConnectionFactory.class);

    // Mock JmsTemplate
    mockJmsTemplate = Mockito.mock(JmsTemplate.class);
    Mockito.doNothing().when(mockJmsTemplate).setConnectionFactory(Mockito.any());
    Mockito.doNothing().when(mockJmsTemplate).setDefaultDestinationName(Mockito.any());
    Mockito.doNothing().when(mockJmsTemplate).setReceiveTimeout(Mockito.anyLong());
    Mockito.doNothing().when(mockJmsTemplate).convertAndSend(Mockito.anyString(), Mockito.any(), Mockito.any());

    // Mock the JmsTemplateFactory to return a mock JmsTemplate
    mockJmsTemplateFactory = Mockito.mock(JmsTemplateFactory.class);
    Mockito.when(mockJmsTemplateFactory.createJmsTemplate()).thenReturn(mockJmsTemplate);

    // Create an instance of jmsQueueService with the mock factory
    jmsQueueService = new JmsQueueService(mockSmmJmsDSConnFactory, mockJmsTemplateFactory);
  }

  @Test
  @DisplayName("Test success sendMessage call")
  public void testSendMessage_Success() {
    String queue = "testQueue";
    String message = "Hello!";

    jmsQueueService.sendMessage(queue, message, null);

    // Verify that JmsTemplate methods were called
    Mockito.verify(mockJmsTemplate).setConnectionFactory(Mockito.any(ConnectionFactory.class));
    Mockito.verify(mockJmsTemplate).convertAndSend(Mockito.anyString(), Mockito.any(), Mockito.any(MessagePostProcessor.class));
  }

  @Test
  @DisplayName("Test failure sendMessage call caused by null queue argument")
  public void testSendMessage_InvalidQueue() {
    String queue = null;
    String message = "Hello!";
    String exceptionMessage = "Queue is not specified";

    Exception exception = assertThrows(java.lang.IllegalArgumentException.class, () -> {
      jmsQueueService.sendMessage(queue, message, null);
    });
    assertEquals(exceptionMessage, exception.getMessage());
  }

  @Test
  @DisplayName("Test failure sendMessage call caused by null message argument")
  public void testSendMessage_InvalidMessage() {
    String queue = "testQueue";
    String message = null;
    String exceptionMessage = "Message is null";

    Exception exception = assertThrows(java.lang.IllegalArgumentException.class, () -> {
      jmsQueueService.sendMessage(queue, message, null);
    });
    assertEquals(exceptionMessage, exception.getMessage());
  }
}
