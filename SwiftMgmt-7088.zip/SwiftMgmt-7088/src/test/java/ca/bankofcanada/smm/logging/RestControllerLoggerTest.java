package ca.bankofcanada.smm.logging;

import static ca.bankofcanada.smm.TestUtils.clearRootLog;
import static ca.bankofcanada.smm.TestUtils.getRootLog;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import biz.c24.io.api.ValidationResultEnum;
import biz.c24.io.api.data.ValidationEvent;
import ca.bankofcanada.smm.exception.C24ValidationException;
import ca.bankofcanada.smm.model.MessageLocal;
import java.io.IOException;
import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class RestControllerLoggerTest {

  @Mock(name = "restControllerLoggerJointPoint")
  private JoinPoint joinPoint;
  @Mock(name = "restControllerLoggerSignature")
  private MethodSignature signature;

  private final RestControllerLogger restControllerLogger = new RestControllerLogger();

  @BeforeEach
  public void setup() throws IOException {
    clearRootLog();
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testC24ValidationExceptionLoggedWithErrors() throws Exception {
    // arrange
    when(joinPoint.getSignature()).thenReturn(signature);
    when(signature.toLongString()).thenReturn("testC24ValidationExceptionLoggedWithErrors");
    when(joinPoint.getArgs()).thenReturn(new Object[]{"JoinPoint"});
    MessageLocal messageLocal = new MessageLocal();
    ValidationEvent event1 = new ValidationEvent(messageLocal, ValidationResultEnum.FAILED_FORMAT_ERROR, ValidationResultEnum.FAILED_FORMAT_ERROR.toString());
    ValidationEvent event2 = new ValidationEvent(messageLocal, ValidationResultEnum.FAILED_SYNTAX_NOT_FOUND, ValidationResultEnum.FAILED_SYNTAX_NOT_FOUND.toString());
    ValidationEvent[] validationEventsArr = new ValidationEvent[]{event1, event2};
    C24ValidationException c24ValidationException = new C24ValidationException(Arrays.toString(validationEventsArr), validationEventsArr);

    // act
    restControllerLogger.logResponse(joinPoint, c24ValidationException);

    // assert
    String log = getRootLog();
    assertEquals(System.getProperty("logfile.location"), "local");
    assertTrue(log.contains("testC24ValidationExceptionLoggedWithErrors"));
    assertTrue(log.contains(ValidationResultEnum.FAILED_FORMAT_ERROR.toString()));
    assertTrue(log.contains(ValidationResultEnum.FAILED_SYNTAX_NOT_FOUND.toString()));
  }

}
