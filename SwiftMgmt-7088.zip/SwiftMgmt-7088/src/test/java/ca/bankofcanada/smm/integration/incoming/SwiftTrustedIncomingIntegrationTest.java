package ca.bankofcanada.smm.integration.incoming;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.integration.test.mock.MockIntegration.messageArgumentCaptor;
import static org.springframework.integration.test.mock.MockIntegration.mockMessageHandler;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.MessageTransformationException;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(properties = {"smm.trust.swift=true"})
public class SwiftTrustedIncomingIntegrationTest extends SwiftIncomingIntegrationBaseTest {

  @Test
  @DisplayName("A valid and unsigned MX message, when trusted, generates a clean, error-free SMM message")
  public void validAndUnsigned() throws Exception {

    validateIncomingWithExpectedOutgoing("messages/incoming/08/pacs.008.valid-and-unsigned.xml",
        "integration/expected/pacs.008.valid-and-unsigned.trusted-SMM-output.xml");
  }

  /**
   * NOTE:
   * <p>
   * The following 2 tests (invalidMessageThrowsException and exceptionInErrorChannelGeneratesSmmMessage),
   * while independent of each other, are related. The 1st one simulates throwing an exception
   * (which would be sent to the error channel), and the 2nd one simulates receiving messages on the
   * error channel and proceeding on to generate an SMM message. Both should, ideally, be one
   * continuous test.
   * <p>
   * The reason they are being broken up is that Spring Integration testing cannot simulate
   * providing an alternate message source, for testing, on the message-driven channel adapter,
   * where our error channel is defined -- we have to manually send the message to the channel
   * adapter's designated channel. Hence, for testing, the exception cannot be automatically sent to
   * the error channel.
   * <p>
   * See https://stackoverflow.com/questions/70749849/how-to-test-message-driven-channel-adapter-with-mockintegrationcontext
   */

  @Test
  @DisplayName("An invalid MX message throws a MessageTransformationException")
  public void invalidMessageThrowsException() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/incoming/08/pacs.008.invalid-and-unsigned.xml");

    // act, assert
    assertThrows(MessageHandlingException.class,
        () -> messageChannel.send(MessageBuilder.withPayload(inputMessage).build()));
  }

  @Test
  @DisplayName("A MessageTransformationException sent to the error channel generates an SMM message indicating the thrown error")
  public void exceptionInErrorChannelGeneratesSmmMessage() throws Exception {
    // arrange
    String inputMessage = loadMessage("messages/incoming/08/pacs.008.invalid-and-unsigned.xml");

    Message<?> incomingMessage = MessageBuilder.withPayload(inputMessage)
        .setHeader(SMM_MESSAGE_PK_HEADER_KEY, "1")
        .setHeaderIfAbsent(MESSAGE_TYPE_HEADER_KEY, "pacs.008.001.08").build();
    MessageTransformationException exception = new MessageTransformationException(incomingMessage,
        "This is the error description", new Exception("This is the exception cause"));

    ArgumentCaptor<Message<?>> messageArgumentCaptor = messageArgumentCaptor();
    MessageHandler mockMessageHandler = mockMessageHandler(messageArgumentCaptor)
        .handleNext(m -> {
        });
    mockIntegrationContext.substituteMessageHandlerFor("messageOut", mockMessageHandler);

    // act
    exceptioneChannel.send(MessageBuilder.withPayload(exception).build());
    Message<?> smmMessage = messageArgumentCaptor.getValue();

    // assert
    String expectedMessage = loadMessage(
        "integration/expected/pacs.008.invalid-and-unsigned.SMM-output.xml");
    String actualMessage = scrubSmmMessage(smmMessage);

    assertEquals(normalizeEOLs(expectedMessage), normalizeEOLs(actualMessage));
  }
}
