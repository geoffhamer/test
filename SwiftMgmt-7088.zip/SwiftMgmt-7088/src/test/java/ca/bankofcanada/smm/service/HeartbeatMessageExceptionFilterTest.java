package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.common.CommonConstants.HEARTBEAT_SOURCE_SMM;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

class HeartbeatMessageExceptionFilterTest {

  private final HeartbeatMessageExceptionFilter filter = new HeartbeatMessageExceptionFilter();

  @Test
  void filter_returnsTrue_whenMessageHasNonSmmHeartbeatSourceHeader() {
    Message<?> message = MessageBuilder.withPayload("")
        .setHeader(HEARTBEAT_SOURCE_HEADER_KEY, "FOO")
        .build();

    boolean result = filter.filter(message);

    assertTrue(result);
  }

  @Test
  void filter_returnsTrue_WhenMessageHasNoHeartbeatSourceHeader() {
    Message<?> message = MessageBuilder.withPayload("").build();

    boolean result = filter.filter(message);

    assertTrue(result);
  }

  @Test
  void filter_returnsTrue_whenMessageHasNullHeartbeatSourceHeaderValue() {
    Message<?> message = MessageBuilder.withPayload("")
        .setHeader(HEARTBEAT_SOURCE_HEADER_KEY, null)
        .build();

    boolean result = filter.filter(message);

    assertTrue(result);
  }

  @Test
  void filter_returnsFalse_whenMessageHasSmmHeartbeatSourceHeader() {
    Message<?> message = MessageBuilder.withPayload("")
        .setHeader(HEARTBEAT_SOURCE_HEADER_KEY, HEARTBEAT_SOURCE_SMM)
        .build();

    boolean result = filter.filter(message);

    assertFalse(result);
  }
}
