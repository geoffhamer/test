package ca.bankofcanada.smm.msg;

import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import biz.c24.io.api.C24;
import ca.bankofcanada.smm.config.SaaConfig;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.junit.jupiter.api.Test;

public class OutgoingSAADataPDUTest {

  private final SaaConfig saaConfig = mock(SaaConfig.class);
  private final static Long MOCK_MESSAGE_KEY = 1234L;

  @Test
  public void createOutgoingMXMessage() throws Exception {
    when(saaConfig.getNetworkServiceName("paymentsca.lynx.01")).thenReturn("paymentscanada.lynx!p");
    String inputMessage = loadMessage("messages/outgoing/09/pacs009_outgoing.xml");
    InputStream inputStream = new ByteArrayInputStream(inputMessage.getBytes());
    OutgoingSAADataPDU outgoingMX = OutgoingSAADataPDU.create(MOCK_MESSAGE_KEY, inputStream, saaConfig);
    C24.validate(outgoingMX);
    assertTrue(C24.isValid(outgoingMX));
  }

}
