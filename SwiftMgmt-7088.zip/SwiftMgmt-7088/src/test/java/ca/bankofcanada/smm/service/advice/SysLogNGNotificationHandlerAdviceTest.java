package ca.bankofcanada.smm.service.advice;

import static ca.bankofcanada.smm.TestUtils.clearLog;
import static ca.bankofcanada.smm.TestUtils.getLog;
import static ca.bankofcanada.smm.TestUtils.loadMessage;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import ca.bankofcanada.smm.config.SmmMessageResource;
import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SysLogNGNotificationHandlerAdviceTest.class, SmmMessageResource.class})
public class SysLogNGNotificationHandlerAdviceTest {

  static class SysLogNGNotificationHandlerAdviceMock extends SysLogNGNotificationHandlerAdvice {
    private static final ExecutionCallbackImpl executionCallback = new ExecutionCallbackImpl();
    static class ExecutionCallbackImpl implements ExecutionCallback {

      @Override
      public Object execute() {
        throw new RuntimeException("");
      }

      @Override
      public Object cloneAndExecute() {
        return null;
      }
    }
  }

  static class SysLogNGNotificationHandlerAdviceMock2 extends SysLogNGNotificationHandlerAdvice {
    private static final ExecutionCallbackImpl executionCallback = new ExecutionCallbackImpl();
    static class ExecutionCallbackImpl implements ExecutionCallback {

      @Override
      public Object execute() {
        return null;
      }

      @Override
      public Object cloneAndExecute() {
        return null;
      }
    }
  }

  private static final String sysLogPattern =
      ".* SMM Environment: .* MessageKey: %s Description: %s.*\\s*";

  @Autowired
  private SysLogNGNotificationHandlerAdviceMock sysLogNGNotificationHandlerAdvice;


  @BeforeEach
  public void clear() throws IOException {
    clearLog();
    sysLogNGNotificationHandlerAdvice.setDescriptionKey(null);
    sysLogNGNotificationHandlerAdvice.setDescription(null);
  }

  @Test
  @DisplayName("SysLogNG notification triggered if failed to execute")
  public void testSysLogNgNotificationTriggeredIfFailedToExecuteTrapExceptionFalse() throws IOException {
    sysLogNGNotificationHandlerAdvice.setTrapException(false);
    sysLogNGNotificationHandlerAdvice.setDescription(
        "Incoming Swift Message failed delivery to SWIFT_MX_INQ destination queue. trapException set to false.");
    String inputPayload = loadMessage("messages/incoming/09/PACS09-LYNX-valid.xml");
    Message<?> message = MessageBuilder.withPayload(inputPayload).setHeader(
        SMM_MESSAGE_PK_HEADER_KEY, "12345").build();
    assertThrows(RuntimeException.class, () -> sysLogNGNotificationHandlerAdvice.doInvoke(
        SysLogNGNotificationHandlerAdviceMock.executionCallback, new Object(), message));
    assertTrue(logMatches("12345", "Incoming Swift Message failed delivery to SWIFT_MX_INQ destination queue"));
  }

  @Test
  @DisplayName("SysLogNG notification triggered if failed to execute and trapException set to true")
  public void testSysLogNgNotificationTriggeredIfFailedToExecute() throws IOException {
    sysLogNGNotificationHandlerAdvice.setTrapException(true);
    sysLogNGNotificationHandlerAdvice.setDescription(
        "Incoming Swift Message failed delivery to SWIFT_MX_INQ destination queue");
    Message<?> message = MessageBuilder.withPayload("Test Payload").build();
    sysLogNGNotificationHandlerAdvice.doInvoke(SysLogNGNotificationHandlerAdviceMock.executionCallback, new Object(), message);
    assertTrue(logMatches("UNKNOWN", "Incoming Swift Message failed delivery to SWIFT_MX_INQ destination queue"));
  }

  @Test
  @DisplayName("SysLogNG notification not triggered")
  public void testSysLogNgNotificationNotTriggered() throws IOException {
    sysLogNGNotificationHandlerAdvice.setTrapException(true);
    sysLogNGNotificationHandlerAdvice.setDescription(
        "Incoming Swift Message failed delivery to SWIFT_MX_INQ destination queue");
    Message<?> message = MessageBuilder.withPayload("Test Payload").build();
    sysLogNGNotificationHandlerAdvice.doInvoke(SysLogNGNotificationHandlerAdviceMock2.executionCallback, new Object(), message);
    assertFalse(logMatches("UNKNOWN", "Incoming Swift Message failed delivery to SWIFT_MX_INQ destination queue"));
  }


  /**
   * This serves as a test of creating messages using the resource bundle instead of hard-coded test
   */
  @Test
  @DisplayName("SysLogNG notification triggered using description key")
  public void testSysLogNgNotificationUsingDescriptionKey() throws IOException {
    sysLogNGNotificationHandlerAdvice.setTrapException(true);
    sysLogNGNotificationHandlerAdvice.setDescriptionKey("queue.failure.SWIFT_MX_INQ");
    Message<?> message = MessageBuilder.withPayload("Test Payload").build();
    sysLogNGNotificationHandlerAdvice.doInvoke(SysLogNGNotificationHandlerAdviceMock.executionCallback, new Object(), message);
    assertTrue(logMatches("UNKNOWN", "The following process failed: Enqueue of an incoming message to SWIFT_MX_INQ"));
  }

  @Test
  @DisplayName("SysLogNG notification triggered using another description key")
  public void testSysLogNgNotificationUsingAnotherDescriptionKey() throws IOException {
    sysLogNGNotificationHandlerAdvice.setTrapException(true);
    sysLogNGNotificationHandlerAdvice.setDescriptionKey("queue.failure.SWIFT_SMM_OUTQ");
    Message<?> message = MessageBuilder.withPayload("Test Payload").build();
    sysLogNGNotificationHandlerAdvice.doInvoke(SysLogNGNotificationHandlerAdviceMock.executionCallback, new Object(), message);
    assertTrue(getLog().contains("The following process failed: Enqueue of an outgoing message to SWIFT_SMM_OUTQ"));
  }

  @Test
  @DisplayName("SysLogNG notification triggered using a description key that doesn't exist")
  public void testSysLogNgNotificationUsingUnknownDescriptionKey() throws IOException {
    sysLogNGNotificationHandlerAdvice.setTrapException(true);
    sysLogNGNotificationHandlerAdvice.setDescriptionKey("non-existant.message.key");
    Message<?> message = MessageBuilder.withPayload("Test Payload").build();
    sysLogNGNotificationHandlerAdvice.doInvoke(SysLogNGNotificationHandlerAdviceMock.executionCallback, new Object(), message);
    assertTrue(logMatches("UNKNOWN", "No resource message found with key: non-existant.message.key"));
  }

  @Bean
  SysLogNGNotificationHandlerAdviceMock sysLogNGNotificationHandlerAdvice() {
    return new SysLogNGNotificationHandlerAdviceMock();
  }

  private boolean logMatches(String msgKey, String description) throws IOException {
    String pattern = String.format(sysLogPattern, msgKey, description);
    String log = getLog();
    return log.matches(pattern);
  }

}
