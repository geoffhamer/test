package ca.bankofcanada.smm.config;

import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Configuration
@ConfigurationProperties(prefix = "smm.heartbeat")
@Validated
public class HeartbeatProperties {

  /**
   * Whether to have scheduled SMM heartbeats enabled or not. Default is disabled.
   */
  private boolean enable = false;

  /**
   * The delay, in milliseconds, to allow between heartbeat messages. Default is 1 minute.
   */
  @Positive
  private int delay = 60_000;

  /**
   * The Bank Identifier Code (BIC) to use when sending a heartbeat message to SAA. Default is
   * BCANCAW0XXX.
   */
  @Size(min = 8, max = 11)
  private String bic = "BCANCAW0XXX";

  public boolean isEnabled() {
    return enable;
  }

  public void setEnable(boolean enable) {
    this.enable = enable;
  }

  public int getDelay() {
    return delay;
  }

  public void setDelay(int delay) {
    this.delay = delay;
  }

  public String getBic() {
    return bic;
  }

  public void setBic(String bic) {
    this.bic = bic;
  }

}
