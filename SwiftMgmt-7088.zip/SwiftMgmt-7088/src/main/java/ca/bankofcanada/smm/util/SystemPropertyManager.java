package ca.bankofcanada.smm.util;

import org.springframework.stereotype.Component;

/**
 * Utility class allowing to manage System property
 * Note: Only created for test mocking as it is not possible to mock static methods of java.lang.System
 *       to avoid interfering with class loading what leads to infinite loops
 */
@Component
public class SystemPropertyManager {

  public String getProperty(String key) {
    return System.getProperty(key);
  }
}
