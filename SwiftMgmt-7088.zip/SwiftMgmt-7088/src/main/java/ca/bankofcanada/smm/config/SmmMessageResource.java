package ca.bankofcanada.smm.config;

import javax.annotation.PostConstruct;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * A wrapper for the Smm resource bundles message source
 *
 * This class allows for access to the message source from static methods which is often the case
 * in producing log messages.
 *
 * NOTE: At this time the only resource bundle we are using is a 'bilingual' one where both English
 * and French text is returned in a single string. If there is a future requirement for localized
 * messages, this class should be expanded to manage them as well.
 */
@Configuration
public class SmmMessageResource {

  public final static String RESOURCE_BUNDLE_BASENAME = "messages";

  private static SmmMessageResource staticInstance;

  private MessageSource bilingualMessageSource;


  /**
   * Load the messages.properties resource bundle found in the /resources dir.
   */
  @PostConstruct
  private void init() {

    ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
    messageSource.setBasename(RESOURCE_BUNDLE_BASENAME);

    this.bilingualMessageSource = messageSource;
    SmmMessageResource.staticInstance = this;

  }


  public MessageSource getBilingualMessageSource() {
    return staticInstance.bilingualMessageSource;
  }


  /**
   * Access to a static instance of the class
   *
   * @return An instance of the SmmMessageResource class that can be accessed in static methods
   */
  public static SmmMessageResource getInstance() {
    return staticInstance;
  }

}
