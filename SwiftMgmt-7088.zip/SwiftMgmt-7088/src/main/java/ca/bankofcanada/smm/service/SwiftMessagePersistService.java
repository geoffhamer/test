package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.repositories.SwiftMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SwiftMessagePersistService {

  @Autowired
  private SwiftMessageRepository swiftMessageRepository;

  public SwiftMessage saveSwiftMessage(SwiftMessage swiftMessage) {
    SwiftMessage saveMsg = swiftMessageRepository.saveAndFlush(swiftMessage);
    return saveMsg;
  }
}
