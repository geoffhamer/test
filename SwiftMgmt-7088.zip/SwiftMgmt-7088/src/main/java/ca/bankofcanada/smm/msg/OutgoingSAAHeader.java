package ca.bankofcanada.smm.msg;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ValidationException;
import org.apache.commons.lang3.StringUtils;
import swift.saa.xsd.saa.x2.x0.AddressFullName;
import swift.saa.xsd.saa.x2.x0.AddressInfo;
import swift.saa.xsd.saa.x2.x0.AddressInfo.AddressInfoSG1;
import swift.saa.xsd.saa.x2.x0.Header;
import swift.saa.xsd.saa.x2.x0.InterfaceInfo;
import swift.saa.xsd.saa.x2.x0.Message;
import swift.saa.xsd.saa.x2.x0.NetworkInfo;
import swift.saa.xsd.saa.x2.x0.SWIFTNetNetworkInfo;

/**
 * This class complies with the Header Specification defined in SAA 7.6.20 configuration guide
 */
public class OutgoingSAAHeader extends Header {

  private static final int SHORT_BIC_LENGTH = 8;
  private static final int FULL_BIC_LENGTH = 11;
  private static final String DEFAULT_BRANCH_CODE = "XXX";
  
  protected OutgoingSAAHeader(Builder builder) {
    super.addElement("Message", builder.message);
  }

  public static IMessageIdentifier builder() {
    return new Builder();
  }

  interface IMessageIdentifier {

    ISender withMessageIdentifier(String messageIdentifier);
  }

  interface ISender {

    IReceiver withSender(String fullName);
  }

  interface IReceiver {

    ISenderReference withReceiver(String fullName);
  }

  interface ISenderReference {

    INetworkInfo withBTPKFromHABS(String btPkFromHABS);
  }


  interface INetworkInfo {

    IRequestTypeInfo withNetworkInfo(String service);
  }

  interface IRequestTypeInfo {

    IOnBuild withRequestSubtypeInfo(String requestSubtype);
  }

  interface IOnBuild {

    OutgoingSAAHeader build() throws ValidationException;
  }

  static class Builder implements ISenderReference, IMessageIdentifier, ISender, IReceiver,
      INetworkInfo, IRequestTypeInfo, IOnBuild {

    protected final Message message;

    protected Builder() {
      this.message = new Message();
    }

    @Override
    public ISender withMessageIdentifier(String messageIdentifier) {
      this.message.addElement("MessageIdentifier", messageIdentifier);
      this.message.addElement("Format", "MX");
      return this;
    }

    @Override
    public IReceiver withSender(String fullName) {
      checkBICLength(fullName, "Sender BIC must be 8 digits or 11 digits.");
      this.message.addElement("Sender", createAddressInfo(fullName));
      return this;
    }

    @Override
    public ISenderReference withReceiver(String fullName) {
      checkBICLength(fullName, "Receiver BIC must be 8 digits or 11 digits.");
      this.message.addElement("Receiver", createAddressInfo(fullName));
      return this;
    }

    @Override
    public INetworkInfo withBTPKFromHABS(String btPkFromHABS) {
      String senderReference = this.message.getSender().getFullName().getX1() + "$" + btPkFromHABS;
      this.message.addElement("SenderReference", senderReference);
      InterfaceInfo interfaceInfo = new InterfaceInfo();
      interfaceInfo.addElement("UserReference", btPkFromHABS);
      this.message.addElement("InterfaceInfo", interfaceInfo);
      return this;
    }

    @Override
    public IRequestTypeInfo withNetworkInfo(String service) {
      NetworkInfo networkInfo = new NetworkInfo();
      networkInfo.addElement("Service", service);
      this.message.addElement("NetworkInfo", networkInfo);
      return this;
    }

    @Override
    public IOnBuild withRequestSubtypeInfo(String requestSubtype) {
      NetworkInfo networkInfo = this.message.getNetworkInfo();
      SWIFTNetNetworkInfo swiftNetNetworkInfo = networkInfo.createNetworkInfoSG1().createSWIFTNetNetworkInfo();
      swiftNetNetworkInfo.addElement("RequestType", this.message.getMessageIdentifier());
      swiftNetNetworkInfo.addElement("RequestSubtype", requestSubtype);
      return this;
    }

    @Override
    public OutgoingSAAHeader build() throws ValidationException {
      OutgoingSAAHeader header = new OutgoingSAAHeader(this);
      C24.validate(header);
      return header;
    }

    private void checkBICLength(String fullName, String msg) {
      int length = StringUtils.length(fullName);
      if (length != FULL_BIC_LENGTH && length != SHORT_BIC_LENGTH) {
        throw new IllegalArgumentException(msg);
      }
    }
    
    private AddressInfo createAddressInfo(String fullName) {
      if (StringUtils.length(fullName) == SHORT_BIC_LENGTH) {
        fullName = fullName + DEFAULT_BRANCH_CODE;
      }
      AddressInfo.AddressInfoSG1 addressInfoSG1 = new AddressInfoSG1();
      String fullDN = "ou=" + fullName.substring(SHORT_BIC_LENGTH, FULL_BIC_LENGTH).toLowerCase() //
          + ",o=" + fullName.substring(0, SHORT_BIC_LENGTH).toLowerCase() + ",o=swift"; //
      addressInfoSG1.addElement("DN", fullDN);
      AddressFullName addressFullName = new AddressFullName();
      addressFullName.addElement("X1", fullName);
      AddressInfo addressInfo = new AddressInfo();
      addressInfo.addElement("AddressInfo-SG1", addressInfoSG1);
      addressInfo.addElement("FullName", addressFullName);
      return addressInfo;
    }
  }

}
