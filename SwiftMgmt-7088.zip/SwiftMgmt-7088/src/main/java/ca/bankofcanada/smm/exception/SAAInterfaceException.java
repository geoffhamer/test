package ca.bankofcanada.smm.exception;


public class SAAInterfaceException extends Exception {

  public SAAInterfaceException(String message, Throwable cause) {
    super(message, cause);
  }

}
