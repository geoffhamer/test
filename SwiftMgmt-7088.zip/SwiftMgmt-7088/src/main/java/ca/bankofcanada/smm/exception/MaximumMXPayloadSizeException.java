package ca.bankofcanada.smm.exception;

public class MaximumMXPayloadSizeException extends Exception {

  public MaximumMXPayloadSizeException(String message) {
    super(message);
  }

}
