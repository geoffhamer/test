package ca.bankofcanada.smm.service;

import biz.c24.io.api.C24;
import biz.c24.io.api.ParserException;
import ca.bankofcanada.smm.config.ErrorCode;
import ca.bankofcanada.smm.logging.SysLogNGLog;
import ca.bankofcanada.smm.model.ErrorListType;
import ca.bankofcanada.smm.model.ErrorType;
import ca.bankofcanada.smm.model.MessageLocal;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.NotImplementedException;
import swift.saa.xsd.saa.x2.x0.SAA_XML_v2_0DocumentRoot;

/**
 * This class is used to process different exceptions.
 *
 * @author River He
 */
enum MessageFlowExceptionProcessor {

  ParserException("biz.c24.io.api.ParserException") {
    @Override
    void processIncomingException(Throwable rootCause, MessageLocal smmMessage, String originalMessageStr) {
      List<Object> errorList = new ArrayList<>(Arrays.asList(((biz.c24.io.api.ParserException) rootCause).getErrors()));
      smmMessage.getHeader().setErrorList(populateErrorsWithKey(errorList, ErrorCode.STRUCTURE_VALIDATION));
      parseOriginalIncomingMessage(originalMessageStr, smmMessage);
    }
  },

  ApsecException("ca.bankofcanada.common.security.apsec.ApsecException") {
    @Override
    void processIncomingException(Throwable rootCause, MessageLocal smmMessage, String originalMessageStr) {
      List<Object> errorList = new ArrayList<>();
      errorList.add(rootCause);
      smmMessage.getHeader().setErrorList(populateErrorsWithKey(errorList, ErrorCode.SIGNATURE_VALIDATION));
      parseOriginalIncomingMessage(originalMessageStr, smmMessage);
    }
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.ApsecException");
    }
  },

  UnparsableSMMMessageException("ca.bankofcanada.smm.exception.UnparsableSMMMessageException") {
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.UnparsableSMMMessageException");
    }
  },

  MaximumMXPayloadSizeException("ca.bankofcanada.smm.exception.MaximumMXPayloadSizeException") {
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.MaximumMXPayloadSizeException");
    }
  },

  SAADataPDUException("ca.bankofcanada.smm.exception.SAADataPDUException") {
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.SAADataPDUException");
    }
  },

  SMMPersistenceException("ca.bankofcanada.smm.exception.SMMPersistenceException") {
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.SMMPersistenceException");
    }
  },

  C24ValidationException("ca.bankofcanada.smm.exception.C24ValidationException") {
    @Override
    void processIncomingException(Throwable rootCause, MessageLocal smmMessage, String originalMessageStr) {
      List<Object> errorList = new ArrayList<>(((ca.bankofcanada.smm.exception.C24ValidationException) rootCause).getValidationEventList());
      smmMessage.getHeader().setErrorList(populateErrorsWithKey(errorList, ErrorCode.RULES_VALIDATION));
      parseOriginalIncomingMessage(originalMessageStr, smmMessage);
    }
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.C24ValidationException");
    }
  },

  RuntimeException("java.lang.RuntimeException") {
    @Override
    void processIncomingException(Throwable rootCause, MessageLocal smmMessage, String originalMessageStr) {
      List<Object> errorList = new ArrayList<>();
      errorList.add(rootCause);
      smmMessage.getHeader().setErrorList(populateErrorsWithKey(errorList, ErrorCode.OTHER));
      parseOriginalIncomingMessage(originalMessageStr, smmMessage);
    }
    @Override
    void processOutgoingException(String messageKey){
      SysLogNGLog.triggerNotificationWithResourceKey(messageKey, "exception.description.RuntimeException");
    }
  };

  private final String canonicalName;
  private static final Map<String, MessageFlowExceptionProcessor> canonicalNameToEnum = Stream.of(
      values()).collect(Collectors.toMap(Object::toString, e -> e));

  private static final String OUTGOING_DESC_PREFIX = "SMM was unable to send the outgoing SWIFT message. The following process failed: ";

  MessageFlowExceptionProcessor(String canonicalName){
    this.canonicalName = canonicalName;
  }

  void processIncomingException(Throwable rootCause, MessageLocal smmMessage, String originalMessageStr) {
    throw new NotImplementedException("method not implemented");
  }

  void processOutgoingException(String messageKey) {
    throw new NotImplementedException("method not implemented");
  }

  /**
   * This method is used to retrieve the enum class by canonicalName
   *
   * @param canonicalName The canonical name of the class.
   * @return The enum instance with the specific name.
   */
  public static MessageFlowExceptionProcessor getByExceptionCanonicalName(String canonicalName){
    return canonicalNameToEnum.getOrDefault(canonicalName, RuntimeException);
  }

  /**
   * This method attempts to extract the AppHdr and Document elements from the original message
   * (using a StringReader) so they can be included in the Body of the SmmMessage being sent to
   * HABS.
   *
   * If the attempt to parse original message fails (due to structure errors in the SAA envelope)
   * it is added to SmmMessage body as escaped XML
   *
   * @param originalMessageStr String representation of the original message
   * @param smmMessage The SmmMessage containing errors send to HABS.
   */
  private static void parseOriginalIncomingMessage(String originalMessageStr, MessageLocal smmMessage) {
    StringReader reader = new StringReader(originalMessageStr);
    try {
      SAA_XML_v2_0DocumentRoot xmlV2Root = C24.parse(SAA_XML_v2_0DocumentRoot.class, reader);
      if (xmlV2Root.getDataPDU().getBody() != null) {
        Object appHdr = xmlV2Root.getDataPDU().getBody().getElement("AppHdr");
        Object document = xmlV2Root.getDataPDU().getBody().getElement("Document");
        smmMessage.getBody().addElement("any", appHdr);
        smmMessage.getBody().addElement("any", document);
      } else {
        smmMessage.getBody().addElement("any", xmlV2Root.getDataPDU());
      }
    } catch (ParserException pEx) {
      smmMessage.getBody().addElement("any", originalMessageStr.replaceAll("\\r\\n?", "\n"));
    } catch (Exception exp) {
      smmMessage.getHeader().setErrorList(
          populateErrorsWithKey(Collections.singletonList(exp.getMessage()), ErrorCode.OTHER));
      smmMessage.getBody().addElement("any", originalMessageStr.replaceAll("\\r\\n?", "\n"));
    }
  }

  /**
   * A method to generate an ErrorList element that is added to the SmmMessage header
   *
   * @param errorList A list of errors generated during passage through SMM
   * @param errorCode The message type associated with the errors
   * @return an ErrorListType element containing the list of errors
   */
  private static ErrorListType populateErrorsWithKey(List<Object> errorList, ErrorCode errorCode) {
    ErrorListType errorListType = new ErrorListType();
    errorList.forEach(errObj -> {
      ErrorType errorType = new ErrorType();
      errorType.setErrorCode(errorCode.getValue());
      errorType.setErrorMessage(Objects.toString(errObj));
      errorListType.addError(errorType);
    });
    return errorListType;
  }

  @Override
  public String toString(){
    return this.canonicalName;
  }
}
