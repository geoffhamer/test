package ca.bankofcanada.smm.msg;

import swift.saa.xsd.saa.x2.x0.NetworkInfo;
import swift.saa.xsd.saa.x2.x0.SWIFTNetNetworkInfo;

public class AdmiOutgoingSAAHeader extends OutgoingSAAHeader {

  private AdmiOutgoingSAAHeader(AdmiBuilder builder) {
    super(builder);
  }

  public static IMessageIdentifier builder() {
    return new AdmiBuilder();
  }

  static class AdmiBuilder extends Builder {

    @Override
    public IOnBuild withRequestSubtypeInfo(String requestSubtype) {
      NetworkInfo networkInfo = this.message.getNetworkInfo();
      SWIFTNetNetworkInfo swiftNetNetworkInfo = networkInfo.createNetworkInfoSG1().createSWIFTNetNetworkInfo();
      swiftNetNetworkInfo.addElement("RequestType", this.message.getMessageIdentifier());
      return this;
    }
  }
}
