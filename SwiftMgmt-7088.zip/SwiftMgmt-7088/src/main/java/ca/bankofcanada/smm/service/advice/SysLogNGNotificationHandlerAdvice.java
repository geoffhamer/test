package ca.bankofcanada.smm.service.advice;

import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;

import ca.bankofcanada.smm.logging.SysLogNGLog;
import java.util.Objects;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.handler.advice.AbstractRequestHandlerAdvice;
import org.springframework.messaging.Message;

/**
 * <p>
 * This class is used to log an entry with SysLogNG if exceptions thrown during execution and write
 * an error log to the full xml log file.
 *
 * @author River He
 */
public class SysLogNGNotificationHandlerAdvice extends AbstractRequestHandlerAdvice {

  private final static Logger logger = Logger.getLogger(LoggingHandler.class.getCanonicalName());
  private boolean trapException = false;
  private String description;

  private String descriptionKey;

  public void setTrapException(boolean trapException) {
    this.trapException = trapException;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setDescriptionKey(String descriptionKey) {
    this.descriptionKey = descriptionKey;
  }

  @Override
  protected Object doInvoke(ExecutionCallback callback, Object target, Message<?> message) {
    try {
      return callback.execute();
    } catch (RuntimeException runtimeException) {
      //logger.getName() is required here to bypass the CustomMessageRollingFileAppender check when writing to file
      logger.error(logger.getName() + " - SysLogNGNotificationHandlerAdvice\n" + ExceptionUtils.getStackTrace(runtimeException));
      String messageKey = null;
      if(message.getHeaders().containsKey(SMM_MESSAGE_PK_HEADER_KEY)){
        messageKey = Objects.toString(message.getHeaders().get(SMM_MESSAGE_PK_HEADER_KEY));
      }

      // Attempt to populate the description using a resource bundle key. Otherwise just use provided description string.
      if (this.descriptionKey != null) {
        SysLogNGLog.triggerNotificationWithResourceKey(messageKey, this.descriptionKey);
      } else {
        SysLogNGLog.triggerNotification(messageKey, this.description);
      }

      if (!this.trapException) {
        throw runtimeException;
      } else {
        return null;
      }
    }
  }
}
