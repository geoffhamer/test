package ca.bankofcanada.smm.repositories;

import ca.bankofcanada.smm.entity.SystemInterfaceNodeSummary;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SystemInterfaceNodeRepository extends JpaRepository<SystemInterfaceNodeSummary, Long> {

  /**
   * Custom query retrieving from SYSTEM_INTERFACE_NODE and CODE_TABLE the required data for the
   * System Interface Node matching to the given pk
   * @param pk
   * @return Optional with requested SystemInterfaceNodeSummary if it exists
   */
  @Query(value = "SELECT s.SYSTEM_INTERFACE_NODE_PK as pk, " +
          "c_name.CODE_CONSTANT_ID AS idName, " +
          "c_name.ATTRIBUTE_EN_NAME AS nameEn, " +
          "c_name.ATTRIBUTE_FR_NAME AS nameFr, " +
          "c_name.ATTRIBUTE_EN_DESC AS descEn, " +
          "c_name.ATTRIBUTE_FR_DESC AS descFr, " +
          "CASE c_status.CODE_CONSTANT_ID " +
          "  WHEN :activeIn THEN :activeOut " +
          "  WHEN :inactiveIn THEN :inactiveOut " +
          "  WHEN :inprogIn THEN :inprogOut " +
          "  ELSE :unknownOut " +
          "END " +
          "AS status, " +
          "s.OPTLOCK AS optLock, " +
          "c_type.CODE_CONSTANT_ID AS type, " +
          "c_bank_site.CODE_CONSTANT_ID AS bankSite, " +
          "s.SWITCH_SCRIPT_NAME AS switchScriptName, " +
          "s.SWITCH_RESULT AS switchResult, " +
          "CASE " +
          "  WHEN s.APPLICATION_UPDATE_TIMESTAMP IS NULL THEN (timestamp '1970-1-1 00:00:00') " +
          "  ELSE s.APPLICATION_UPDATE_TIMESTAMP "+
          "END as lastUpdateTimestamp, "+
          "s.AUDIT_LAST_UPDATE_DATE AS lastUpdateDate, " +
          "s.AUDIT_LAST_UPDATE_USER AS lastUpdateBy " +
          "FROM SYSTEM_INTERFACE_NODE s " +
          "JOIN CODE_TABLE c_name ON c_name.CODE_PK = s.SYSTEM_INTERFACE_NODE_PK " +
          "JOIN CODE_TABLE c_status ON c_status.CODE_PK = s.INTERFACE_NODE_STATUS_FK " +
          "JOIN CODE_TABLE c_type ON c_type.CODE_PK = s.SYSTEM_INTERFACE_TYPE_FK " +
          "JOIN CODE_TABLE c_bank_site ON c_bank_site.CODE_PK = s.BANK_SITE_FK " +
          "WHERE s.SYSTEM_INTERFACE_NODE_PK = :pk", nativeQuery = true)
  Optional<SystemInterfaceNodeSummary> findSystemInterfaceNodeByPk(
      @Param("pk") Long pk,
      @Param("activeIn") String activeVal,
      @Param("activeOut") String activeName,
      @Param("inactiveIn") String inactiveVal,
      @Param("inactiveOut") String inactiveName,
      @Param("inprogIn") String inprogVal,
      @Param("inprogOut") String inprogName,
      @Param("unknownOut") String unknownName
  );

  /**
   * Custom query retrieving all System interfaces Nodes with the given type i.e 'Swift'
   *
   * @param type
   * @return
   */
  @Query(value = "SELECT s.SYSTEM_INTERFACE_NODE_PK as pk, " +
      "c_name.CODE_CONSTANT_ID AS idName, " +
      "c_name.ATTRIBUTE_EN_NAME AS nameEn, " +
      "c_name.ATTRIBUTE_FR_NAME AS nameFr, " +
      "c_name.ATTRIBUTE_EN_DESC AS descEn, " +
      "c_name.ATTRIBUTE_FR_DESC AS descFr, " +
      "CASE c_status.CODE_CONSTANT_ID " +
      "  WHEN :activeIn THEN :activeOut " +
      "  WHEN :inactiveIn THEN :inactiveOut " +
      "  WHEN :inprogIn THEN :inprogOut " +
      "  ELSE :unknownOut " +
      "END " +
      "AS status, " +
      "s.OPTLOCK AS optLock, " +
      "c_type.CODE_CONSTANT_ID AS type, " +
      "c_bank_site.CODE_CONSTANT_ID AS bankSite, " +
      "s.SWITCH_SCRIPT_NAME AS switchScriptName, " +
      "s.SWITCH_RESULT AS switchResult, " +
      "CASE " +
      "  WHEN s.APPLICATION_UPDATE_TIMESTAMP IS NULL THEN (timestamp '1970-1-1 00:00:00') " +
      "  ELSE s.APPLICATION_UPDATE_TIMESTAMP "+
      "END as lastUpdateTimestamp, "+
      "s.AUDIT_LAST_UPDATE_DATE AS lastUpdateDate, " +
      "s.AUDIT_LAST_UPDATE_USER AS lastUpdateBy " +
      "FROM SYSTEM_INTERFACE_NODE s " +
      "JOIN CODE_TABLE c_name ON c_name.CODE_PK = s.SYSTEM_INTERFACE_NODE_PK " +
      "JOIN CODE_TABLE c_status ON c_status.CODE_PK = s.INTERFACE_NODE_STATUS_FK " +
      "JOIN CODE_TABLE c_type ON c_type.CODE_PK = s.SYSTEM_INTERFACE_TYPE_FK " +
      "JOIN CODE_TABLE c_bank_site ON c_bank_site.CODE_PK = s.BANK_SITE_FK " +
      "WHERE c_type.CODE_CONSTANT_ID = :type", nativeQuery = true)
  List<SystemInterfaceNodeSummary> findByType(
     @Param("type") String type,
     @Param("activeIn") String activeVal,
     @Param("activeOut") String activeName,
     @Param("inactiveIn") String inactiveVal,
     @Param("inactiveOut") String inactiveName,
     @Param("inprogIn") String inprogVal,
     @Param("inprogOut") String inprogName,
     @Param("unknownOut") String unknownName
  );

  /**
   * Update the status of a System Interface Node for a given pk
   * The required status code is retrieved based on the given Code Category
   *
   * @param pk PK of a System Interface Node to update
   * @param status string representing the status to set
   * @param categoryName category name is required so the Status PK is unique
   * @return number of rows updated (1 in case of success)
   */
  @Modifying
  @Query(value = "UPDATE SYSTEM_INTERFACE_NODE s " +
      "SET s.INTERFACE_NODE_STATUS_FK = ( " +
      "   SELECT code.CODE_PK " +
      "   FROM CODE_TABLE code " +
      "   JOIN CODE_CATEGORY_TABLE cat ON code.CODE_CATEGORY_FK = cat.CODE_CATEGORY_PK " +
      "   WHERE code.CODE_CONSTANT_ID = :status " +
      "      AND cat.ATTRIBUTE_EN_NAME = :categoryName ), " +
      "s.APPLICATION_UPDATE_TIMESTAMP = (SELECT SYSTIMESTAMP FROM DUAL), " +
      "s.OPTLOCK = s.OPTLOCK + 1 " +
      "WHERE s.SYSTEM_INTERFACE_NODE_PK = :pk", nativeQuery = true)
  int updateStatusByPkAndStatusAndCategory(@Param("pk") Long pk,
                                           @Param("status") String status,
                                           @Param("categoryName") String categoryName);


  /**
   * Update the status and the switchResult of a System Interface Node for a given pk
   *
   * @param pk PK of a System Interface Node to update
   * @param status string representing the status to set
   * @param switchResult string to set for the switchResult, can be null
   * @param categoryName category name is required so the Status PK is unique
   * @return number of rows updated (1 in case of success)
   */
  @Modifying
  @Query(value = "UPDATE SYSTEM_INTERFACE_NODE s " +
      "SET s.INTERFACE_NODE_STATUS_FK = ( " +
      "   SELECT code.CODE_PK " +
      "   FROM CODE_TABLE code " +
      "   JOIN CODE_CATEGORY_TABLE cat ON code.CODE_CATEGORY_FK = cat.CODE_CATEGORY_PK " +
      "   WHERE code.CODE_CONSTANT_ID = :status " +
      "      AND cat.ATTRIBUTE_EN_NAME = :categoryName ), " +
      "s.SWITCH_RESULT = :switchResult, " +
      "s.APPLICATION_UPDATE_TIMESTAMP = (SELECT SYSTIMESTAMP FROM DUAL), " +
      "s.OPTLOCK = s.OPTLOCK + 1 " +
      "WHERE s.SYSTEM_INTERFACE_NODE_PK = :pk", nativeQuery = true)
  int updateStatusAndSwitchResultByPkAndStatusAndCategory(@Param("pk") Long pk,
      @Param("status") String status,
      @Param("switchResult") String switchResult,
      @Param("categoryName") String categoryName);

  /**
   * Update the status for ALL the System Interface Nodes having the given current state
   *
   * @param currentStatus string representing the current status to filter the System Interface Nodes
   * @param newStatus string representing the status to set for the filtered  System Interface Nodes
   * @param categoryName category name is required so the Status PK is unique
   * @return number of rows updated (1 in case of success)
   */
  @Modifying
  @Query(value = "UPDATE SYSTEM_INTERFACE_NODE s " +
      "SET s.INTERFACE_NODE_STATUS_FK = ( " +
      "   SELECT code.CODE_PK " +
      "   FROM CODE_TABLE code " +
      "   JOIN CODE_CATEGORY_TABLE cat ON code.CODE_CATEGORY_FK = cat.CODE_CATEGORY_PK " +
      "   WHERE code.CODE_CONSTANT_ID = :newStatus " +
      "      AND cat.ATTRIBUTE_EN_NAME = :categoryName ), " +
      "s.APPLICATION_UPDATE_TIMESTAMP = (SELECT SYSTIMESTAMP FROM DUAL), " +
      "s.OPTLOCK = s.OPTLOCK + 1 " +
      "WHERE s.SYSTEM_INTERFACE_NODE_PK IN ( " +
      "  SELECT s2.SYSTEM_INTERFACE_NODE_PK " +
      "  FROM SYSTEM_INTERFACE_NODE s2 " +
      "  JOIN CODE_TABLE c ON c.CODE_PK = s2.INTERFACE_NODE_STATUS_FK " +
      "  WHERE c.CODE_CONSTANT_ID = :currentStatus)", nativeQuery = true)
  int replaceStatusesByStatusAndCategory(@Param("currentStatus") String currentStatus,
      @Param("newStatus") String newStatus,
      @Param("categoryName") String categoryName);
}