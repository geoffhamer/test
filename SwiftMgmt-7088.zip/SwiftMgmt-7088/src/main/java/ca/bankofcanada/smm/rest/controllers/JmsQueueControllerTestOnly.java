package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.service.JmsQueueService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.jms.JMSException;
import javax.jms.TextMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/for-testing-purposes-only")
@Profile({"local", "dev", "qa"})
public class JmsQueueControllerTestOnly {

  private static final Logger logger = LoggerFactory.getLogger(
      JmsQueueControllerTestOnly.class);

  public final static Map<String, String> JMS_QUEUES = Stream.of(new String[][]{
      {"SWIFT_SMM_INQ", "swift to SMM"},
      {"SWIFT_MX_INQ", "SMM to consumers"},
      {"SWIFT_SMM_OUTQ", "SMM to SWIFT"},
      {"SWIFT_MX_OUTQ", "Consumers to SMM"},
      {"SWITCH_INTERFACE_Q", "SMM to AMOS WEB"}
  }).collect(Collectors.toMap(data -> data[0], data -> data[1]));

  // No idea why we can't use JMS_QUEUES.toString() here. I have tried a few things but none of it works in the annotation
  private final static String JMS_QUEUES_DOC = "Possible Queue values are: \n "
      + "* `SWIFT_SMM_INQ  -> Swift to SMM` \n"
      + "* `SWIFT_MX_INQ   -> SMM to consumers` \n"
      + "* `SWIFT_SMM_OUTQ -> SMM to Swift` \n"
      + "* `SWIFT_MX_OUTQ  -> Consumers to SMM` \n"
      + "* `SWITCH_INTERFACE_Q  -> SMM to AMOS WEB` \n";

  private final JmsQueueService jmsQueueService;

  @Autowired
  public JmsQueueControllerTestOnly(JmsQueueService jmsQueueService) {
    this.jmsQueueService = jmsQueueService;
  }

  @Operation(description = "Allows you to post a message in a queue. " + JMS_QUEUES_DOC,
      parameters = {
      @Parameter(
          in = ParameterIn.PATH,
          name = "queue",
          schema = @Schema(allowableValues = {"SWIFT_SMM_INQ", "SWIFT_MX_INQ", "SWIFT_SMM_OUTQ", "SWIFT_MX_OUTQ", "SWITCH_INTERFACE_Q"}))})
  @PostMapping(path = "/queues/{queue}/messages", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<String> uploadFileAsMessageToQueue(
      @PathVariable("queue") String queue,
      @Parameter(name = "file", description = "A file containing the message content") MultipartFile file,
      @Parameter(required = false, name="jmsHeaderFields", description = "A JMS header to pass in") String[] jmsHeaderFields,
      @Parameter(required = false, name="jmsHeaderValues", description = "The value of the JMS header to pass in") String[] jmsHeaderValues) throws IOException  {
    // Validate Queue
    if (!JMS_QUEUES.containsKey(queue)) {
      return new ResponseEntity<>(
          "Invalid Queue Name specified: " + queue + ". Valid values are: " + JMS_QUEUES.toString(),
          HttpStatus.BAD_REQUEST);
    }

    // Validate JMS Headers
    // if either is not null AND  (one is null or they are not the same size) return error
    if ((jmsHeaderFields != null || jmsHeaderValues != null)
      && ((jmsHeaderFields != null && jmsHeaderValues == null)
        || (jmsHeaderFields == null && jmsHeaderValues != null)
        || (jmsHeaderFields.length != jmsHeaderValues.length))) {
      return new ResponseEntity<>(
          "You must specify the same number of jmsHeaderFields and jmsHeaderValues",
          HttpStatus.BAD_REQUEST);
    }

    Map<String, Object> headers = new HashMap<>();
    for (int x = 0; jmsHeaderFields != null && x < jmsHeaderFields.length; x++) {
      headers.put(jmsHeaderFields[x], jmsHeaderValues[x]);
    }

    String message = new BufferedReader(
        new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))
        .lines()
        .collect(Collectors.joining("\n"));

    logger.debug("Sending message...");
    jmsQueueService.sendMessage(queue, message, headers);

    return new ResponseEntity<>(
        "Message has been uploaded",
        HttpStatus.OK);
  }

  @Operation(description = "Allows you to view all message in a queue. " + JMS_QUEUES_DOC,
      parameters = {
      @Parameter(
          in = ParameterIn.PATH,
          name = "queue",
          schema = @Schema(allowableValues = {"SWIFT_SMM_INQ", "SWIFT_MX_INQ", "SWIFT_SMM_OUTQ", "SWIFT_MX_OUTQ", "SWITCH_INTERFACE_Q"}))})
  @GetMapping(value = "/queues/{queue}/messages", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<SimpleTextMessage>> listMessageInQueue(
      @PathVariable("queue") String queue) throws IOException, JMSException {

    // Validate Queue
    if (!JMS_QUEUES.containsKey(queue)) {
      return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
    }

    StringBuffer response = new StringBuffer();
    List<TextMessage> messages = jmsQueueService.listMessagesOnQueue(queue);
    if (messages != null) {
      // for some odd reason serializing a TextMessage is not a trivial task. Simplifying
      return new ResponseEntity<>(messages.stream().map(stm -> new SimpleTextMessage(stm))
          .collect(Collectors.toList()), HttpStatus.OK);
    } else {
      return new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
    }
  }

  @Operation(description = "Allows you to delete all messages in a queue. " + JMS_QUEUES_DOC,
      parameters = {
          @Parameter(
              in = ParameterIn.PATH,
              name = "queue",
              schema = @Schema(allowableValues = {"SWIFT_SMM_INQ", "SWIFT_MX_INQ", "SWIFT_SMM_OUTQ", "SWIFT_MX_OUTQ", "SWITCH_INTERFACE_Q"}))})
  @DeleteMapping("/queues/{queue}/messages")
  public ResponseEntity<String> deleteMessageInQueue(
      @PathVariable("queue") String queue) throws IOException {

    // Validate Queue
    if (!JMS_QUEUES.containsKey(queue)) {
      return new ResponseEntity<>(
          "Invalid Queue Name specified: " + queue + ". Valid values are: " + JMS_QUEUES.toString(),
          HttpStatus.BAD_REQUEST);
    }

    int numberOfMessages = jmsQueueService.deleteAllMessages(queue);
    return new ResponseEntity<>(numberOfMessages + " message(s) have been removed from queue: " + queue,
        HttpStatus.OK);
  }


  /**
   * Serializing a java.jms.TextMessage is causing grief because of the implementation we are
   * using which are using vectors and have non implemented abstract methods.  In order to avoid
   * those inconvenients, until we migrate to newer better tech, we are using this simple wrapper
   * class.  We are also converting JMSException into runtime exception.  This is after all, testing
   * code only.
   */
  class SimpleTextMessage {
    private String text;
    private String correlationId;
    private String messageId;
    private long timestamp;
    SimpleTextMessage(TextMessage tm) {
      try {
        this.text = tm.getText();
        this.messageId = tm.getJMSMessageID();
        this.timestamp = tm.getJMSTimestamp();
        this.correlationId = tm.getJMSCorrelationID();
      } catch (JMSException jmse) {
        throw new RuntimeException(jmse.getMessage());
      }
    }

    public String getText() {
      return text;
    }
    public long getTimestamp() {
      return timestamp;
    }
    public String getMessageId() {
      return messageId;
    }
    public String getCorrelationId() {
      return correlationId;
    }
  }
}
