package ca.bankofcanada.smm.validation;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ComplexDataObject;
import biz.c24.io.api.data.Element;
import biz.c24.io.api.data.ValidationEvent;
import biz.c24.io.api.presentation.Source;
import biz.c24.io.spring.source.XmlSourceFactory;
import ca.bankofcanada.smm.exception.C24ValidationException;
import ca.bankofcanada.smm.exception.MaximumMXPayloadSizeException;
import ca.bankofcanada.smm.exception.UnparsableSMMMessageException;
import ca.bankofcanada.smm.model.SmmMessageDocumentRoot;
import ca.bankofcanada.smm.util.XMLUtil;
import java.io.StringReader;
import java.util.Arrays;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import swift.saa.xsd.saa.x2.x0.SwAny;

/**
 * <p>
 * This class validates payload passed from /api/mx-messages/validations rest call or the outgoing flow
 * <p>
 * Notes: <br> HABS should always call SMM endpoint /api/mx-messages/validations to validate the
 * outgoing message before dropping the message onto the SWIFT_MX_OUT.Q.
 *
 * @author River He
 */
@Component("outMessageValidator")
public class SMMToSwiftValidator {

  private static final int MAX_PAYLOAD_SIZE = 80000;
  private final XmlSourceFactory xmlSourceFactory;

  public SMMToSwiftValidator(XmlSourceFactory xmlSourceFactory) {
    this.xmlSourceFactory = xmlSourceFactory;
  }

  /**
   * This method validates passed payload
   *
   * @param payload The request payload (Constructed SAA Header + Body)
   * @return The original payload if validation succeeded.
   * @throws Exception if any exception during validation process
   *
   */
  public String validate(String payload) throws Exception {
    // Step#1 - validate if payload is parsable using the SmmMessage model
    SmmMessageDocumentRoot cdo = validateStructure(payload);

    // Step#2 - validate if AppHdr + Document exceeds size limit
    //        - determine the message type so correct validation class is used
    validateAppHdrAndDocSize(cdo);

    // Object must be parsable by SmmOutgoingValidationModelDocumentRoot
    SmmOutgoingValidationModelDocumentRoot validationCdo;
    try {
      Source validationSource = xmlSourceFactory.getSource(new StringReader(payload));
      validationCdo = C24.parse(SmmOutgoingValidationModelDocumentRoot.class).from(validationSource);
    } catch (Exception exception) {
      throw new UnparsableSMMMessageException(exception.getMessage());
    }

    // Step#3 validate if any business rules are violated (Using SmmOutgoingValidationModelDocumentRoot model parsed object)
    ValidationEvent[] validationEvents = C24.validateFully(validationCdo);

    // No ValidationEvent is populated if validation is successful
    if (validationEvents != null) {
      throw new C24ValidationException(Arrays.toString(validationEvents), validationEvents);
    }
    return payload;
  }

  /**
   * This method attempts to parse given outgoing payload
   * @param payload Either fully constructed (SAA Header + Body) or MessageLocal object
   * @return Parsed SmmMessageDocumentRoot object
   */
  public SmmMessageDocumentRoot validateStructure(String payload) {
    try {
      Source source = xmlSourceFactory.getSource(new StringReader(payload));
      return C24.parse(SmmMessageDocumentRoot.class).from(source);
    } catch (Exception exception) {
      throw new UnparsableSMMMessageException(exception.getMessage());
    }
  }

  private void validateAppHdrAndDocSize(SmmMessageDocumentRoot cdo) throws Exception {
    SwAny body = cdo.getDataPDU().getBody();

    StringBuilder appHdrAndDocOneLiner = new StringBuilder();
    int count = body.getTotalElementCount();
    for (int i = 0; i < count; i++) {
      // For SwAny, the first elementDecl is always "any", skip it and start from the second one
      Element elementDecl = body.getElementDecl(i + 1);
      appHdrAndDocOneLiner.append(
          XMLUtil.writeObjectToOneLine((ComplexDataObject) body.getElement(elementDecl.getName())));
    }

    int bahAndDocSize = appHdrAndDocOneLiner.toString().length();
    if (bahAndDocSize > MAX_PAYLOAD_SIZE) {
      throw new MaximumMXPayloadSizeException("Message Payload (Business Application Header and Document) is too large. Payload size exceeds maximum limit of 80,000 bytes");
    }
  }

}
