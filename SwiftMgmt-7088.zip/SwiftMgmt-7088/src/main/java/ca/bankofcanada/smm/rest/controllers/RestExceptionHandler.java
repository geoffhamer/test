package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.config.ErrorCode;
import ca.bankofcanada.smm.exception.C24ValidationException;
import ca.bankofcanada.smm.exception.DatabaseException;
import ca.bankofcanada.smm.exception.MaximumMXPayloadSizeException;
import ca.bankofcanada.smm.exception.ResourceNotFoundException;
import ca.bankofcanada.smm.exception.SAADataPDUException;
import ca.bankofcanada.smm.exception.SAAInterfaceException;
import ca.bankofcanada.smm.exception.UnparsableSMMMessageException;
import ca.bankofcanada.smm.rest.dto.SMMError;
import ca.bankofcanada.smm.rest.dto.SMMResponse;
import ca.bankofcanada.smm.rest.dto.ValidationsResponse;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.EntityNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice
public class RestExceptionHandler {

  /**
   *
   * @param exception UnparsableSMMMessageException when C24 fails to parse messages from HABS
   * @return ValidationsResponse with http code 400
   */
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(value = {UnparsableSMMMessageException.class})
  protected ValidationsResponse handleParsingException(Exception exception) {
    ValidationsResponse response = new ValidationsResponse();

    SMMError smmError = createSMMError(ErrorCode.STRUCTURE_VALIDATION,
        exception.getMessage());
    response.getErrors().add(smmError);

    return response;
  }

  /**
   *
   * @param exception MaximumMXPayloadSizeException when BAT + Document exceeded maximum size (80000 bytes)
   *                  SAADataPDUException if failed to construct SAA envelope
   * @return ValidationsResponse with http code 400
   */
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(value = {MaximumMXPayloadSizeException.class, SAADataPDUException.class})
  protected ValidationsResponse handlePayloadSizeException(Exception exception) {
    ValidationsResponse response = new ValidationsResponse();

    SMMError smmError = createSMMError(ErrorCode.RULES_VALIDATION, exception.getMessage());
    response.getErrors().add(smmError);

    return response;
  }

  /**
   *
   * @param exception MethodArgumentTypeMismatchException user provides invalid parameters
   * @return ValidationsResponse with http code 400
   */
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(value = {MethodArgumentTypeMismatchException.class})
  protected ValidationsResponse handleInvalidArgumentException(MethodArgumentTypeMismatchException exception) {
    ValidationsResponse response = new ValidationsResponse();

    SMMError smmError = createSMMError(ErrorCode.INVALID_ARGUMENTS, exception.getMessage());
    response.getErrors().add(smmError);

    return response;
  }

  /**
   *
   * @param exception C24ValidationException when C24 fails to validate message from HABS
   * @return ValidationsResponse with http code 400
   */
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  @ExceptionHandler(value = {C24ValidationException.class})
  protected ValidationsResponse handleValidationException(C24ValidationException exception) {
    ValidationsResponse response = new ValidationsResponse();

    List<SMMError> errorList = new LinkedList<>();

    exception.getValidationEventList().forEach(event -> {
      // Construct SMMError. The event.toString() is used because it include both the element
      // in error and the error message.
      SMMError smmError = createSMMError(ErrorCode.RULES_VALIDATION, event.toString());
      errorList.add(smmError);
    });

    response.setErrors(errorList);

    return response;
  }

  /**
   *
   * @param exception ca.bankofcanada.smm.exception.DatabaseException will be handled here
   * @return SMMResponse with http code 500
   */
  @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
  @ExceptionHandler(value = {DatabaseException.class})
  protected SMMResponse handleDatabaseException(DatabaseException exception) {
    SMMResponse smmResponse = new SMMResponse();

    // Extract the Exception classname and message to create SMMError
    String message = "Database Problem:\n" + exception.getMessage();
    // Add the error to the SMMResponse (Error code = "-1")
    SMMError error = createSMMError(ErrorCode.DATABASE_ACCESS, message);
    smmResponse.getErrors().add(error);

    return smmResponse;
  }

  /**
   *
   * @param exception All other exceptions will be handled here
   * @return SMMResponse with http code 500
   */
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler(value = {Throwable.class})
  protected SMMResponse handleException(Throwable exception) {
    SMMResponse smmResponse = new SMMResponse();

    // Extract the Exception classname and message to create SMMError
    String message = exception.getClass().getSimpleName() + ":" + exception.getMessage();
    // Add the error to the SMMResponse (Error code = "99")
    SMMError error = createSMMError(ErrorCode.OTHER, message);
    smmResponse.getErrors().add(error);

    return smmResponse;
  }

  @ExceptionHandler(EntityNotFoundException.class)
  protected ResponseEntity<Object> handleEntityNotFound(
      EntityNotFoundException ex) {
    return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
  }

  /**
   *
   * @param exception ResourceNotFoundException user provided an unknown resource ID
   * @return SMMResponse with http code 404
   */
  @ExceptionHandler(ResourceNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  public SMMResponse handleResourceNotFoundException(ResourceNotFoundException exception) {
    SMMResponse response = new SMMResponse();

    SMMError smmError = createSMMError(ErrorCode.RESOURCE_NOT_FOUND, exception.getMessage());
    response.getErrors().add(smmError);

    return response;
  }

  /**
   *
   * @param exception SAAInterfaceException
   * @return SMMResponse with http code 400
   */
  @ExceptionHandler(SAAInterfaceException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public SMMResponse handleSAAInterfaceException(SAAInterfaceException exception) {
    SMMResponse response = new SMMResponse();

    SMMError smmError = createSMMError(ErrorCode.SAA_INTERFACE_REQUEST_FAILURE, exception.getMessage());
    response.getErrors().add(smmError);

    return response;
  }


  private SMMError createSMMError(ErrorCode errorCode, String errorMsg){
    SMMError error = new SMMError();
    error.setCode(errorCode.getValue());
    error.setMessage(errorMsg);
    return error;
  }
}
