package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.entity.Heartbeat;
import ca.bankofcanada.smm.repositories.HeartbeatRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HeartbeatService {

  private final HeartbeatRepository repository;

  @Autowired
  public HeartbeatService(HeartbeatRepository repository) {
    this.repository = repository;
  }

  public Optional<Heartbeat> getHeartbeat() {
    List<Heartbeat> heartbeats = repository.findAll();

    if (heartbeats.size() > 1) {
      throw new IllegalStateException(
          "More than one heartbeat record should not exist, but found: " + heartbeats.size());
    }

    // A heartbeat may not have been submitted yet, so default to returning an empty optional as no
    // record will exist in the database.
    Optional<Heartbeat> result = Optional.empty();
    if (!heartbeats.isEmpty()) {
      result = Optional.of(heartbeats.get(0));
    }

    return result;
  }

  public Heartbeat save(Heartbeat heartbeat) {
    return repository.save(heartbeat);
  }

}
