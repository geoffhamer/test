package ca.bankofcanada.smm.logging;

import java.util.Objects;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.spi.LoggingEvent;

public class CustomMessageRollingFileAppender extends RollingFileAppender {

  private static final String DEFAULT_LOGGING_HANDLER_NAME = "org.springframework.integration.handler.LoggingHandler";


  @Override
  protected void subAppend(LoggingEvent event) {
    String message = Objects.toString(event.getMessage());

    // skip payload for debug logging except for default LoggingHandler
    if(!message.contains(DEFAULT_LOGGING_HANDLER_NAME)){
      String msgHeaders = StringUtils.substringBetween(message, "headers={", "}");
      if (msgHeaders != null) {
        message = StringUtils.substringBefore(message, "GenericMessage [payload=") + "headers={"
            + msgHeaders + "}";
      }
    }

    LoggingEvent modifiedEvent = new LoggingEvent(event.getFQNOfLoggerClass(), event.getLogger(),
        event.getTimeStamp(), event.getLevel(), message, event.getThreadName(),
        event.getThrowableInformation(), event.getNDC(), event.getLocationInformation(),
        event.getProperties());
    super.subAppend(modifiedEvent);
  }

}
