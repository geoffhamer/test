package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.exception.SMMPersistenceException;
import ca.bankofcanada.smm.msg.SwiftMessageFactory;
import java.util.Objects;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("outgoingMessagePostProcessor")
public class OutgoingMessagePostProcessor extends SMMBaseServiceActivator {

  private final static String xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";

  private final SwiftMessagePersistService swiftMessagePersistService;
  private final SwiftMessageFactory messageFactory;

  public OutgoingMessagePostProcessor(SwiftMessagePersistService swiftMessagePersistService,
      SwiftMessageFactory messageFactory) {
    this.swiftMessagePersistService = swiftMessagePersistService;
    this.messageFactory = messageFactory;
  }

  public Message<?> dispatchMessageToDestinationQueue(Message<?> m) throws SMMPersistenceException {
    String messageType = Objects.toString(m.getHeaders().get(OUTGOING_MESSAGE_TYPE_HEADER_KEY));

    // admi.004.001.02 bypass persistence
    if (!MESSAGETYPE_ADMI_004.equals(messageType)) {
      SwiftMessage swiftMessage = messageFactory.createOutgoingMessage(m.getPayload().toString());
      try {
        swiftMessagePersistService.saveSwiftMessage(swiftMessage);
      } catch (Exception exp) {
        throw new SMMPersistenceException(exp.getMessage());
      }
    }

    /*
     * This extra XML declaration is the same as the default XML declaration.
     * It is added at the beginning of the message because SOA AQ adaptor will remove the default XML declaration once it receives the message.
     * Without this extra XML declaration, the message passes through SOA BPEL process will arrive at SAA without default XML declaration.
     * SAA is unable to process XML messages without the default XML declaration.
     */
    String msgout = xmlHeader + m.getPayload().toString();
    return MessageBuilder.withPayload(msgout).copyHeaders(m.getHeaders()).build();
  }
}