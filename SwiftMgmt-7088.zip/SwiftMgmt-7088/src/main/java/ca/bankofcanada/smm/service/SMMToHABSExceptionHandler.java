package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.PERSISTENCE_ERROR_PK;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_TYPE_UNKNOWN;

import ca.bankofcanada.smm.model.MessageLocal;
import java.util.GregorianCalendar;
import java.util.Objects;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;

/**
 * This class handles exceptions thrown on the SAA->HABS flow.
 *
 * @author River He
 */
@Component
public class SMMToHABSExceptionHandler {

  private static final Logger logger = Logger.getLogger(SMMToHABSExceptionHandler.class.getCanonicalName());

  /**
   * This method converts exceptions to MessageLocal object
   *
   * @param exception MessageException thrown on the SAA->HABS flow.
   * @return The constructed payload (MessageLocal object)
   */
  public Message<String> handleException(MessagingException exception) {
    Message<?> originalMessage = Objects.requireNonNull(exception.getFailedMessage());
    MessageHeaders originalHeaders = originalMessage.getHeaders();

    String messageType = SMM_MESSAGE_TYPE_UNKNOWN;
    String messagePk = String.valueOf(PERSISTENCE_ERROR_PK);
    if (originalHeaders.containsKey(SMM_MESSAGE_PK_HEADER_KEY)) {
      messagePk = Objects.toString(originalHeaders.get(SMM_MESSAGE_PK_HEADER_KEY));
    }

    if (originalHeaders.containsKey(MESSAGE_TYPE_HEADER_KEY)) {
      messageType = Objects.toString(originalHeaders.get(MESSAGE_TYPE_HEADER_KEY));
    }
    String originalMessageStr = Objects.toString(originalMessage.getPayload());

    MessageLocal smmMessage = new MessageLocal();
    smmMessage.createHeader();
    smmMessage.createBody();

    smmMessage.getHeader().setCreationDate((new GregorianCalendar()).getTime());
    smmMessage.getHeader().setMessageKey(messagePk);
    smmMessage.getHeader().setMessageType(messageType);

    Throwable rootCause = ExceptionUtils.getRootCause(exception);
    MessageFlowExceptionProcessor.getByExceptionCanonicalName(rootCause.getClass().getCanonicalName())
        .processIncomingException(rootCause, smmMessage, originalMessageStr);
    logger.error(smmMessage.toString() + "\n" + ExceptionUtils.getStackTrace(rootCause));
    return MessageBuilder.withPayload(smmMessage.toString()).copyHeaders(originalHeaders).build();
  }
}
