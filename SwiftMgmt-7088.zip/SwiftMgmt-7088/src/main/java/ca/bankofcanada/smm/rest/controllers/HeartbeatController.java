package ca.bankofcanada.smm.rest.controllers;


import ca.bankofcanada.smm.service.SAAHeartbeatService;
import ca.bankofcanada.smm.service.SMMToSwiftHeartbeatBuilder;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/heartbeats/saa/messages")
public class HeartbeatController {

  private final SAAHeartbeatService saaHeartbeatService;
  private final SMMToSwiftHeartbeatBuilder heartbeatBuilder;

  @Autowired
  public HeartbeatController(SAAHeartbeatService saaHeartbeatService,
      SMMToSwiftHeartbeatBuilder heartbeatBuilder) {
    this.saaHeartbeatService = saaHeartbeatService;
    this.heartbeatBuilder = heartbeatBuilder;
  }

  @PostMapping
  @Operation(description = "Submit a heartbeat message unconditionally")
  public ResponseEntity<String> submitHeartbeatMessage() {
    String message = heartbeatBuilder.buildSmmAdmi004Message();
    saaHeartbeatService.submitHeartbeatMessageUnconditionally(message);
    return new ResponseEntity<>(
        "Heartbeat message has been sent",
        HttpStatus.ACCEPTED);
  }
}
