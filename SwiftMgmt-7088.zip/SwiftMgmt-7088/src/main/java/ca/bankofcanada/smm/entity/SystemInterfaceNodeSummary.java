package ca.bankofcanada.smm.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;
import java.sql.Timestamp;

/**
 * Basic representation of a SystemInterfaceNodeSummary retrieved by custom SQL
 * This represents only attributes needed by SMM and does not include all the attributes from
 * the SYSTEM_INTERFACE_NODE table
 * its main purpose is read and update data from the SYSTEM_INTERFACE_NODE table NOT TO CREATE
 * new entries in this table
 */
@Entity
public class SystemInterfaceNodeSummary implements Serializable {
  @Id
  // SYSTEM_INTERFACE_NODE_PK column
  private Long pk;

  // Code String mapped to "SYSTEM_INTERFACE_NODE_PK" column
  private String idName;

  // Code String mapped to "ATTRIBUTE_EN_NAME" column
  private String nameEn;

  // Code String mapped to "ATTRIBUTE_FR_NAME" column
  private String nameFr;

  // Code String mapped to "ATTRIBUTE_EN_DESC" column
  private String descEn;

  // Code String mapped to "ATTRIBUTE_FR_DESC" column
  private String descFr;

  // Code String mapped to "INTERFACE_NODE_STATUS_FK" column converted to API format
  private String status;

  @Version
  // OPTLOCK column
  private Long optLock;

  // Code String mapped to "SYSTEM_INTERFACE_TYPE_FK" column
  private String type;

  // Code String mapped to "BANK_SITE_FK" column
  private String bankSite;

  // SWITCH_SCRIPT_NAME column
  private String switchScriptName;

  // SWITCH_RESULT column
  private String switchResult;

  // APPLICATION_UPDATE_TIMESTAMP column
  private Timestamp lastUpdateTimestamp;

  // AUDIT_LAST_UPDATE_DATE column
  private Date lastUpdateDate;

  // AUDIT_LAST_UPDATE_USER column
  private String lastUpdateBy;


  /**
   * Setters and getters
   */
  public Long getPk() {
    return pk;
  }

  public void setPk(Long pk) {
    this.pk = pk;
  }

  public String getIdName() {
    return idName;
  }

  public void setIdName(String idName) {
    this.idName = idName;
  }

  public String getNameEn() {
    return nameEn;
  }

  public void setNameEn(String nameEn) {
    this.nameEn = nameEn;
  }

  public String getNameFr() {
    return nameFr;
  }

  public void setNameFr(String nameFr) {
    this.nameFr = nameFr;
  }

  public String getDescEn() {
    return descEn;
  }

  public void setDescEn(String descEn) {
    this.descEn = descEn;
  }

  public String getDescFr() {
    return descFr;
  }

  public void setDescFr(String descFr) {
    this.descFr = descFr;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Long getOptLock() {
    return optLock;
  }

  public void setOptLock(Long optlock) {
    this.optLock = optlock;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getBankSite() {
    return bankSite;
  }

  public void setBankSite(String bankSite) {
    this.bankSite = bankSite;
  }

  public String getSwitchScriptName() {
    return switchScriptName;
  }

  public void setSwitchScriptName(String switchScriptName) {
    this.switchScriptName = switchScriptName;
  }

  public String getSwitchResult() {
    return switchResult;
  }

  public void setSwitchResult(String switchResult) {
    this.switchResult = switchResult;
  }

  public Timestamp getLastUpdateTimestamp() {
    return lastUpdateTimestamp;
  }

  public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
    this.lastUpdateTimestamp = lastUpdateTimestamp;
  }

  public Date getLastUpdateDate() {
    return lastUpdateDate;
  }

  public void setLastUpdateDate(Date lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
  }

  public String getLastUpdateBy() {
    return lastUpdateBy;
  }

  public void setLastUpdateBy(String lastUpdateBy) {
    this.lastUpdateBy = lastUpdateBy;
  }
}
