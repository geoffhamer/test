package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.config.HeartbeatProperties;
import ca.bankofcanada.smm.entity.Heartbeat;
import ca.bankofcanada.smm.logging.SysLogNGLog;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.stereotype.Component;

/**
 *  Adds a customized SAA health check component to the health check endpoint (Spring Boot's health actuator)
 *  Endpoint: /actuator/health
 */
@Component
public class SAAHealthIndicator extends AbstractHealthIndicator {
  private static final String MESSAGE_KEY = "message";
  private final long maxHealthyTimeDifferenceMs;
  private final HeartbeatService heartbeatService;

  @Autowired
  public SAAHealthIndicator(HeartbeatService heartbeatService, HeartbeatProperties heartbeatProperties) {
    this.heartbeatService = heartbeatService;
    this.maxHealthyTimeDifferenceMs = heartbeatProperties.getDelay() + 5_000L;
  }

  @Override
  public void doHealthCheck(Builder builder) throws Exception {
    Optional<Heartbeat> smmHeartbeatOpt = heartbeatService.getHeartbeat();

    if (!smmHeartbeatOpt.isPresent()
        || (smmHeartbeatOpt.get().getLastSentTimestamp() == null)
        || (smmHeartbeatOpt.get().getLastReceivedTimestamp() == null)) {
      builder.unknown()
          .withDetail(MESSAGE_KEY, "SAA may NOT be available. No successful connectivity "
              + "verification on record as of yet");
      return;
    }

    Heartbeat smmHeartbeat = smmHeartbeatOpt.get();
    Timestamp lastSentTimestamp = smmHeartbeat.getLastSentTimestamp();
    Timestamp lastReceivedTimestamp = smmHeartbeat.getLastReceivedTimestamp();
    long timeDifferenceMs = Math.abs(lastReceivedTimestamp.getTime() - lastSentTimestamp.getTime());

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssz");
    String lastSentTimestampFormatted = sdf.format(lastSentTimestamp);
    String lastReceivedTimestampFormatted = sdf.format(lastReceivedTimestamp);

    if (timeDifferenceMs <= maxHealthyTimeDifferenceMs) {
      builder.up()
          .withDetail(MESSAGE_KEY,
              "SAA is available." + getConnectivityMessage(lastReceivedTimestampFormatted));
    } else {
      builder.unknown()
          .withDetail(MESSAGE_KEY,
              "SAA may NOT be available." + getConnectivityMessage(lastReceivedTimestampFormatted));

      SysLogNGLog.triggerNotificationWithResourceKey("SMM-SAA Heartbeat",
          "health.saa.unresponsiveHeartbeatOnOpenBusinessDay");
    }

  builder.withDetail("heartbeatLastSent", lastSentTimestampFormatted)
      .withDetail("heartbeatLastReceived", lastReceivedTimestampFormatted);
  }

  private String getConnectivityMessage(String timestamp) {
    return " Last successful connectivity verification was done on: " + timestamp;
  }
}
