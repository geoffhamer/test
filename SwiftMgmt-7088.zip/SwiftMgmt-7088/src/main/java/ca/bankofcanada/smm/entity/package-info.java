/**
 * The module contains the entities that represent tables on the database.
 *
 * <p>Some columns that would appear on the database are omitted from the entities for simplicity
 * reasons as not all fields of the models are needed for the application. Generally, these fields
 * are specific to tables that the HABS project has constructed. Some examples of this are:
 * <ul>
 *   <li>{@link ca.bankofcanada.smm.entity.SwiftMessage}</li>
 *   <li>{@link ca.bankofcanada.smm.entity.SystemInterfaceNodeSummary}</li>
 * </ul>
 *
 * <p>Entity relationships (e.g. 1:1 relationships) have been omitted for simplicity in scenarios
 * where it would be cumbersome to define the entity classes as the entity classes are not
 * directly required within SMM. Instead of entity relationships, just the data type of the foreign
 * key is defined (e.g. INSTRUCTION_FK would correspond to an Instruction entity, but it has been
 * left as the type on the database: a BIGINT). Some examples of this are:
 * <ul>
 *   <li>{@link ca.bankofcanada.smm.entity.BusinessCycle}</li>
 *   <li>{@link ca.bankofcanada.smm.entity.Heartbeat}</li>
 * </ul>
 */
package ca.bankofcanada.smm.entity;