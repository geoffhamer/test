package ca.bankofcanada.smm.logging;

import ca.bankofcanada.smm.config.SmmMessageResource;
import java.util.Locale;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;

public class SysLogNGLog {

  //Get a specific logger that outputs logs in a separate file that will be monitor by Syslog ng
  private static final Logger logger = Logger.getLogger("sysLogNG");

  /**
   * A message source that contains both English and French messages in a single string
   */
  private static MessageSource bilingualMessageSource;


  /**
   * Triggers a SyslogNG notification with the specified Message Key and Description text
   *
   * @param messageKey The message key to be used in the log entry.
   * @param description The description to be used in the log entry.
   */
  public static void triggerNotification(String messageKey, String description) {

    String msgKey = "UNKNOWN";
    if (messageKey != null) {
      msgKey = messageKey;
    }

    log("MessageKey: " + msgKey + " Description: " + description);
  }


  /**
   * Triggers a SysLogNG notifications using messages found in the messages.properties
   * resource bundle.
   *
   * @param messageKey The message key to be used in the log entry.
   * @param resourceKey The key used to find the text in the resource bundle
   */
  public static void triggerNotificationWithResourceKey(String messageKey, String resourceKey) {

    triggerNotification(messageKey, getResourceMessage(resourceKey));
  }


  private static void log(String message) {
    //Syslog NG requires logs to be single line, so make sure we don't output a newline
    logger.error(message.replaceAll("([\\r\\n])", ""));
  }


  /**
   * Method to fetch text from the resource bundles using the provided key.
   *
   * If the local static instance of the message resource hasn't been initialized, it will be
   * fetched from the SmmMessageResource and set.
   *
   * @param resourceKey The key to the resource text
   * @return The resource text
   */
  private static String getResourceMessage( String resourceKey ) {

    String resourceString;

    // Set the message source if it hasn't been already
    if (bilingualMessageSource == null) {
      bilingualMessageSource = SmmMessageResource.getInstance().getBilingualMessageSource();
    }

    try {
      resourceString = bilingualMessageSource.getMessage( resourceKey, null, Locale.getDefault());
    } catch (NoSuchMessageException ex) {
      resourceString = "No resource message found with key: " + resourceKey;
    }

    return resourceString;
  }

}
