package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;

import ca.bankofcanada.smm.config.SaaConfig;
import ca.bankofcanada.smm.exception.SAADataPDUException;
import ca.bankofcanada.smm.msg.OutgoingSAADataPDU;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.IOUtils;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@Component
public class SMMToSwiftMessageBuilder {

  private final SaaConfig saaConfig;

  public SMMToSwiftMessageBuilder(SaaConfig saaConfig) {
    this.saaConfig = saaConfig;
  }

  public String createSMMToSwiftMXMessage(String payload,
      @Header(SMM_MESSAGE_PK_HEADER_KEY) String messageKey) {
    try (InputStream inputStream = IOUtils.toInputStream(payload, StandardCharsets.UTF_8)) {
      OutgoingSAADataPDU outgoingMX = OutgoingSAADataPDU.create(Long.parseLong(messageKey),
          inputStream, saaConfig);
      return outgoingMX.toString();
    } catch (Exception exp) {
      throw new SAADataPDUException(exp.getMessage());
    }
  }

}
