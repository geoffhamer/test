package ca.bankofcanada.smm.msg;

import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ComplexDataObject;
import biz.c24.io.api.data.NamespaceMapping;
import biz.c24.io.api.data.ValidationException;
import ca.bankofcanada.smm.config.SaaConfig;
import ca.bankofcanada.smm.model.MessageLocal;
import java.io.IOException;
import java.io.InputStream;
import swift.saa.xsd.saa.x2.x0.DataPDU;
import swift.saa.xsd.saa.x2.x0.SAA_XML_v2_0DataModel;
import swift.saa.xsd.saa.x2.x0.SwAny;

public class OutgoingSAADataPDU extends DataPDU {

  // SAA DatPDU fields, complies with SAA_XML_v2 urn:swift:saa:xsd:saa.2.0
  private static final String SAA_REVISION = "2.0.14";
  private static final String ANY_ELEMENT = "any";
  private static final String SAA_DATAPDU_PREFIX = "Saa";
  private static final String SAA_DATAPDU_APPHDR = "AppHdr";
  private static final String SAA_DATAPDU_APPHDR_PREFIX = "";
  private static final String SAA_DATAPDU_DOCUMENT = "Document";
  private static final String SAA_DATAPDU_DOCUMENT_PREFIX = "";


  // extraction sources, complies with urn:iso:std:iso:20022:tech:xsd:head.001.001.02
  private static final String[] SENDER_EXTRACTION_SRC = new String[]{SAA_DATAPDU_APPHDR, "Fr", "FIId",
      "FinInstnId", "BICFI"};
  private static final String[] RECEIVER_EXTRACTION_SRC = new String[]{SAA_DATAPDU_APPHDR, "To", "FIId",
      "FinInstnId", "BICFI"};
  private static final String[] MESSAGE_IDENTIFIER_EXTRACTION_SRC = new String[]{SAA_DATAPDU_APPHDR,
      "MsgDefIdr"};
  private static final String[] BIZ_SVC_EXTRACTION_SRC = new String[]{SAA_DATAPDU_APPHDR, "BizSvc"};
  private static final String[] BIZ_MSG_IDENTIFIER_EXTRACTION_SRC = new String[]{SAA_DATAPDU_APPHDR, "BizMsgIdr"};
  

  public static OutgoingSAADataPDU create(Long messageKey, InputStream inputStream, SaaConfig saaConfig)
      throws IOException, ValidationException {
    OutgoingSAADataPDU outgoingMX = new OutgoingSAADataPDU();

    outgoingMX.setRevision(SAA_REVISION);

    // extract required fields from HABS message
    MessageLocal message = C24.parse(MessageLocal.class, inputStream);

    ComplexDataObject body = message.getBody();

    String sender = getValueByElementName(body, SENDER_EXTRACTION_SRC);
    String receiver = getValueByElementName(body, RECEIVER_EXTRACTION_SRC);
    String messageIdentifier = getValueByElementName(body, MESSAGE_IDENTIFIER_EXTRACTION_SRC);

    // add namespace to DataPDU
    outgoingMX.addNamespaceMapping(
        new NamespaceMapping(SAA_XML_v2_0DataModel.getInstance().getTargetNamespace(),
            SAA_DATAPDU_PREFIX));

    // construct SAA Header
    OutgoingSAAHeader outgoingSAAHeader;
    if(MESSAGETYPE_ADMI_004.equals(messageIdentifier)){
      String bizMsgIdr = getValueByElementName(body, BIZ_MSG_IDENTIFIER_EXTRACTION_SRC);
      // for admi.004.001.02 message, the message is not persisted anywhere and doesn't have a pk.
      // use BizMsgIdr as btPKFromHABS in SenderReference and UserReference
      outgoingSAAHeader = AdmiOutgoingSAAHeader.builder() //
          .withMessageIdentifier(messageIdentifier) //
          .withSender(sender) //
          .withReceiver(receiver) //
          .withBTPKFromHABS(bizMsgIdr) //
          .withNetworkInfo(saaConfig.getNetworkServiceNameByMessageIdentifier(messageIdentifier)) //
          .withRequestSubtypeInfo("") // admi.004.001.02 doesn't contain BizSvc.
          .build();
    } else {
      String businessService =  getValueByElementName(body, BIZ_SVC_EXTRACTION_SRC);
      outgoingSAAHeader = OutgoingSAAHeader.builder() //
          .withMessageIdentifier(messageIdentifier) //
          .withSender(sender) //
          .withReceiver(receiver) //
          .withBTPKFromHABS(String.valueOf(messageKey)) //
          .withNetworkInfo(saaConfig.getNetworkServiceName(businessService)) //
          .withRequestSubtypeInfo(businessService) //
          .build();
    }

    outgoingMX.setHeader(outgoingSAAHeader);

    // construct SAA Body
    SwAny outgoingBody = new SwAny();
    ComplexDataObject appHdr = (ComplexDataObject) body.getElement(SAA_DATAPDU_APPHDR);
    appHdr.addNamespaceMapping(
        new NamespaceMapping(appHdr.getDefiningDecl().getType().getModel().getTargetNamespace(),
            SAA_DATAPDU_APPHDR_PREFIX));
    outgoingBody.addElement(ANY_ELEMENT, appHdr);

    ComplexDataObject document = (ComplexDataObject) body.getElement(SAA_DATAPDU_DOCUMENT);
    document.addNamespaceMapping(
        new NamespaceMapping(document.getDefiningDecl().getType().getModel().getTargetNamespace(),
            SAA_DATAPDU_DOCUMENT_PREFIX));
    outgoingBody.addElement(ANY_ELEMENT, document);

    outgoingMX.setBody(outgoingBody);

    return outgoingMX;
  }

  private static String getValueByElementName(ComplexDataObject object, String[] attrs) {
    ComplexDataObject dataObject = object;
    for (String attr : attrs) {
      dataObject = (ComplexDataObject) dataObject.getElement(attr);
    }
    return dataObject.getMixedContent(0);
  }
}
