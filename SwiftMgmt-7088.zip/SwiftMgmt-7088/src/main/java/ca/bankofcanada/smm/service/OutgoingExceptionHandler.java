package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;

import java.util.Objects;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Component;

/**
 * This class handles exceptions thrown on the HABS->SAA flow.
 *
 * @author River He
 */
@Component
public class OutgoingExceptionHandler {

  private static final Logger logger = Logger.getLogger(OutgoingExceptionHandler.class.getCanonicalName());

  public String handleException(MessagingException exception) {
    Message<?> originalMessage = Objects.requireNonNull(exception.getFailedMessage());
    MessageHeaders originalHeaders = originalMessage.getHeaders();
    String messageKey = String.valueOf(originalHeaders.get(SMM_MESSAGE_PK_HEADER_KEY));
    Throwable rootCause = ExceptionUtils.getRootCause(exception);
    MessageFlowExceptionProcessor.getByExceptionCanonicalName(rootCause.getClass().getCanonicalName())
        .processOutgoingException(messageKey);
    logger.error("MessageKey=" + messageKey + "\n" + ExceptionUtils.getStackTrace(rootCause));
    return exception.toString();
  }

}
