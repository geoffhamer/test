package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.common.CommonConstants;
import ca.bankofcanada.smm.config.SmmMessageResource;
import ca.bankofcanada.smm.entity.SystemInterfaceNodeSummary;
import ca.bankofcanada.smm.exception.ResourceNotFoundException;
import ca.bankofcanada.smm.exception.SAAInterfaceException;
import ca.bankofcanada.smm.models.*;
import ca.bankofcanada.smm.repositories.SystemInterfaceNodeRepository;
import ca.bankofcanada.smm.util.SystemPropertyManager;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;

/**
 * Service class providing functionalities for managing SSA Interfaces
 */
@Service
public class SAAInterfaceService {

  private static final Logger logger = LoggerFactory.getLogger(SAAInterfaceService.class);

  private static final String CMD_SEPARATOR = ":";
  private static final String APP_SERVERS = "app";
  private static final String SWITCH_INTERFACE_Q = "SWITCH_INTERFACE_Q";
  private static final String ENVIRONMENT_NAME_PROPERTY = "EnvironmentName";
  static final int ROWS_NB_SWITCH_INTERFACE_SUCCESS = 1;
  static final int ROWS_NB_SWITCH_INTERFACE_FAILURE = 0;

  private final EntityManager entityManager;
  private final SystemInterfaceNodeRepository systemInterfaceNodeRepository;
  private final JmsQueueService jmsQueueService;
  private final SystemPropertyManager systemPropertyManager;
  private final SmmMessageResource smmMessageResource;


  @Autowired
  public SAAInterfaceService(EntityManager entityManager,
      SystemInterfaceNodeRepository systemInterfaceNodeRepository,
      JmsQueueService jmsQueueService,
      SystemPropertyManager systemPropertyManager,
      SmmMessageResource smmMessageResource ) {

    this.entityManager = entityManager;
    this.systemInterfaceNodeRepository = systemInterfaceNodeRepository;
    this.jmsQueueService = jmsQueueService;
    this.systemPropertyManager = systemPropertyManager;
    this.smmMessageResource = smmMessageResource;
  }


  /**
   * Trigger the switch to the given SAA interface Rollback all DB changes made if
   * ResourceNotFoundException or SAAInterfaceException occurs
   *
   * @param pk Primary Key matching to the SAA Interface to activate
   */
  @Transactional(rollbackFor = {ResourceNotFoundException.class, SAAInterfaceException.class})
  public void switchToSAAInterface(Long pk)
      throws ResourceNotFoundException, SAAInterfaceException {

    int rowsSwitchInterface;

    // Get the SystemInterfaceNodeSummary for given pk
    SystemInterfaceNodeSummary interfaceNode = getSAAInterface(pk); // will throw if no match found

    try {

      // Reset Any InProgress Node Status to 'Inactive'
      systemInterfaceNodeRepository
          .replaceStatusesByStatusAndCategory(SAAInterfaceConstants.REPO_STATUS_INPROGRESS,
              SAAInterfaceConstants.REPO_STATUS_INACTIVE,
              SAAInterfaceConstants.REPO_CATEGORY_INTERFACENODESTATUS);

      // Set status of required interface to 'InProgress' and switchResult to null
      rowsSwitchInterface = systemInterfaceNodeRepository
          .updateStatusAndSwitchResultByPkAndStatusAndCategory(pk,
              SAAInterfaceConstants.REPO_STATUS_INPROGRESS,
              null,
              SAAInterfaceConstants.REPO_CATEGORY_INTERFACENODESTATUS);

    } catch (Exception exp) {
      throw new SAAInterfaceException(exp.getMessage(), exp);
    }

    if (ROWS_NB_SWITCH_INTERFACE_SUCCESS != rowsSwitchInterface) {
      String errorMessage = smmMessageResource.getBilingualMessageSource().getMessage(
          "error.message.MissingInterfaceResource",
          new String[]{String.valueOf(pk)},
          Locale.getDefault());
      throw new ResourceNotFoundException(errorMessage, null);
    }

    // Put message on Swift interface queue (Amos Web)
    enqueueSwitchToSAAInterfaceMessage(interfaceNode);
  }


  /**
   * Enqueue a SAA interface Switch request message to SWITCH_INTERFACE_Q
   *
   * @param interfaceNode System Interface Node Summary for which the Switch request was made
   * @throws SAAInterfaceException in case of any error occurred during the enqueuing
   */
  private void enqueueSwitchToSAAInterfaceMessage(SystemInterfaceNodeSummary interfaceNode)
      throws SAAInterfaceException {
    // Switch Command String : Instruction Pk + hosts + Script Name
    String switchCommand = interfaceNode.getIdName() + CMD_SEPARATOR
        + interfaceNode.getBankSite() + CMD_SEPARATOR + APP_SERVERS
        + CMD_SEPARATOR + interfaceNode.getSwitchScriptName();

    // Post message to the queue
    try {
      Map<String, Object> messageProperty = null;
      String smmEnvironment = systemPropertyManager.getProperty(
          CommonConstants.SYSTEM_PROPERTY_ENVIRONMENT);
      if (null != smmEnvironment) {
        messageProperty = new HashMap<>();
        messageProperty.put(ENVIRONMENT_NAME_PROPERTY, smmEnvironment);
      } else {
        // Do nothing if environment name not available
        logger.warn("{} is not set!!!", CommonConstants.SYSTEM_PROPERTY_ENVIRONMENT);
      }
      jmsQueueService.sendMessage(SWITCH_INTERFACE_Q, switchCommand, messageProperty);

    } catch (Exception exp) {
      throw new SAAInterfaceException(exp.getMessage(), exp);
    }
  }


  /**
   * Retrieves System Interface Node date for the given PK and returns a SystemInterfaceNodeSummary
   *
   * @param pk pk of the interface for which the SystemInterfaceNodeSummary needs to be retrieved
   * @return SystemInterfaceNodeSummary matching to the given pk
   * @throws ResourceNotFoundException in case of invalid/not found Pk
   * @throws SAAInterfaceException in case of any error occurred during the data retrieval
   */
  public SystemInterfaceNodeSummary getSAAInterface(Long pk)
      throws ResourceNotFoundException, SAAInterfaceException {
    Optional<SystemInterfaceNodeSummary> optNode;

    // Get the SystemInterfaceNodeSummary for given pk
    try {
      optNode = systemInterfaceNodeRepository.findSystemInterfaceNodeByPk(
          pk,
          SAAInterfaceConstants.REPO_STATUS_ACTIVE,
          Code.ACTIVE.toString(),
          SAAInterfaceConstants.REPO_STATUS_INACTIVE,
          Code.AVAILABLE.toString(),
          SAAInterfaceConstants.REPO_STATUS_INPROGRESS,
          Code.ACTIVATION_REQUESTED.toString(),
          SAAInterfaceConstants.API_STATUS_UNKNOWN
      );
    } catch (Exception exp) {
      throw new SAAInterfaceException(exp.getMessage(), exp);
    }

    if (!optNode.isPresent()) {
      String errorMessage = smmMessageResource.getBilingualMessageSource().getMessage(
          "error.message.MissingInterfaceResource",
          new String[]{String.valueOf(pk)},
          Locale.getDefault());
      throw new ResourceNotFoundException(errorMessage, null);
    }

    return optNode.get();
  }


  /**
   * Retrieve all System interfaces Nodes for type SWIFT MT interface type ('Swift')
   *
   * @return List<SAAInterfaceConnection> A list interfaces as SAAInterfaceConnections
   * @throws SAAInterfaceException On calls to node repository
   */
  @Transactional(rollbackFor = {SAAInterfaceException.class})
  public List<SAAInterfaceConnection> getAllSAAInterfacesWithUpdates()
      throws SAAInterfaceException {

    List<SAAInterfaceConnection> saaInterfaceConnectionList = new ArrayList<>();

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList = this.fetchAllInterfaceNodes();

    // If any nodes were altered, fetch them again
    List<SystemInterfaceNodeSummary> nodesAltered = this.updateInProgressInterfaces(
        sysInterfaceNodeList);
    if (!nodesAltered.isEmpty()) {
      sysInterfaceNodeList = this.fetchAllInterfaceNodes();
    }

    // Use the Interface Node entities to create a list of Interface Connection pojos
    sysInterfaceNodeList.forEach(n -> saaInterfaceConnectionList.add(this.convertEntityToPojo(n)));

    return saaInterfaceConnectionList;
  }

  /**
   * Set the Switch Result column to null and the Status column to Available for specified node.
   *
   * @param pk The primary key of the Interface Node to be altered
   * @throws ResourceNotFoundException On an invalid pk value
   * @throws SAAInterfaceException For all other errors
   */
  @Transactional(rollbackFor = {ResourceNotFoundException.class, SAAInterfaceException.class})
  public void setSwitchResultToNull(Long pk)
      throws ResourceNotFoundException, SAAInterfaceException {

    int rowsUpdated = 0;
    try {

        rowsUpdated = systemInterfaceNodeRepository.updateStatusAndSwitchResultByPkAndStatusAndCategory(
            pk,
            SAAInterfaceConstants.REPO_STATUS_INACTIVE,
            null,
            SAAInterfaceConstants.REPO_CATEGORY_INTERFACENODESTATUS);

    } catch (Exception ex) {
      throw new SAAInterfaceException(ex.getMessage(), ex);
    }

    // If no nodes were changed, throw an exception
    if (rowsUpdated != 1) {
      String errorMessage = smmMessageResource.getBilingualMessageSource().getMessage(
          "error.message.MissingInterfaceResource",
          new String[]{String.valueOf(pk)},
          Locale.getDefault());
      throw new ResourceNotFoundException(errorMessage, null);
    }

  }


  /**
   * Fetches all current interrface nodes and uses the PK to set the SwitchResults to null
   *
   * @throws SAAInterfaceException On all errors
   */
  @Transactional(rollbackFor = {ResourceNotFoundException.class, SAAInterfaceException.class})
  public void setAllSwitchResultToNull() throws ResourceNotFoundException, SAAInterfaceException {

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList = this.fetchAllInterfaceNodes();

    for (SystemInterfaceNodeSummary node:sysInterfaceNodeList) {

      this.setSwitchResultToNull(node.getPk());

    }

  }

  /**
   * This method implements an algorithm to properly set interface statuses after an interface
   * change.
   *
   * AMOS only sets the SwitchResult value after an interface switch. The status isn't set to
   * 'ACTIVE' on the changed node and previously active nodes aren't changed to inactive. This
   * method performs the following:
   *
   * If there are nodes with Status/SwitchResult == InProgress/Success: - set all 'Active' nodes to
   * Inactive/null (AVAILABLE) - set the most recently changed InProgress/Success node to
   * Active/Success - set any other InProgress/Success nodes to Inactive/null (AVAILABLE)
   *
   * @param currentNodes The Interface Nodes in their current state
   * @return A List of nodes that were altered while implementing the above algorithm
   */
  List<SystemInterfaceNodeSummary> updateInProgressInterfaces(
      List<SystemInterfaceNodeSummary> currentNodes)
      throws SAAInterfaceException {

    List<SystemInterfaceNodeSummary> alteredNodes = new ArrayList<>();

    // Create a list of nodes whose Status/SwitchResult is InProgress/Success sorted by descending update date.
    List<SystemInterfaceNodeSummary> inProgressList = currentNodes.stream().filter(
            n -> (SAAInterfaceConstants.API_STATUS_ACTIVATION_REQUESTED.equals(n.getStatus()) &&
                SAAInterfaceConstants.SWITCH_RESULT_SUCCESS.equals(n.getSwitchResult())))
        .sorted(Comparator.comparing(SystemInterfaceNodeSummary::getLastUpdateTimestamp).reversed())
        .collect(Collectors.toList());

    // Do we have any nodes whose state is InProgress/Success?
    if (!inProgressList.isEmpty()) {

      // We are going to be altering Entities, so we detach them from the persistence context
      this.entityManager.clear();

      // Get a list of any nodes with status ACTIVE
      List<SystemInterfaceNodeSummary> activeNodes = currentNodes.stream().filter(
              n -> (SAAInterfaceConstants.API_STATUS_ACTIVE.equals(n.getStatus())))
          .collect(Collectors.toList());

      // Set their state to Inactive/null and put them on the alteredNode list
      for (SystemInterfaceNodeSummary activeNode : activeNodes) {
        activeNode.setStatus(SAAInterfaceConstants.REPO_STATUS_INACTIVE);
        activeNode.setSwitchResult(null);
        alteredNodes.add(activeNode);
      }

      // Change the status of the NEWEST node to Active/Success and the rest to Inactive/null
      for (SystemInterfaceNodeSummary inProgressNode : inProgressList) {

        // This is the NEWEST (or ONLY) InProgress node, set it Active
        if (inProgressList.indexOf(inProgressNode) == 0) {
          inProgressNode.setStatus(SAAInterfaceConstants.REPO_STATUS_ACTIVE);
          // Set all other InProgress nodes ot InActive/null
        } else {
          inProgressNode.setStatus(SAAInterfaceConstants.REPO_STATUS_INACTIVE);
          inProgressNode.setSwitchResult(null);
        }

        // Add the nodes to the altered list
        alteredNodes.add(inProgressNode);
      }
    }

    // Persists all nodes that were altered
    try {

      for (SystemInterfaceNodeSummary node : alteredNodes) {
        systemInterfaceNodeRepository.updateStatusAndSwitchResultByPkAndStatusAndCategory(
            node.getPk(),
            node.getStatus(),
            node.getSwitchResult(),
            SAAInterfaceConstants.REPO_CATEGORY_INTERFACENODESTATUS);
      }

    } catch (Exception ex) {
      throw new SAAInterfaceException(ex.getMessage(), ex);
    }

    return alteredNodes;
  }


  /**
   * Fetches a list of all the Interface Node in their current state
   *
   * @return A list of Interface node entities
   * @throws SAAInterfaceException On all database errors
   */
  private List<SystemInterfaceNodeSummary> fetchAllInterfaceNodes() throws SAAInterfaceException {

    List<SystemInterfaceNodeSummary> sysInterfaceNodeList;

    try {

      sysInterfaceNodeList = systemInterfaceNodeRepository.findByType(
          SAAInterfaceConstants.REPO_TYPE_SWIFT,
          SAAInterfaceConstants.REPO_STATUS_ACTIVE,
          Code.ACTIVE.toString(),
          SAAInterfaceConstants.REPO_STATUS_INACTIVE,
          Code.AVAILABLE.toString(),
          SAAInterfaceConstants.REPO_STATUS_INPROGRESS,
          Code.ACTIVATION_REQUESTED.toString(),
          SAAInterfaceConstants.API_STATUS_UNKNOWN
      );

    } catch (Exception exp) {
      throw new SAAInterfaceException(exp.getMessage(), exp);
    }

    return sysInterfaceNodeList;
  }


  /**
   * Converts the SystemInterfaceNodeSummary entity to a SAAInterfaceConnection pojo for marshalling
   * as JSON.
   *
   * @param entity The SystemInterfaceNodeSummary returned by the repo
   * @return SAAInterfaceConnection pojo
   */
  private SAAInterfaceConnection convertEntityToPojo(SystemInterfaceNodeSummary entity) {

    SAAInterfaceConnection pojo = new SAAInterfaceConnection();
    pojo.setId(entity.getPk());
    pojo.setName(new Name(entity.getNameEn(), entity.getNameFr()));
    pojo.setDescription(new Description(entity.getDescEn(), entity.getDescFr()));
    pojo.setNote(entity.getSwitchResult());

    ZonedDateTime zDate = ZonedDateTime.ofInstant(entity.getLastUpdateTimestamp().toInstant(),
        ZoneId.systemDefault());
    pojo.setLastUpdateDateTime(zDate);
    pojo.setLastUpdateBy(entity.getLastUpdateBy());

    Status status = new Status();
    Code code = Code.valueOf(entity.getStatus());
    status.setCode(code);
    status.setDescription(code.getDescription());
    status.setName(code.getName());

    pojo.setStatus(status);

    return pojo;
  }

}
