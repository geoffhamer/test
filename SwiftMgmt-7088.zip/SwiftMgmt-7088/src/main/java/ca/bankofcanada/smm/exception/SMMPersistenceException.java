package ca.bankofcanada.smm.exception;

public class SMMPersistenceException extends Exception {

  public SMMPersistenceException(String message) {
    super(message);
  }

}
