package ca.bankofcanada.smm.entity;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "BUSINESS_CYCLE")
public class BusinessCycle implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "BUSINESS_CYCLE_SEQ_GEN", strategy = GenerationType.SEQUENCE)
  @SequenceGenerator(name = "BUSINESS_CYCLE_SEQ_GEN", sequenceName = "BUSINESS_CYCLE_SEQ")
  @Column(name = "BUSINESS_CYCLE_PK", updatable = false, nullable = false)
  private Long pk;

  @Column(name = "BUSINESS_DATE")
  private Date businessDate;

  @Column(name = "PROCESS_START_DATE")
  private Date processStartDate;

  @Column(name = "PROCESS_END_DATE")
  private Date processEndDate;

  @Column(name = "CYCLE_STATUS_FK")
  private Long cycleStatusCode;

  @Version
  @Column(name = "OPTLOCK")
  private Long optlock;

  @Column(name = "APPLICATION_USER_NAME")
  private String applicationUserName;

  @Column(name = "INSTRUCTION_FK")
  private Long instruction;

  @Column(name = "APPLICATION_UPDATE_TIMESTAMP")
  private Timestamp applicationUpdateTimestamp;

  @Column(name = "AUDIT_CREATION_USER", insertable = false, updatable = false)
  private String auditCreationUserName;

  @Column(name = "AUDIT_LAST_UPDATE_USER", insertable = false, updatable = false)
  private String auditLastUpdateUserName;

  @Column(name = "AUDIT_CREATION_DATE", insertable = false, updatable = false)
  private Timestamp auditCreationTimestamp;

  @Column(name = "AUDIT_LAST_UPDATE_DATE", insertable = false, updatable = false)
  private Timestamp auditLastUpdateTimestamp;

  public Long getPk() {
    return pk;
  }

  public void setPk(Long pk) {
    this.pk = pk;
  }

  public Date getBusinessDate() {
    return businessDate;
  }

  public void setBusinessDate(Date businessDate) {
    this.businessDate = businessDate;
  }

  public Date getProcessStartDate() {
    return processStartDate;
  }

  public void setProcessStartDate(Date processStartDate) {
    this.processStartDate = processStartDate;
  }

  public Date getProcessEndDate() {
    return processEndDate;
  }

  public void setProcessEndDate(Date processEndDate) {
    this.processEndDate = processEndDate;
  }

  public Long getCycleStatusCode() {
    return cycleStatusCode;
  }

  public void setCycleStatusCode(Long cycleStatusCode) {
    this.cycleStatusCode = cycleStatusCode;
  }

  public Long getOptlock() {
    return optlock;
  }

  public void setOptlock(Long optlock) {
    this.optlock = optlock;
  }

  public String getApplicationUserName() {
    return applicationUserName;
  }

  public void setApplicationUserName(String applicationUserName) {
    this.applicationUserName = applicationUserName;
  }

  public Long getInstruction() {
    return instruction;
  }

  public void setInstruction(Long instruction) {
    this.instruction = instruction;
  }

  public Timestamp getApplicationUpdateTimestamp() {
    return applicationUpdateTimestamp;
  }

  public void setApplicationUpdateTimestamp(Timestamp applicationUpdateTimestamp) {
    this.applicationUpdateTimestamp = applicationUpdateTimestamp;
  }

  public String getAuditCreationUserName() {
    return auditCreationUserName;
  }

  public void setAuditCreationUserName(String auditCreationUserName) {
    this.auditCreationUserName = auditCreationUserName;
  }

  public String getAuditLastUpdateUserName() {
    return auditLastUpdateUserName;
  }

  public void setAuditLastUpdateUserName(String auditLastUpdateUserName) {
    this.auditLastUpdateUserName = auditLastUpdateUserName;
  }

  public Timestamp getAuditCreationTimestamp() {
    return auditCreationTimestamp;
  }

  public void setAuditCreationTimestamp(Timestamp auditCreationTimestamp) {
    this.auditCreationTimestamp = auditCreationTimestamp;
  }

  public Timestamp getAuditLastUpdateTimestamp() {
    return auditLastUpdateTimestamp;
  }

  public void setAuditLastUpdateTimestamp(Timestamp auditLastUpdateTimestamp) {
    this.auditLastUpdateTimestamp = auditLastUpdateTimestamp;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BusinessCycle that = (BusinessCycle) o;
    return pk.equals(that.pk);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pk);
  }
}
