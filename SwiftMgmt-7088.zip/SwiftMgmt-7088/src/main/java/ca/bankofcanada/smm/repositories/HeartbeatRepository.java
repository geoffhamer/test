package ca.bankofcanada.smm.repositories;

import ca.bankofcanada.smm.entity.Heartbeat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HeartbeatRepository extends JpaRepository<Heartbeat, Integer> {}
