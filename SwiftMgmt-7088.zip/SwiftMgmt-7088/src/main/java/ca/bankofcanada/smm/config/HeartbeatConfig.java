package ca.bankofcanada.smm.config;

import ca.bankofcanada.smm.service.SAAHeartbeatService;
import ca.bankofcanada.smm.service.SMMToSwiftHeartbeatBuilder;
import ca.bankofcanada.smm.service.ScheduledHeartbeatService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
@EnableAsync
@ConditionalOnProperty(prefix = "smm.heartbeat", name = "enable", havingValue = "true")
public class HeartbeatConfig {

  @Bean
  public ScheduledHeartbeatService scheduledHeartbeatService(
      SAAHeartbeatService saaHeartbeatService,
      HeartbeatProperties heartbeatProperties, SMMToSwiftHeartbeatBuilder heartbeatBuilder) {
    return new ScheduledHeartbeatService(saaHeartbeatService, heartbeatProperties, heartbeatBuilder);
  }
}
