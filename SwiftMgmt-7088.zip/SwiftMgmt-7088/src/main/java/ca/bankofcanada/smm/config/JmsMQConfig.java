package ca.bankofcanada.smm.config;

import org.apache.activemq.artemis.core.config.impl.ConfigurationImpl;
import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.annotation.EnableJms;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.apache.activemq.artemis.core.server.embedded.EmbeddedActiveMQ;

@Configuration
@EnableJms
public class JmsMQConfig {

   private final static Logger logger = LoggerFactory.getLogger(JmsMQConfig.class);

   @Value("${spring.artemis.broker-url:tcp://localhost:61616}")
   private String brokerUrl;

   @Profile("local")
   @Bean(initMethod = "start", destroyMethod = "stop")
   public EmbeddedActiveMQ embeddedActiveMQ() {

      org.apache.activemq.artemis.core.config.Configuration artemisConfig = new ConfigurationImpl();
      try {
         artemisConfig.setSecurityEnabled(false);
         artemisConfig.addAcceptorConfiguration("netty", brokerUrl);
      } catch (Exception ex) {
         logger.debug("Error configuring embedded Artemis: " + ex.getMessage() );
      }

      final EmbeddedActiveMQ embeddedActiveMQ = new EmbeddedActiveMQ();
      embeddedActiveMQ.setConfiguration(artemisConfig);

      return embeddedActiveMQ;
   }

   @Bean(name = "smmJmsDSConnFactory")
   public ConnectionFactory jmsIncomingConnectionFactory() throws JMSException {
      ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
      connectionFactory.setBrokerURL(brokerUrl);
      return connectionFactory;
   }

   @Bean(name = "smmQueueSenderDSConnFactory")
   public ConnectionFactory jmsOutgoingConnectionFactory() throws JMSException {
      ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
      connectionFactory.setBrokerURL(brokerUrl);
      return connectionFactory;
   }

}
