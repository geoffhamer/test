package ca.bankofcanada.smm.exception;

public class UnparsableSMMMessageException extends RuntimeException {

  public UnparsableSMMMessageException(String message) {
    super(message);
  }

}
