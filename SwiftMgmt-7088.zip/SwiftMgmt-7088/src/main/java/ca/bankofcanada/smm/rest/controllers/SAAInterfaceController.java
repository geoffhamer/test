package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.exception.ResourceNotFoundException;
import ca.bankofcanada.smm.exception.SAAInterfaceException;
import ca.bankofcanada.smm.logging.annotations.LogRestAPIException;
import ca.bankofcanada.smm.models.SAAInterfaceConnection;
import ca.bankofcanada.smm.service.SAAInterfaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(SAAInterfaceController.URI_BASE_SAA_INTERFACE_API)
public class SAAInterfaceController {

  private static final Logger logger = LoggerFactory.getLogger(SAAInterfaceController.class);
  public static final String URI_BASE_SAA_INTERFACE_API  = "/api/saa-interfaces";
  public static final String INTERFACE_ID  = "interfaceId";
  public static final String INTERFACE_ID_ACTIVATE_SEGMENT  = "/{" + INTERFACE_ID + "}/activation-requests";
  public static final String INTERFACE_ID_GET_SEGMENT  = "/{" + INTERFACE_ID + "}";
  public static final String INTERFACES_GET_SEGMENT  = "";

  private final SAAInterfaceService saaInterfaceService;

  @Autowired
  public SAAInterfaceController(SAAInterfaceService saaInterfaceService) {
    this.saaInterfaceService = saaInterfaceService;
  }

  /**
   * Retrieves all Interface Nodes as a list of SAAInterfaceConnection POJOs.
   *
   * The system performs the following:
   * - all interface nodes are retrieved
   * - nodes with 'InProgress' status are updated
   * - all nodes are retrieved again and returned to the Controller as POJOs
   *
   * @return List of System interfaces Nodes for type 'Swift'
   * @throws SAAInterfaceException on calls to the interface service
   */
  @GetMapping(value = SAAInterfaceController.INTERFACES_GET_SEGMENT)
  @LogRestAPIException
  public ResponseEntity<List<SAAInterfaceConnection>> getAllSAAInterfaces()
      throws SAAInterfaceException {
    logger.debug("Fetching list of Interface Connections.");

    List<SAAInterfaceConnection> connections = saaInterfaceService.getAllSAAInterfacesWithUpdates();
    logger.debug("{} Interface Connections found.", connections.size() );

    return new ResponseEntity<>(connections, HttpStatus.OK);
  }

  /**
   * Switch to the given SAA interface
   * @param interfaceId of the interface to switch to
   * @return ResponseEntity
   * @throws ResourceNotFoundException When requested interface doesn't exist.
   * @throws SAAInterfaceException On calls to the interface service
   */
  @Operation(description = "Initiate a Swift SAA interface change to the given " + INTERFACE_ID ,
      parameters = {
          @Parameter(
              in = ParameterIn.PATH,
              name = INTERFACE_ID,
              required = true,
              description = INTERFACE_ID + " of the SAA interface to switch to",
              schema = @Schema(type = "integer", format = "int64"))})
  @PostMapping(value = SAAInterfaceController.INTERFACE_ID_ACTIVATE_SEGMENT)
  @LogRestAPIException
  public ResponseEntity<?> switchToSAAInterface(@NotEmpty @PathVariable(name = INTERFACE_ID) Long interfaceId)
      throws ResourceNotFoundException, SAAInterfaceException {
    logger.debug("Switching SAA interface ...");

    saaInterfaceService.switchToSAAInterface(interfaceId);

    return ResponseEntity.status(HttpStatus.ACCEPTED).build();
  }
}
