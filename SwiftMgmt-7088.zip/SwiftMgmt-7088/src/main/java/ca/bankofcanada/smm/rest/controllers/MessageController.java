package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.logging.annotations.LogRestAPIException;
import ca.bankofcanada.smm.repositories.SwiftMessageRepository;
import ca.bankofcanada.smm.validation.SMMToSwiftValidator;
import io.swagger.v3.oas.annotations.Parameter;
import java.util.Optional;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/swift-messages")
public class MessageController {


  private final SwiftMessageRepository swiftMessageRepository;

  @Autowired
  public MessageController(SwiftMessageRepository swiftMessageRepository) {
    this.swiftMessageRepository = swiftMessageRepository;
  }

  @GetMapping(path = "/{referenceId}", produces = "application/xml")
  @LogRestAPIException
  public ResponseEntity<?> getSwiftMessage(@NotEmpty @PathVariable(name = "referenceId") Long referenceId) throws Throwable {
    SwiftMessage swiftMessage = Optional.ofNullable(swiftMessageRepository.getReferenceById(referenceId))
        .orElseThrow(EntityNotFoundException::new);
    return new ResponseEntity<>(swiftMessage.getMessageContentTxt(), HttpStatus.OK);
  }

}
