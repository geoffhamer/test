package ca.bankofcanada.smm.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SaaConfig {

  public static final String PAYMENTSCA_LYNX_02 = "paymentsca.lynx.02";
  public static final String PAYMENTSCA_LYNX_COV_02 = "paymentsca.lynx.cov.02";
  public static final String SWIFT_CBPRPLUS_02 = "swift.cbprplus.02";

  public static final String MESSAGETYPE_XSYS_002 = "xsys.002.001.01";
  public static final String MESSAGETYPE_XSYS_003 = "xsys.003.001.01";
  public static final String MESSAGETYPE_XSYS_012 = "xsys.012.001.01";
  public static final String MESSAGETYPE_PACS_008 = "pacs.008.001.08";
  public static final String MESSAGETYPE_PACS_009 = "pacs.009.001.08";
  public static final String MESSAGETYPE_PACS_004 = "pacs.004.001.09";

  public static final String MESSAGETYPE_ADMI_004 = "admi.004.001.02";
  public static final String MESSAGETYPE_CAMT_004 = "camt.057.001.06";

  public static final String MESSAGETYPE_NETWORK_ACKED = "NetworkAcked";
  public static final String MESSAGETYPE_NETWORK_NACKED = "NetworkNacked";

  public static final List<String> VALID_INCOMING_MESSAGE_TYPES = Collections.unmodifiableList(
      Arrays.asList( //
          MESSAGETYPE_PACS_009, //
          MESSAGETYPE_PACS_008, //
          MESSAGETYPE_XSYS_002, //
          MESSAGETYPE_XSYS_003, //
          MESSAGETYPE_XSYS_012, //
          MESSAGETYPE_PACS_004, //
          MESSAGETYPE_CAMT_004, //
          MESSAGETYPE_NETWORK_ACKED, //
          MESSAGETYPE_NETWORK_NACKED, //
          MESSAGETYPE_ADMI_004 //
      ));

  private static final HashMap<String, String> serviceMap = new HashMap<>();

  @Value("${smm.saa.paymentscalynx.service:paymentscanada.lynx!p}")
  private String paymentscaLynxService;

  @Value("${smm.saa.cbprplus.service:swift.finplus!pf}")
  private String cbprplusService;

  @Value("${smm.saa.admi.service:swift.tst2.iast!p}")
  private String admiService;

  @PostConstruct
  private void init() {
    serviceMap.put(PAYMENTSCA_LYNX_02, this.paymentscaLynxService);
    serviceMap.put(PAYMENTSCA_LYNX_COV_02, this.paymentscaLynxService);

    serviceMap.put(SWIFT_CBPRPLUS_02, this.cbprplusService);

    serviceMap.put(MESSAGETYPE_ADMI_004, this.admiService);
  }

  public String getNetworkServiceName(String bizSvc) {
    return serviceMap.get(bizSvc);
  }

  public String getNetworkServiceNameByMessageIdentifier(String messageIdentifier) {
    return serviceMap.get(messageIdentifier);
  }
}
