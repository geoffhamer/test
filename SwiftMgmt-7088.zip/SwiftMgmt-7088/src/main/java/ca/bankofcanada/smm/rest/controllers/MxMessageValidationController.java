package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.logging.annotations.LogRestAPIException;
import ca.bankofcanada.smm.model.SmmMessageDocumentRoot;
import ca.bankofcanada.smm.rest.dto.ValidationsResponse;
import ca.bankofcanada.smm.service.SMMToSwiftMessageBuilder;
import ca.bankofcanada.smm.validation.SMMToSwiftValidator;
import javax.validation.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/mx-messages/validations")
public class MxMessageValidationController {
  @Autowired
  private final SMMToSwiftValidator validator;
  private final SMMToSwiftMessageBuilder builder;

  public MxMessageValidationController(SMMToSwiftValidator validator,
      SMMToSwiftMessageBuilder builder) {
    this.validator = validator;
    this.builder = builder;
  }

  @PostMapping
  @LogRestAPIException
  public ResponseEntity<?> validate(@NotEmpty @RequestBody String body) throws Exception {

    // attempt to validate structure before send for full validation
    SmmMessageDocumentRoot cdo = validator.validateStructure(body);

    String constructedSAAMsg = builder.createSMMToSwiftMXMessage(body,
        cdo.getMessage().getHeader().getMessageKey());
    
    validator.validate(constructedSAAMsg);
    return new ResponseEntity<>(new ValidationsResponse(),HttpStatus.OK);
  }
}
