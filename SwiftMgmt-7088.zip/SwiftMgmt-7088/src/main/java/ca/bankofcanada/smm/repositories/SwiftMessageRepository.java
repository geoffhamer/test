package ca.bankofcanada.smm.repositories;

import ca.bankofcanada.smm.entity.SwiftMessage;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SwiftMessageRepository extends JpaRepository<SwiftMessage, Long> {

  /*This will issue an sql query with LIMIT 1 so it will always be fast*/
  Optional<SwiftMessage> findFirstByOrderByMessagePkAsc();
}
