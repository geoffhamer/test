package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_PACS_008;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_PACS_009;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_XSYS_002;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_XSYS_003;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_XSYS_012;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.PERSISTENCE_ERROR_PK;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_TYPE_UNKNOWN;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ComplexDataObject;
import biz.c24.io.api.data.Element;
import biz.c24.io.api.data.NamespaceMapping;
import biz.c24.io.api.presentation.Source;
import biz.c24.io.spring.source.XmlSourceFactory;
import ca.bankofcanada.smm.model.HeaderType;
import ca.bankofcanada.smm.model.MessageLocal;
import ca.bankofcanada.smm.model.SmmMessageDataModel;
import com.progress.swiftsolutions.systemmessages10.ycopyauthstnntfctnv01message.YCopyAuthstnNtfctnV01MessageDocumentRoot;
import com.progress.swiftsolutions.systemmessages10.ycopyrfslntfctnv01message.YCopyRfslNtfctnV01MessageDocumentRoot;
import com.progress.swiftsolutions.systemmessages10.faileddlvryntfctnmessage.FailedDlvryNtfctnMessageDocumentRoot;
import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.GregorianCalendar;
import org.springframework.lang.Nullable;
import org.springframework.messaging.handler.annotation.Header;
import swift.saa.xsd.saa.x2.x0.DataPDU;
import swift.saa.xsd.saa.x2.x0.Intervention;
import swift.saa.xsd.saa.x2.x0.Interventions;
import swift.saa.xsd.saa.x2.x0.SAA_XML_v2_0DocumentRoot;
import swift.saa.xsd.saa.x2.x0.SWIFTNetNetworkInfo;
import swift.saa.xsd.saa.x2.x0.SwAny;
import swift.saa.xsd.saa.x2.x0.TransmissionReport;
import swift.snl.ns.sw.AnyDataType;

/**
 * This class builds outgoing messages for the SAA->HABS flow
 *
 * @author  River He
 */
public class SMMToHABSMessageBuilder {

  private static final String SAA_HEADER_ACK_NACK = "AckNack";
  private static final String SAA_BODY_APPHDR = "AppHdr";
  private static final String SAA_BODY_DOCUMENT = "Document";
  private final static String TS_INFO_FOR_RECEIVER = "TSInfoForReceiver";

  private final XmlSourceFactory xmlSourceFactory;

  public SMMToHABSMessageBuilder(XmlSourceFactory xmlSourceFactory) {
    this.xmlSourceFactory = xmlSourceFactory;
  }

  /**
   * This method builds ack/nack messages for the SAA->HABS flow.
   *
   * @param payload The spring message payload
   * @param messagePk HeaderKey SwiftMessagePK
   * @param messageType HeaderKey incomingMessageType
   * @return The built MessageLocal object
   * @throws IOException if failed to parse payload
   */
  public String buildAckNackMessage(String payload,
      @Header(SMM_MESSAGE_PK_HEADER_KEY) String messagePk,
      @Header(MESSAGE_TYPE_HEADER_KEY) String messageType) throws IOException {

    Source source = xmlSourceFactory.getSource(new StringReader(payload));
    DataPDU saaDataPDU = C24.parse(DataPDU.class).from(source);

    TransmissionReport transmissionReport = saaDataPDU.getHeader().getTransmissionReport();

    // extract ack/nack from incoming SAA Header
    Interventions interventions = transmissionReport.getInterventions();
    ComplexDataObject ackNack = null;
    for (Intervention intervention : interventions.getIntervention()) {
      SwAny contents = intervention.getContents();
      if (contents.containsElementDecl(SAA_HEADER_ACK_NACK)) {
        ackNack = (ComplexDataObject) contents.getElement(SAA_HEADER_ACK_NACK);
        break;
      }
    }

    MessageLocal outMsg = buildMessageLocal(messagePk, messageType, new Object[]{ackNack});

    return outMsg.toString();
  }

  /**
   * This method builds xsys messages for the SAA->HABS flow.
   *
   * @param payload The spring message payload
   * @param messagePk HeaderKey SwiftMessagePK
   * @param messageType HeaderKey incomingMessageType
   * @return The built MessageLocal object
   * @throws IOException if failed to parse payload
   */
  public String buildXsysMessage(String payload,
      @Header(SMM_MESSAGE_PK_HEADER_KEY) String messagePk,
      @Header(MESSAGE_TYPE_HEADER_KEY) String messageType) throws Exception {

    Source source = xmlSourceFactory.getSource(new StringReader(payload));
    DataPDU saaDataPDU;

    if(MESSAGETYPE_XSYS_002.equals(messageType)) {
      saaDataPDU = C24.parse(YCopyAuthstnNtfctnV01MessageDocumentRoot.class).from(source).getDataPDU();
    } else if(MESSAGETYPE_XSYS_003.equals(messageType)){
      saaDataPDU = C24.parse(YCopyRfslNtfctnV01MessageDocumentRoot.class).from(source).getDataPDU();
    } else if (MESSAGETYPE_XSYS_012.equals(messageType)) {
      saaDataPDU = C24.parse(FailedDlvryNtfctnMessageDocumentRoot.class).from(source).getDataPDU();
    } else {
      saaDataPDU = C24.parse(SAA_XML_v2_0DocumentRoot.class).from(source).getDataPDU();
    }

    // extract AppHdr and Document
    // For an explanation of the namespace workaround, see the buildGenericMessage() method below
    ComplexDataObject appHdr = (ComplexDataObject)saaDataPDU.getBody().getElement(SAA_BODY_APPHDR);
    appHdr.setNamespaceMapping(new NamespaceMapping(appHdr.getNamespaceMapping(0).getUri(), ""), 0);

    ComplexDataObject document = (ComplexDataObject)saaDataPDU.getBody().getElement(SAA_BODY_DOCUMENT);
    document.setNamespaceMapping(new NamespaceMapping(document.getNamespaceMapping(0).getUri(), ""), 0);

    MessageLocal outMsg = buildMessageLocal(messagePk, messageType, new Object[]{appHdr, document});

    return outMsg.toString();
  }

  /**
   * This method builds pacs/admi/camt messages for the SAA->HABS flow.
   *
   * @param payload The spring message payload
   * @param messagePk HeaderKey SwiftMessagePK
   * @param messageType HeaderKey incomingMessageType
   * @return The built MessageLocal object
   * @throws IOException if failed to parse payload
   */
  public String buildGenericMessage(String payload,
      @Header(SMM_MESSAGE_PK_HEADER_KEY) @Nullable String messagePk,
      @Header(MESSAGE_TYPE_HEADER_KEY) String messageType) throws Exception {

    DataPDU saaDataPDU = C24.parse(DataPDU.class, new StringReader(payload));

    // admi.004.001.002 bypasses persistence
    if(messagePk == null){
      messagePk = String.valueOf(PERSISTENCE_ERROR_PK);
    }

    // Extract AppHdr and Document and replace unnecessary namespace prefix with a default namespace
    //
    // Note: There is a quirk with C24 where, if a default namespace prefix is defined in a parent
    // element, that prefix is removed from child elements during the transformation. This causes
    // issues in HABS. To get around it, we extract the default namespace (index '0') and insert it
    // without the prefix. That way the child elements simply inherit it from the AppHdr and Document.
    ComplexDataObject appHdr = (ComplexDataObject)saaDataPDU.getBody().getElement(SAA_BODY_APPHDR);
    appHdr.setNamespaceMapping(new NamespaceMapping(appHdr.getNamespaceMapping(0).getUri(), ""), 0);

    ComplexDataObject document = (ComplexDataObject)saaDataPDU.getBody().getElement(SAA_BODY_DOCUMENT);
    document.setNamespaceMapping(new NamespaceMapping(document.getNamespaceMapping(0).getUri(), ""), 0);

    // Build SmmMessage using extracted AppHdr and Document objects
    MessageLocal outMsg = buildMessageLocal(messagePk, messageType, new Object[]{appHdr, document});

    // TSInfoForReceiver only available in pacs008 and pacs009 messages
    if(MESSAGETYPE_PACS_008.equals(messageType) || MESSAGETYPE_PACS_009.equals(messageType)){
      SWIFTNetNetworkInfo swiftNetNetworkInfo = saaDataPDU.getHeader().getMessage().getNetworkInfo().getNetworkInfoSG1().getSWIFTNetNetworkInfo();
      String tsInfo = swiftNetNetworkInfo.getTSInfoForReceiver();

      if (tsInfo != null) {
        Element tsInfoElement = new Element(TS_INFO_FOR_RECEIVER, 0, 1, AnyDataType.class,
            SmmMessageDataModel.getInstance());
        SwAny additionalInformation = outMsg.getHeader().createAdditionalInformation();
        additionalInformation.addElementDecl(tsInfoElement);
        additionalInformation.addElement(TS_INFO_FOR_RECEIVER, tsInfo);
      }

    }

    return outMsg.toString();
  }

  /**
   * This method builds unknown type messages for the SAA->HABS flow.
   *
   * @param payload The spring message payload
   * @param messagePk HeaderKey SwiftMessagePK
   * @return The built MessageLocal object
   * @throws IOException if failed to parse payload
   */
  public String buildUnknownMessage(String payload,
      @Header(SMM_MESSAGE_PK_HEADER_KEY) String messagePk) throws Exception {

    StringReader reader = new StringReader(payload);
    SAA_XML_v2_0DocumentRoot xml_v2_0DocumentRoot = C24.parse(SAA_XML_v2_0DocumentRoot.class, reader);

    MessageLocal outMsg = buildMessageLocal(messagePk, SMM_MESSAGE_TYPE_UNKNOWN, new Object[]{xml_v2_0DocumentRoot});

    return outMsg.toString();
  }

  private MessageLocal buildMessageLocal(String messagePk, String messageType, Object[] outMsgBodies) {
    MessageLocal outMsg = new MessageLocal();

    // set header
    HeaderType outMsgHeader = new HeaderType();
    outMsgHeader.setCreationDate((new GregorianCalendar()).getTime());
    outMsgHeader.setMessageKey(messagePk);
    outMsgHeader.setMessageType(messageType);
    outMsg.setHeader(outMsgHeader);

    // set body
    SwAny swAny = new SwAny();
    Arrays.asList(outMsgBodies).forEach(outMsgBody -> swAny.addElement("any", outMsgBody));
    outMsg.setBody(swAny);

    return outMsg;
  }
}
