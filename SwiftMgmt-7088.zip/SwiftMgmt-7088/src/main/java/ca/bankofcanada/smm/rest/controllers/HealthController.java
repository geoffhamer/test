package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.exception.DatabaseException;
import ca.bankofcanada.smm.logging.annotations.LogRestAPIException;
import ca.bankofcanada.smm.repositories.SwiftMessageRepository;
import ca.bankofcanada.smm.rest.dto.SMMResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/health")
@Deprecated
/**
 * Please use the health actuator instead
 * http://host/contextroot/actuator/health
 */
public class HealthController {

  @Autowired(required = false)
  SwiftMessageRepository swiftMessageRepository;

  @GetMapping
  @LogRestAPIException
  public ResponseEntity<?> healthCheck() throws DatabaseException {
    try {
      swiftMessageRepository.findFirstByOrderByMessagePkAsc();
    } catch (Exception exp) {
      throw new DatabaseException(exp.getMessage(), exp);
    }
    return new ResponseEntity<>(new SMMResponse(), HttpStatus.OK);
  }
}
