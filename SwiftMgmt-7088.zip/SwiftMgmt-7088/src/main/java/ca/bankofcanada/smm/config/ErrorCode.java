package ca.bankofcanada.smm.config;

/**
 * An enum that defines different error codes used in the system
 */
public enum ErrorCode {
   DATABASE_ACCESS(-1),
   RULES_VALIDATION(1),
   STRUCTURE_VALIDATION(2),
   SIGNATURE_VALIDATION(3),
   INVALID_ARGUMENTS(4),
   RESOURCE_NOT_FOUND(5),
   SAA_INTERFACE_REQUEST_FAILURE(6),
   OTHER(99);

   private final int value;

   ErrorCode(int value) {
      this.value = value;
   }

   public int getValue() {
      return this.value;
   }
}
