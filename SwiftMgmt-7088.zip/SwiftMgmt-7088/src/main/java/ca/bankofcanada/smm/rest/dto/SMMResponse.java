package ca.bankofcanada.smm.rest.dto;

import java.util.ArrayList;
import java.util.List;

public class SMMResponse {

  private List<SMMError> errors = new ArrayList<>();

  public SMMResponse() {

  }

  public List<SMMError> getErrors() {
    return errors;
  }

  public void setErrors(List<SMMError> errors) {
    this.errors = errors;
  }
}
