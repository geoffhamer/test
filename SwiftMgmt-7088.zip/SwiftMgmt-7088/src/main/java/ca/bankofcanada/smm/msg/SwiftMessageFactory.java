package ca.bankofcanada.smm.msg;

import ca.bankofcanada.smm.entity.SwiftMessage;
import java.sql.Timestamp;

import ca.bankofcanada.smm.util.XMLUtil;
import java.util.Optional;
import org.springframework.stereotype.Component;

@Component
public class SwiftMessageFactory {
  private static final String SAA_USERREFERENCE = "Saa:UserReference";

  /**
   * @param payload Message payload
   * @return New instance of SwiftMessage
   */
  public SwiftMessage createIncomingMessage(String payload){
    return createSwiftMessage(payload);
  }

  /**
   * @param payload Message payload
   * @return New instance of SwiftMessage
   */
  public SwiftMessage createOutgoingMessage(String payload) {
    Optional<String> userReference = XMLUtil.extractXMLTagText(payload, SAA_USERREFERENCE);

    SwiftMessage swiftMessage = createSwiftMessage(payload);
    userReference.ifPresent(ref -> swiftMessage.setBusinessTransactionFk(Long.parseLong(ref)));
    return swiftMessage;
  }

  private SwiftMessage createSwiftMessage(String payload){
    SwiftMessage swiftMessage = new SwiftMessage();

    // Message content will now be stored in the TXT column instead of the XML column
    swiftMessage.setMessageContentTxt(payload);
    swiftMessage.setApplicationUserName("System");
    swiftMessage.setApplicationUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
    return swiftMessage;
  }
}
