package ca.bankofcanada.smm.service;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class JmsTemplateFactory {
  public JmsTemplate createJmsTemplate() {
    return new JmsTemplate();
  }
}