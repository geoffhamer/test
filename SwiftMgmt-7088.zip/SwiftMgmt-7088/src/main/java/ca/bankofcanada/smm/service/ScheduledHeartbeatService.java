package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.config.HeartbeatProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * Schedules a heartbeat message on a pre-defined interval to be sent to SAA.
 */
public class ScheduledHeartbeatService {

  private final SAAHeartbeatService saaHeartbeatService;
  private final HeartbeatProperties heartbeatProperties;
  private final SMMToSwiftHeartbeatBuilder heartbeatBuilder;

  @Autowired
  public ScheduledHeartbeatService(SAAHeartbeatService saaHeartbeatService,
      HeartbeatProperties heartbeatProperties, SMMToSwiftHeartbeatBuilder heartbeatBuilder) {
    this.saaHeartbeatService = saaHeartbeatService;
    this.heartbeatProperties = heartbeatProperties;
    this.heartbeatBuilder = heartbeatBuilder;
  }

  @Async
  @Scheduled(fixedRateString = "#{heartbeatProperties.getDelay()}")
  public void submitHeartbeatMessage() {
    saaHeartbeatService.submitHeartbeatMessage(heartbeatBuilder.buildSmmAdmi004Message(),
        heartbeatProperties.getDelay());
  }
}
