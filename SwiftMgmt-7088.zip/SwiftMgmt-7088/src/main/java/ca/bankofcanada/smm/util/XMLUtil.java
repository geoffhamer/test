package ca.bankofcanada.smm.util;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ComplexDataObject;
import biz.c24.io.api.presentation.XMLSink;
import java.io.StringWriter;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class XMLUtil {

  private XMLUtil() { }

  public static Optional<String> extractXMLTagText(String strXML, String tagName){
    //create a pattern object
    Pattern pattern = Pattern.compile("<"+tagName+">"+"(.*)"+"</"+tagName+">");
    //create a matcher object
    Matcher matcher = pattern.matcher(strXML);

    String tagValue = null;

    if(matcher.find()){
      tagValue = matcher.group(1);
    }

    return Optional.ofNullable(tagValue);
  }

  public static String writeObjectToOneLine(ComplexDataObject cdo) throws Exception {
    StringWriter writer = new StringWriter();
    XMLSink xmlSink = new XMLSink(writer);
    xmlSink.getFormat().setIndent(0);
    xmlSink.getFormat().setLineSeparator("");
    xmlSink.getFormat().setIndenting(false);
    xmlSink.getFormat().setOmitXMLDeclaration(true);
    xmlSink.getFormat().setOmitComments(true);
    xmlSink.getFormat().setPreserveSpace(false);
    xmlSink.getFormat().setPreserveEmptyAttributes(false);

    C24.write(cdo).to(xmlSink);
    return writer.toString();
  }
}
