package ca.bankofcanada.smm.security;

import ca.bankofcanada.common.security.apsec.ApsecException;
import ca.bankofcanada.common.security.apsec.BouncyCastleSecurityToolkit;
import ca.bankofcanada.common.security.apsec.core.ApsecCipher;
import ca.bankofcanada.common.security.apsec.xml.EntrustXmlSignatureManager;
import java.io.File;
import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class MessageSecurityService {

  private static final Logger logger = LoggerFactory.getLogger(MessageSecurityService.class);

  private static final String SIGNATURE_VALIDATION_FAILURE = "Message failed signature validation.";
  private static final String SOURCE_SWIFT_MX = "SwiftMx";

  @Value("${smm.xml.signature.parent.namespace.uri:urn:swift:saa:xsd:saa.2.0}")
  private String signatureParentNamespaceURI;

  @Value("${smm.xml.signature.parent.qualified.name:Saa:LAU}")
  private String signatureParentQualifiedName;

  @Value("${smm.trust.swift:false}")
  private boolean trustSwift;

  @Value("${smm.profile:#{null}}")
  private String smmProfile;

  @Value("${smm.profile.password:#{null}}")
  private String smmProfilePwd;

  @Value("${smm.swift.public.key.file:#{null}}")
  private String swiftPublicProfile;

  @Value("${smm.swift.keystore:#{null}}")
  private String swiftKeyStore;

  @Value("${smm.swift.keystore.password:#{null}}")
  private String swiftKeyStorePassword;

  @Value("${smm.swift.keystore.cipher:#{null}}")
  private String swiftKeyStoreCipher;

  @Value("${smm.swift.certificate:#{null}}")
  private String swiftCertificate;

  @Value("${smm.swift.certificate.revocation:#{false}}")
  private boolean swiftCertificateRevocation;

  private EntrustXmlSignatureManager signatureManager;

  private BouncyCastleSecurityToolkit bouncyCastleSecurityToolkit;

  @PostConstruct
  public void init() throws ApsecException {
    logger.debug("Initializing Entrust XML signature manager...");
    signatureManager = new EntrustXmlSignatureManager.Builder(smmProfile, smmProfilePwd)
        .swiftCertificate(swiftPublicProfile).build();

    if (StringUtils.isNotBlank(swiftKeyStore)) {
      bouncyCastleSecurityToolkit = new BouncyCastleSecurityToolkit();
      String tempSwiftKeyStorePassword = new String(
          bouncyCastleSecurityToolkit.decode(swiftKeyStorePassword));
      bouncyCastleSecurityToolkit
          .setKeyStore(SOURCE_SWIFT_MX, new File(swiftKeyStore), tempSwiftKeyStorePassword,
              ApsecCipher
                  .valueOf(swiftKeyStoreCipher), false);

      bouncyCastleSecurityToolkit
          .setValidationCertificate(SOURCE_SWIFT_MX, new File(swiftCertificate),
              swiftCertificateRevocation);
    }
  }

  public String signXMLMessage(String xmlMessage) throws ApsecException {
    logger.debug("Signing XML message...");
    if (bouncyCastleSecurityToolkit != null) {
      return bouncyCastleSecurityToolkit.getXmlSignatureManager(SOURCE_SWIFT_MX)
          .signXMLMessage(xmlMessage, signatureParentNamespaceURI,
              signatureParentQualifiedName);
    }
    return signatureManager.signXMLMessage(xmlMessage, signatureParentNamespaceURI,
        signatureParentQualifiedName);
  }

  public boolean verifyXMLMessage(String xmlMessage) {
    logger.debug("Verifying XML message...");
    if (trustSwift) {
      logger.debug("SWIFT is trusted. Skipping signature verification.");
      return true;
    }

    try {
      if (bouncyCastleSecurityToolkit != null) {
        return bouncyCastleSecurityToolkit.getXmlSignatureManager(SOURCE_SWIFT_MX)
            .verifyXMLMessage(xmlMessage);
      }
      return signatureManager.verifyXMLMessage(xmlMessage);
    } catch (ApsecException e) {
      logger.error("Exception verifying a Swift message", e);
      throw new RuntimeException(e);
    }
  }

  /**
   * This method checks the signature of messages on the SAA->HABS flow.
   *
   * @param payload The spring message payload
   * @return The original spring message payload
   * @throws Exception if there is any signature validation failures
   */
  public String saaMessageSignatureCheck(String payload) throws Exception {
    if (!verifyXMLMessage(payload)) {
      throw new ApsecException(SIGNATURE_VALIDATION_FAILURE);
    }
    return payload;
  }
}
