package ca.bankofcanada.smm.config;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

/**
 * JPA config that applies to the default Spring Profile.
 */
@Configuration
@Profile({"default"})
public class JpaDefaultConfig {

  @Value("${hibernate.show_sql:true}")
  public String showSql;

  @Bean
  public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource,
      JpaVendorAdapter jpaVendorAdapter) {
    LocalContainerEntityManagerFactoryBean lemfb = new LocalContainerEntityManagerFactoryBean();
    lemfb.setDataSource(dataSource);
    lemfb.setPersistenceXmlLocation("classpath*:persistence.xml");
    lemfb.setPersistenceUnitName("SMMPersistenceUnit");
    lemfb.setJpaVendorAdapter(jpaVendorAdapter);
    lemfb.setLoadTimeWeaver(new InstrumentationLoadTimeWeaver());

    Map<String, String> jpaProperties = Stream.of(
            new String[][]{{"hibernate.format_sql", "true"}, {"hibernate.show_sql", showSql}})
        .collect(Collectors.toMap(data -> data[0], data -> data[1]));

    lemfb.setJpaPropertyMap(jpaProperties);

    return lemfb;
  }
}
