package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.config.SaaConfig.VALID_INCOMING_MESSAGE_TYPES;

import java.util.Arrays;
import java.util.List;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.xml.DefaultXmlPayloadConverter;
import org.springframework.integration.xml.XmlPayloadConverter;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.xml.xpath.XPathExpression;
import org.springframework.xml.xpath.XPathExpressionFactory;
import org.w3c.dom.Node;

@Component("messageTypeDetectionServiceActivator")
public class MessageTypeDetectionServiceActivator extends SMMBaseServiceActivator {

  private final static XmlPayloadConverter xmlPayloadConverter = new DefaultXmlPayloadConverter();

  private static final String NETWORK_NACKED_TYPE = "NetworkNacked";

  private static final List<String> ADDITIONAL_NACKED_TYPES = Arrays.asList( "NetworkRejectedLocally",
                                                                             "NetworkAborted",
                                                                             "NetworkTimedOut",
                                                                             "NetworkWaitingAck");


  /**
   * A spring integration service activator that determines:
   *
   * Message Type - A value used in populating the SmmMessage header
   * Unknown Message Type - If the found type isn't included in the list of valid types
   *
   * The message type value is stored in the jms headers of the incoming message
   *
   * @param message The incoming message
   * @return A message with headers populated.
   */
  public Message<?> detectMessageType(Message<?> message) {

    String messageType = SMM_MESSAGE_TYPE_UNKNOWN;

    Node documentNode = xmlPayloadConverter.convertToDocument(message.getPayload().toString());

    String determinedType = this.determineMessageType(documentNode);

    if (determinedType != null &&
        !determinedType.isEmpty() &&
        VALID_INCOMING_MESSAGE_TYPES.contains(determinedType) ) {

      messageType = determinedType;
    }

    return MessageBuilder.fromMessage(message).setHeader(MESSAGE_TYPE_HEADER_KEY,
        messageType).build();
  }

  /**
   * Determine the message type based on either the MessageIdentifier or NetworkDeliveryStatus
   * elements.
   *
   * If the message type is identified from the Network Delivery Status there are four values
   * (defined in the ADDITIONAL_NACKED_TYPES variable) that are converted to NetworkNacked.
   *
   * @param documentNode The incoming message
   * @return The determined message type
   */
  private String determineMessageType(Node documentNode) {

    String messageType;

    String messageIdentXPath = "/*[local-name()='DataPDU']/*[local-name()='Header']/*[local-name()='Message']/*[local-name()='MessageIdentifier']";
    String netDelivStatXPath = "/*[local-name()='DataPDU']/*[local-name()='Header']/*[local-name()='TransmissionReport']/*[local-name()='NetworkDeliveryStatus']";

    XPathExpression messageIdentExp = XPathExpressionFactory.createXPathExpression(messageIdentXPath);
    String messageIdent = messageIdentExp.evaluateAsString(documentNode);

    if (messageIdent != null && !messageIdent.isEmpty()) {
      messageType = messageIdent;
    } else {

      XPathExpression netDelivStatExp = XPathExpressionFactory.createXPathExpression(netDelivStatXPath);
      messageType = netDelivStatExp.evaluateAsString(documentNode);

      // If the message type is in the list of addition NACKED types, convert the type to 'NetworkNacked'
      if ( ADDITIONAL_NACKED_TYPES.contains(messageType) ) {
        messageType = NETWORK_NACKED_TYPE;
      }

    }

    return messageType;
  }
}