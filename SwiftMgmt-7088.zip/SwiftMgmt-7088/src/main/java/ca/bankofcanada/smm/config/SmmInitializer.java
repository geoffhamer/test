package ca.bankofcanada.smm.config;

import static biz.c24.io.api.Utils.SYSTEM_PROPERTY_ISO3166_COUNTRY_CODE_FILE;
import static biz.c24.io.api.Utils.SYSTEM_PROPERTY_ISO4217_CURRENCY_CODE_FILE;
import static biz.c24.io.api.Utils.SYSTEM_PROPERTY_ISO8601_TIME_ZONE_PRESENT;
import static biz.c24.io.api.Utils.SYSTEM_PROPERTY_ISO8601_TIME_ZONE_ZERO;

import biz.c24.io.api.data.ComplexDataType;
import biz.c24.io.spring.source.XmlSourceFactory;
import ca.bankofcanada.smm.common.CommonConstants;
import javax.annotation.PostConstruct;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * By default, it looks for file config/smm/smm.properties. Copy the file from
 * config/weblogic/smm_commons to config/smm folder under your WebLogic domain.
 * Set the System property smm.property.file to indicate a different property file name.
 */
@Configuration
@EnableAspectJAutoProxy
@EnableTransactionManagement
@PropertySource(value = "file:${smm.property.file:config/smm/smm.properties}", ignoreResourceNotFound = true)
public class SmmInitializer {
  private static final Logger logger = LoggerFactory.getLogger(SmmInitializer.class);

  private static final String REVISION = "Revision";

  private static final String NOT_AVAILABLE = "N/A";


  @Value("${smm.c24.country.file:N/A}")
  private String c24CountryFile;
  @Value("${smm.c24.currency.file:N/A}")
  private String c24CurrencyFile;

  @Value("${smm.c24.timezone.present:true}")
  private String c24TimezonePresent;
  @Value("${smm.c24.timezone.zero:true}")
  private String c24TimezoneZero;

  @Value("${smm.log4j.configuration.path:N/A}")
  private String log4jConfiguration;

  @Value("${smm.environment:N/A}")
  private String smmEnvironment;

  @Value("${smm.heartbeat.enable:false}")
  private String heartbeatEnable;
  @Value("${smm.heartbeat.delay:N/A}")
  private String heartbeatDelay;
  @Value("${smm.heartbeat.bic:N/A}")
  private String heartbeatBic;

  @PostConstruct
  private void init() {
    logger.debug("smm.environment: {}", smmEnvironment);
    logger.debug("smm.c24.country.file: {}",  c24CountryFile);
    logger.debug("smm.c24.currency.file: {}", c24CurrencyFile);
    logger.debug("smm.c24.timezone.present: {}", c24TimezonePresent);
    logger.debug("smm.c24.timezone.zero: {}", c24TimezoneZero);


    if (!NOT_AVAILABLE.equals(c24CountryFile) && c24CountryFile.length()>0) {
      System.setProperty(SYSTEM_PROPERTY_ISO3166_COUNTRY_CODE_FILE, c24CountryFile);
    }
    if (!NOT_AVAILABLE.equals(c24CurrencyFile) && c24CurrencyFile.length()>0) {
      System.setProperty(SYSTEM_PROPERTY_ISO4217_CURRENCY_CODE_FILE, c24CurrencyFile);
    }

    //load log4j configuration from the external path. It can add/modify built-in log4j configurations.
    if(!NOT_AVAILABLE.equals(log4jConfiguration)){
      PropertyConfigurator.configure(log4jConfiguration);
    }

    // Timezone parameters. These will default to 'true' if not present in properties file
    System.setProperty(SYSTEM_PROPERTY_ISO8601_TIME_ZONE_PRESENT, c24TimezonePresent);
    System.setProperty(SYSTEM_PROPERTY_ISO8601_TIME_ZONE_ZERO, c24TimezoneZero);

    // Turn off revision validation by setting the fixed value to 'null'
    ((ComplexDataType)swift.saa.xsd.saa.x2.x0.DataPDUDataType.getInstance()).getElementDecl(REVISION).setFixedValue(null);

    // SMM Environment
    if (!NOT_AVAILABLE.equals(smmEnvironment)) {
      System.setProperty(CommonConstants.SYSTEM_PROPERTY_ENVIRONMENT, smmEnvironment);
    }

    // Heartbeat Properties.
    System.setProperty("smm.heartbeat.enable", heartbeatEnable);
    if (!NOT_AVAILABLE.equals(heartbeatDelay)) {
      System.setProperty("smm.heartbeat.delay", heartbeatDelay);
    }
    if (!NOT_AVAILABLE.equals(heartbeatBic)) {
      System.setProperty("smm.heartbeat.bic", heartbeatBic);
    }
  }

  @Bean
  public XmlSourceFactory xmlSourceFactory() {

    XmlSourceFactory xmlSourceFactory = new XmlSourceFactory();
    xmlSourceFactory.setUnknownComponentsAllowed(true);
    xmlSourceFactory.setStrictNamespaces(true);
    xmlSourceFactory.setSwiftMxUsageAware(true);

    return xmlSourceFactory;
  }

}
