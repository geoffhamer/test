package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.common.CommonConstants;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import javax.jms.ConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import java.util.Map;

/**
 * Use to facilitate testing and send messages to the different jms queue
 */
@Service
public class JmsQueueService {
  private static final Logger logger = LoggerFactory.getLogger(JmsQueueService.class);

  private final ConnectionFactory smmJmsDSConnFactory;

  private final JmsTemplateFactory jmsTemplateFactory;

  @Autowired
  public JmsQueueService(
      @Value("#{smmJmsDSConnFactory}") ConnectionFactory smmJmsDSConnFactory,
      JmsTemplateFactory jmsTemplateFactory
      ) {
    this.smmJmsDSConnFactory = smmJmsDSConnFactory;
    this.jmsTemplateFactory = jmsTemplateFactory;
  }

  public void sendMessage(String queue, String message, Map<String, Object> messageProperties) {
    Assert.notNull(queue, "Queue is not specified");
    Assert.isTrue(message != null && message.length() > 0, "Message is null");

    String corrId = "UPL:" + new java.util.Date();

    logger.debug("Trying to send the following message "
        + "with correlation ID: " + corrId + " to queue " + queue);

    JmsTemplate jmsTemplate = jmsTemplateFactory.createJmsTemplate();
    jmsTemplate.setConnectionFactory(smmJmsDSConnFactory);
    jmsTemplate.convertAndSend(queue, message, new MessagePostProcessor() {
      public Message postProcessMessage(Message message) throws JMSException {
        message.setJMSCorrelationID(corrId);
        if (messageProperties != null) {
          for (String prop : messageProperties.keySet()) {
            message.setStringProperty(prop, messageProperties.get(prop).toString());
          }
        }
        return message;
      }
    });
    logger.debug("Message sent with correlation ID:" + corrId);
  }

  @Profile({CommonConstants.PROFILE_DEV, CommonConstants.PROFILE_QA})
  public List<TextMessage> listMessagesOnQueue(String queue) {
    JmsTemplate jmsTemplate = jmsTemplateFactory.createJmsTemplate();
    jmsTemplate.setConnectionFactory(smmJmsDSConnFactory);
    List<TextMessage> messages = jmsTemplate.browse(queue, (session, browser) -> {
      Enumeration<?> browserEnumeration = browser.getEnumeration();
      List<TextMessage> messageList = new ArrayList<>();
      while (browserEnumeration.hasMoreElements()) {
        messageList.add((TextMessage) browserEnumeration.nextElement());
      }
      return messageList;
    });
    return messages;
  }

  @Profile({CommonConstants.PROFILE_DEV, CommonConstants.PROFILE_QA})
  public int deleteAllMessages(String queue) {
    JmsTemplate jmsTemplate = jmsTemplateFactory.createJmsTemplate();
    jmsTemplate.setConnectionFactory(smmJmsDSConnFactory);
    jmsTemplate.setDefaultDestinationName(queue);
    jmsTemplate.setReceiveTimeout(1000);
    int messageCounter = 0;
    while (jmsTemplate.receive(queue) != null) {
      logger.debug("One more message dequeued");
      messageCounter++;
    }
    return messageCounter;
  }
}
