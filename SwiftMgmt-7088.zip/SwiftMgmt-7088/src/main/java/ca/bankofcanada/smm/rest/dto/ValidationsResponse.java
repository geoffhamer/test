package ca.bankofcanada.smm.rest.dto;

public class ValidationsResponse extends SMMResponse {

}
