package ca.bankofcanada.smm.config;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

/**
 * JPA configuration that is applied to the "dev" profile.
 *
 * <p>Note: the QA config is bundled within this class as well as these two environments are
 * identical at this time in terms of configuration options.
 */
@Configuration
@Profile({"dev", "qa"})
public class JpaDevQAConfig {

  @Value("${hibernate.show_sql:true}")
  public String showSql;

  @Bean
  public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource,
      JpaVendorAdapter jpaVendorAdapter) {
    LocalContainerEntityManagerFactoryBean lemfb = new LocalContainerEntityManagerFactoryBean();
    lemfb.setDataSource(dataSource);
    lemfb.setPersistenceXmlLocation("classpath*:persistence.xml");
    lemfb.setPersistenceUnitName("SMMPersistenceUnit");
    lemfb.setJpaVendorAdapter(jpaVendorAdapter);
    lemfb.setLoadTimeWeaver(new InstrumentationLoadTimeWeaver());

    Map<String, String> jpaProperties = Stream.of(
            new String[][]{{"hibernate.format_sql", "true"}, {"hibernate.show_sql", showSql}, {
              "hibernate.generate_statistics", "true"}})
        .collect(Collectors.toMap(data -> data[0], data -> data[1]));

    lemfb.setJpaPropertyMap(jpaProperties);

    return lemfb;
  }
}
