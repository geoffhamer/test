package ca.bankofcanada.smm.service;

public class SMMBaseServiceActivator {

  public static final String SMM_MESSAGE_PK_HEADER_KEY = "SwiftMessagePK";
  public static final  Long PERSISTENCE_ERROR_PK = -999L;
  public static final String SMM_MESSAGE_TYPE_UNKNOWN = "UNKNOWN";

  public static final String MESSAGE_TYPE_HEADER_KEY = "incomingMessageType";

  public static final String OUTGOING_MESSAGE_TYPE_HEADER_KEY = "outgoingMessageType";

  public static final String APP_HDR_BIZ_SVC = "appHdrBizSvc";

  public static final String HEARTBEAT_SOURCE_HEADER_KEY = "heartbeatSource";

}
