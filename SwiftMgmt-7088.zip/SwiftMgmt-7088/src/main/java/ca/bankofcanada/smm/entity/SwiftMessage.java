package ca.bankofcanada.smm.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Cacheable(false)
@Table(name = "SWIFT_MESSAGE")
public class SwiftMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "SwiftMessageSeqGenerator", sequenceName = "SWIFT_MESSAGE_SEQ", allocationSize = 50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SwiftMessageSeqGenerator")
    @Column(name = "MESSAGE_PK", unique = true, nullable = false)
    private Long messagePk;

    @Column(name = "MESSAGE_TYPE")
    private String messageType;

    @Column(name = "MESSAGE_IDENTIFIER")
    private String messageIdentifier;

    @Lob
    @Column(name = "MESSAGE_CONTENT_TXT")
    private String messageContentTxt;

    @Column(name="BUSINESS_TRANSACTION_FK")
    private Long businessTransactionFk;

    @Column(name = "APPLICATION_USER_NAME")
    private String applicationUserName;

    @Column(nullable = true, name = "APPLICATION_UPDATE_TIMESTAMP")
    private Timestamp applicationUpdateTimestamp;

    @Version
    @Column(name = "OPTLOCK")
    private Long optlock;

    public SwiftMessage() {
    }

    public Long getMessagePk() {
        return this.messagePk;
    }

    public void setMessagePk(Long messagePk) {
        this.messagePk = messagePk;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMessageIdentifier() {
        return messageIdentifier;
    }

    public void setMessageIdentifier(String messageIdentifier) {
        this.messageIdentifier = messageIdentifier;
    }

    public String getMessageContentTxt() {
        return messageContentTxt;
    }

    public void setMessageContentTxt(String messageContentTxt) {
        this.messageContentTxt = messageContentTxt;
    }

    public String getApplicationUserName() {
        return this.applicationUserName;
    }

    public void setApplicationUserName(String applicationUserName) {
        this.applicationUserName = applicationUserName;
    }

    public Timestamp getApplicationUpdateTimestamp() {
        return this.applicationUpdateTimestamp;
    }

    public void setApplicationUpdateTimestamp(Timestamp applicationUpdateTimestamp) {
        this.applicationUpdateTimestamp = applicationUpdateTimestamp;
    }

    public Long getOptlock() {
        return this.optlock;
    }

    public void setOptlock(Long optlock) {
        this.optlock = optlock;
    }

    public Long getBusinessTransactionFk() {
        return businessTransactionFk;
    }

    public void setBusinessTransactionFk(Long businessTransactionFk) {
        this.businessTransactionFk = businessTransactionFk;
    }
}


