package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.common.CommonConstants.HEARTBEAT_SOURCE_HABS;
import static ca.bankofcanada.smm.common.CommonConstants.HEARTBEAT_SOURCE_SMM;
import static ca.bankofcanada.smm.common.CommonConstants.SMM_HEARTBEAT_EVT_DESC;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.HEARTBEAT_SOURCE_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.MESSAGE_TYPE_HEADER_KEY;

import ca.bankofcanada.smm.common.CommonConstants;
import ca.bankofcanada.smm.entity.Heartbeat;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.xml.DefaultXmlPayloadConverter;
import org.springframework.integration.xml.XmlPayloadConverter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.xml.xpath.XPathExpression;
import org.springframework.xml.xpath.XPathExpressionFactory;

/**
 * A service class for sending and receiving heartbeat messages to/from SAA.
 */
@Service
public class SAAHeartbeatService {

  // SWIFT_MX_OUTQ is chosen over SWIFT_SMM_OUTQ so that we send the heartbeat message through
  // the Spring Integration outgoing flow to take advantage of the error handling, logging, and
  // validation that exists.
  private static final String HEARTBEAT_QUEUE_NAME = "SWIFT_MX_OUTQ";

  private final JmsQueueService jmsQueueService;

  private final HeartbeatService heartbeatService;

  @Autowired
  public SAAHeartbeatService(JmsQueueService jmsQueueService, HeartbeatService heartbeatService) {
    this.jmsQueueService = jmsQueueService;
    this.heartbeatService = heartbeatService;
  }

  /**
   * Submits a heartbeat message to SAA at every interval on open business days
   *
   * @param message the heartbeat (admi004) message to submit.
   * @param delay   the time interval between each heartbeat submission before sending the next one,
   *                in milliseconds. This amount must be non-negative.
   */
  public void submitHeartbeatMessage(String message, long delay) {
    // Fetch the time now to prevent time desyncs due to database queries.
    LocalDateTime now = Instant.now().atZone(CommonConstants.TORONTO_ZONE_ID).toLocalDateTime();

    if (delay < 0) {
      throw new IllegalArgumentException("delay must be non-negative");
    }

    Optional<Heartbeat> smmHeartbeatOpt = heartbeatService.getHeartbeat();

    // No heartbeat has ever been sent, submit one.
    if (!smmHeartbeatOpt.isPresent()) {
      jmsQueueService.sendMessage(HEARTBEAT_QUEUE_NAME, message, null);
      createOrUpdateSmmHeartbeatRecord(null, now);
      return;
    }

    // A heartbeat has been previously ran. Check whether the configured delay has been reached
    // before sending off a heartbeat message.
    //
    // A two second buffer is added to account for time desyncs.
    Heartbeat heartbeat = smmHeartbeatOpt.get();
    Duration duration = Duration.between(heartbeat.getLastSentTimestamp().toLocalDateTime(), now)
        .plus(2, ChronoUnit.SECONDS);
    if (duration.toMillis() >= delay) {
      jmsQueueService.sendMessage(HEARTBEAT_QUEUE_NAME, message, null);
      createOrUpdateSmmHeartbeatRecord(heartbeat, now);
    }
  }

  /**
   * DIRECTLY submits a heartbeat message to SAA without any delays or any other conditions
   *
   * @param message the heartbeat (admi004) message to submit.
   */
  public void submitHeartbeatMessageUnconditionally(String message) {
    LocalDateTime now = Instant.now().atZone(CommonConstants.TORONTO_ZONE_ID).toLocalDateTime();
    jmsQueueService.sendMessage(HEARTBEAT_QUEUE_NAME, message, null);
    createOrUpdateSmmHeartbeatRecord(heartbeatService.getHeartbeat().orElse(null), now);
  }

  /**
   * Updates the existing smm_heartbeat record if one exists; otherwise, creates a new record
   *
   * @param heartbeat the heartbeat record to update if one exists
   * @param now current local time
   */
  private void createOrUpdateSmmHeartbeatRecord(Heartbeat heartbeat, LocalDateTime now) {
    if (heartbeat == null) {
      heartbeat = new Heartbeat();
      heartbeat.setHeartbeatType("SAA");
    }

    Timestamp lastSentAt = Timestamp.valueOf(now);
    heartbeat.setLastSentTimestamp(lastSentAt);
    heartbeat.setLastUpdatedTimestamp(lastSentAt);
    heartbeatService.save(heartbeat);
  }

  /**
   * Receives, and processes, a heartbeat message.
   *
   * @param message the heartbeat message to process.
   */
  @Transactional
  public void receiveHeartbeatMessage(Message<?> message) {
    String messageType = (String) message.getHeaders().get(MESSAGE_TYPE_HEADER_KEY);

    if (!MESSAGETYPE_ADMI_004.equals(messageType)) {
      throw new IllegalArgumentException("Expected an admi.004 message, but got: " + message);
    }

    Heartbeat heartbeat = heartbeatService.getHeartbeat()
        .orElseThrow(() -> new IllegalStateException(
            "Expected a record of a SMM heartbeat being sent in the database, but none exists: "
                + message));

    Long dequeuedTimeEpochMs = (Long) message.getHeaders().get("JMSXRcvTimestamp");

    // Default to current time.
    if (dequeuedTimeEpochMs == null) {
      dequeuedTimeEpochMs = Instant.now().toEpochMilli();
    }

    Timestamp lastReceivedAt = Timestamp.from(
        Instant.ofEpochMilli(dequeuedTimeEpochMs).atZone(CommonConstants.TORONTO_ZONE_ID).toInstant());
    heartbeat.setLastReceivedTimestamp(lastReceivedAt);
    heartbeat.setLastUpdatedTimestamp(lastReceivedAt);
    heartbeatService.save(heartbeat);
  }

  /**
   * For the given heartbeat message, detect the original source of the heartbeat message.
   *
   * <p>This method examines the "EvtDesc" component of an admi.004 message to infer what the
   * original source of the message was. Nothing is performed for non-admi.004 message.
   *
   * @param message the message to inspect
   * @return A modified message with the message source of the heartbeat assigned in the headers of
   * the message.
   */
  public Message<?> detectHeartbeatSource(Message<?> message) {
    MessageHeaders messageHeaders = message.getHeaders();

    Message<?> result = message;
    if (MESSAGETYPE_ADMI_004.equals(messageHeaders.get(MESSAGE_TYPE_HEADER_KEY))) {
      String heartbeatSource = HEARTBEAT_SOURCE_HABS;
      String evtDescXPathStr = "/*[local-name()='DataPDU']/*[local-name()='Body']/*[local-name()='Document']/*[local-name()='SysEvtNtfctn']/*[local-name()='EvtInf']/*[local-name()='EvtDesc']";

      XPathExpression evtDescXPath = XPathExpressionFactory.createXPathExpression(evtDescXPathStr);
      XmlPayloadConverter xmlPayloadConverter = new DefaultXmlPayloadConverter();

      String evtDesc = evtDescXPath.evaluateAsString(
          xmlPayloadConverter.convertToDocument(message.getPayload().toString()));

      if (evtDesc.toLowerCase().contains(SMM_HEARTBEAT_EVT_DESC.toLowerCase())) {
        heartbeatSource = HEARTBEAT_SOURCE_SMM;
      }

      result = MessageBuilder.fromMessage(message)
          .setHeader(HEARTBEAT_SOURCE_HEADER_KEY, heartbeatSource)
          .build();
    }
    return result;
  }
}
