package ca.bankofcanada.smm.logging;

import java.util.Arrays;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public final class RestControllerLogger {

  private static final Logger log4jLogger = Logger.getLogger(
      RestControllerLogger.class.getCanonicalName());
  private static final String LOG_HEADER = "[REST API Exception]";

  @AfterThrowing(pointcut = "@annotation(ca.bankofcanada.smm.logging.annotations.LogRestAPIException)", throwing = "exception")
  public void logResponse(JoinPoint joinPoint, Exception exception) {
    StringBuilder stringBuilder = new StringBuilder();

    // method information
    String methodInfo = LOG_HEADER + joinPoint.getSignature().toLongString();
    stringBuilder.append(methodInfo).append(" - ");

    // args
    String args = Arrays.toString(joinPoint.getArgs());
    stringBuilder.append(args).append(" - ").append(ExceptionUtils.getStackTrace(exception));

    log4jLogger.error(stringBuilder.toString());
  }
}
