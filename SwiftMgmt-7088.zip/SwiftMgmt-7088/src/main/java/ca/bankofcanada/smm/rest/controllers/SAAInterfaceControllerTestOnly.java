package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.exception.ResourceNotFoundException;
import ca.bankofcanada.smm.exception.SAAInterfaceException;
import ca.bankofcanada.smm.logging.annotations.LogRestAPIException;
import ca.bankofcanada.smm.service.SAAInterfaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;

@RestController
@RequestMapping("/for-testing-purposes-only/saa-interfaces")
@Profile({"local", "dev", "qa"})
public class SAAInterfaceControllerTestOnly {

  public static final String INTERFACE_ID  = "interfaceId";

  private final SAAInterfaceService saaInterfaceService;

  @Autowired
  public SAAInterfaceControllerTestOnly(SAAInterfaceService saaInterfaceService) {
    this.saaInterfaceService = saaInterfaceService;
  }

  /**
   * For the specified interface PK, set the Status to 'Available' and the SwitchResult to 'null'
   *
   * @param interfaceId The PK of the interface node
   * @return A status of 'Accepted' if no errors
   * @throws ResourceNotFoundException If the specified node doesn't exist
   * @throws SAAInterfaceException On all other errors
   */
  @Operation(description = "An API for QA to easily set status/result to Available/null of the given " + INTERFACE_ID ,
      parameters = {
          @Parameter(
              in = ParameterIn.PATH,
              name = INTERFACE_ID,
              required = true,
              description = INTERFACE_ID + " of the SAA interface to set to the switch result to null",
              schema = @Schema(type = "integer", format = "int64"))})
  @PutMapping(value = "/{" + INTERFACE_ID + "}/nullify-switch-results")
  @LogRestAPIException
  public ResponseEntity<?> nullifySwitchResult(@NotEmpty @PathVariable(name = INTERFACE_ID) Long interfaceId)
      throws ResourceNotFoundException, SAAInterfaceException {

    saaInterfaceService.setSwitchResultToNull(interfaceId);

    return ResponseEntity.status(HttpStatus.ACCEPTED).build();
  }

  /**
   * For each interface node, set the Status to 'Available' and the SwitchResult to 'null'
   *
   * NOTE: This API could have been done more easily with a GET mapping but POST was used as
   * it is performing the same task as the 'nullifySwitchResult(id)' but on all interfaces. This
   * doesn't follow proper REST naming, but it's not deployed to PROD.
   *
   * @throws SAAInterfaceException On all errors
   */
  @Operation(description = "An API for QA to easily set status/result to Available/null for all interface nodes")
  @PutMapping(value = "/nullify-switch-results")
  @LogRestAPIException
  public ResponseEntity<?> nullifySwitchResult()
      throws ResourceNotFoundException, SAAInterfaceException {

    saaInterfaceService.setAllSwitchResultToNull();

    return ResponseEntity.status(HttpStatus.ACCEPTED).build();
  }

}
