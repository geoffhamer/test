package ca.bankofcanada.smm.exception;

public class SAADataPDUException extends RuntimeException {

  public SAADataPDUException(String message) {
    super(message);
  }

}
