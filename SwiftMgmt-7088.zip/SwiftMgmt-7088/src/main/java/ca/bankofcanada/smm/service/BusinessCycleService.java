package ca.bankofcanada.smm.service;

import ca.bankofcanada.smm.entity.BusinessCycle;
import ca.bankofcanada.smm.repositories.BusinessCycleRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BusinessCycleService {

  private final BusinessCycleRepository repository;

  @Autowired
  public BusinessCycleService(BusinessCycleRepository repository) {
    this.repository = repository;
  }

  public Optional<BusinessCycle> getOpenBusinessCycle() {
    return repository.getOpenBusinessCycle();
  }

}
