package ca.bankofcanada.smm.service;

public interface  SAAInterfaceConstants {
  String REPO_CATEGORY_INTERFACENODESTATUS = "INTERFACENODESTATUS";
  String REPO_TYPE_SWIFT = "Swift";

  /* Statuses in Repository */
  String REPO_STATUS_ACTIVE = "Active";
  String REPO_STATUS_INACTIVE = "Inactive";
  String REPO_STATUS_INPROGRESS = "InProgress";

  /* Switch Result */
  String SWITCH_RESULT_SUCCESS = "Switch Success";

  /* Statuses in API */
  String API_STATUS_ACTIVE = "ACTIVE";
  String API_STATUS_AVAILABLE = "AVAILABLE";
  String API_STATUS_ACTIVATION_REQUESTED = "ACTIVATION_REQUESTED";
  String API_STATUS_UNKNOWN = "UNKNOWN";

}
