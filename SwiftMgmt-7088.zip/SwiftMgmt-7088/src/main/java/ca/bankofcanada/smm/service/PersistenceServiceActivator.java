package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;

import ca.bankofcanada.smm.entity.SwiftMessage;
import ca.bankofcanada.smm.msg.SwiftMessageFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

@Component("persistenceServiceActivator")
public class PersistenceServiceActivator extends SMMBaseServiceActivator {

  @Autowired
  public SwiftMessagePersistService swiftMessagePersistService;

  @Autowired
  private SwiftMessageFactory messageFactory;

  public Message<?> saveMessage(Message<?> message) {
    String messageBody = message.getPayload().toString();
    SwiftMessage sm = messageFactory.createIncomingMessage(messageBody);

    // Do not persist admi.004.001.02 heartbeat messages sent every 5 minutes
    if (!MESSAGETYPE_ADMI_004.equals(message.getHeaders().get(MESSAGE_TYPE_HEADER_KEY))) {
      sm = swiftMessagePersistService.saveSwiftMessage(sm);
    }

    // Put SwiftMessage PK on the JMS headers.
    MessageBuilder<?> outMessageBuilder = MessageBuilder.fromMessage(message);
    outMessageBuilder.setHeader(SMM_MESSAGE_PK_HEADER_KEY, sm.getMessagePk());

    return outMessageBuilder.build();
  }

}
