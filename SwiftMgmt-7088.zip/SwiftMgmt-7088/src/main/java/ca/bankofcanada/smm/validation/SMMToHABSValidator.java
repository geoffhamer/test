package ca.bankofcanada.smm.validation;

import static ca.bankofcanada.smm.config.SaaConfig.SWIFT_CBPRPLUS_02;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.APP_HDR_BIZ_SVC;

import biz.c24.io.api.C24;
import biz.c24.io.api.data.ValidationEvent;
import biz.c24.io.api.presentation.Source;
import biz.c24.io.spring.source.XmlSourceFactory;
import ca.bankofcanada.smm.exception.C24ValidationException;
import java.io.StringReader;
import org.springframework.lang.Nullable;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

/**
 * <p>
 *   This class validates messages on flow SAA->HABS.
 *   It depends on SwiftCBPRValidationModelDocumentRoot model to do the validation.
 *
 * </p>
 */
@Component
public class SMMToHABSValidator {

  private final XmlSourceFactory xmlSourceFactory;

  public SMMToHABSValidator(XmlSourceFactory xmlSourceFactory) {
    this.xmlSourceFactory = xmlSourceFactory;
  }

  /**
   * This method validates cbpr pacs messages, collects failed validation events and wraps it up
   * with a customized C24ValidationException.
   *
   * @param payload The SAA->HABS spring message payload
   * @return The original spring message payload
   * @throws Exception if there is any validation failures
   */
  public String validateMessage(String payload, @Header(APP_HDR_BIZ_SVC) @Nullable String appHdrBizSvc) throws Exception {
    // BizSvc other than CBPR+ will bypass structural check and C24 validation
    if (appHdrBizSvc == null || !appHdrBizSvc.startsWith(SWIFT_CBPRPLUS_02.substring(0,14))) {
      return payload;
    }

    Source source = xmlSourceFactory.getSource(new StringReader(payload));
    SwiftCBPRValidationModelDocumentRoot cdo = C24.parse(
        SwiftCBPRValidationModelDocumentRoot.class).from(source);

    ValidationEvent[] validationEvents = C24.validateFully(cdo.getDataPDU());
    if (validationEvents != null) {
      throw new C24ValidationException("C24 validation failed!", validationEvents);
    }

    return payload;
  }

}
