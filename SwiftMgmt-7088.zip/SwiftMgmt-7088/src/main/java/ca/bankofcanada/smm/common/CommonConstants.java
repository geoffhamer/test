package ca.bankofcanada.smm.common;

import java.time.ZoneId;

public final class CommonConstants {

  private CommonConstants() {
    throw new IllegalStateException("Utility class should not be instantiated.");
  }

  public static final String PROFILE_DEV  = "dev";
  public static final String PROFILE_QA  = "qa";
  public static final String SYSTEM_PROPERTY_ENVIRONMENT = "smm.environment";

  public static final ZoneId TORONTO_ZONE_ID = ZoneId.of("America/Toronto");

  /* Error messages */
  public static final String HEARTBEAT_SOURCE_SMM = "SMM";

  public static final String HEARTBEAT_SOURCE_HABS = "HABS";

  public static final String HEARTBEAT_TYPE_DEFAULT = "SAA";

  public static final String SMM_HEARTBEAT_EVT_DESC = "SMM Heartbeat message";
}
