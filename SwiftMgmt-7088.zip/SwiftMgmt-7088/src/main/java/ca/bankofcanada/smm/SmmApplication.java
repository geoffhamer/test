package ca.bankofcanada.smm;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.WebApplicationInitializer;

@SpringBootApplication
@ImportResource("classpath*:META-INF/spring/applicationContext.xml")
/**
 * Standard Spring Boot application would have a main method
 * <pre>public static void main(String[])</pre>
 * Unfortunately at this point in time, we need to run on WebLogic and aren't setup to run
 * as a standalone application. More work will be required to do so.
 */
public class SmmApplication  extends SpringBootServletInitializer implements
    WebApplicationInitializer {

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(SmmApplication.class);
  }
}
