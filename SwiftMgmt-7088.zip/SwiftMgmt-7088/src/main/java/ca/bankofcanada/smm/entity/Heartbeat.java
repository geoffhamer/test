package ca.bankofcanada.smm.entity;

import static ca.bankofcanada.smm.common.CommonConstants.HEARTBEAT_TYPE_DEFAULT;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "HEARTBEAT", schema = "SMM")
@SequenceGenerator(name = "HEARTBEAT_SEQ_GEN", sequenceName = "HEARTBEAT_SEQ")
public class Heartbeat implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(generator = "HEARTBEAT_SEQ_GEN", strategy = GenerationType.SEQUENCE)
  @Column(name = "HEARTBEAT_PK", nullable = false, precision = 5, columnDefinition = "NUMERIC(5, 0)")
  private Integer pk;

  @Column(name = "HEARTBEAT_TYPE", nullable = false, length = 8, unique = true)
  private String heartbeatType = HEARTBEAT_TYPE_DEFAULT;

  @Column(name = "LAST_SENT_TIMESTAMP", nullable = false)
  private Timestamp lastSentTimestamp;

  @Column(name = "LAST_RECEIVED_TIMESTAMP")
  private Timestamp lastReceivedTimestamp;

  @Column(name = "LAST_UPDATED_TIMESTAMP", nullable = false)
  private Timestamp lastUpdatedTimestamp;

  public Integer getPk() {
    return pk;
  }

  public void setPk(Integer pk) {
    this.pk = pk;
  }

  public String getHeartbeatType() {
    return heartbeatType;
  }

  public void setHeartbeatType(String heartbeatType) {
    this.heartbeatType = heartbeatType;
  }

  public Timestamp getLastSentTimestamp() {
    return lastSentTimestamp;
  }

  public void setLastSentTimestamp(Timestamp lastSentTimestamp) {
    this.lastSentTimestamp = lastSentTimestamp;
  }

  public Timestamp getLastReceivedTimestamp() {
    return lastReceivedTimestamp;
  }

  public void setLastReceivedTimestamp(Timestamp lastReceivedTimestamp) {
    this.lastReceivedTimestamp = lastReceivedTimestamp;
  }

  public Timestamp getLastUpdatedTimestamp() {
    return lastUpdatedTimestamp;
  }

  public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
    this.lastUpdatedTimestamp = lastUpdatedTimestamp;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Heartbeat that = (Heartbeat) o;
    return pk == that.pk;
  }

  @Override
  public int hashCode() {
    return Objects.hash(pk);
  }
}