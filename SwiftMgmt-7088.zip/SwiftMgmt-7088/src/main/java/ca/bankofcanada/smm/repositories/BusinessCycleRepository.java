package ca.bankofcanada.smm.repositories;

import ca.bankofcanada.smm.entity.BusinessCycle;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface BusinessCycleRepository extends JpaRepository<BusinessCycle, Long> {

  /**
   * Fetch the active business cycle.
   *
   * <p>Note: this implementation matches how HABS resolves the open business cycle.
   * @return the resulting {@link BusinessCycle} record.
   */
  @Query(value = "SELECT * FROM BUSINESS_CYCLE bc"
      + " JOIN INSTRUCTION i ON bc.INSTRUCTION_FK = i.INSTRUCTION_PK"
      + "  WHERE i.INSTRUCTION_STATUS_FK = ("
      + "    SELECT CODE_PK FROM CODE_TABLE ct"
      + "    JOIN CODE_CATEGORY_TABLE cct ON ct.CODE_CATEGORY_FK = cct.CODE_CATEGORY_PK"
      + "    WHERE cct.ATTRIBUTE_EN_NAME = 'INSTRSTATUS'"
      + "      AND ct.CODE_CONSTANT_ID = 'Inprog'"
      + "  )"
      + "  AND i.INSTRUCTION_SERVICE_FK = ("
      + "    SELECT CODE_PK FROM CODE_TABLE ct"
      + "    JOIN CODE_CATEGORY_TABLE cct ON ct.CODE_CATEGORY_FK = cct.CODE_CATEGORY_PK"
      + "    WHERE cct.ATTRIBUTE_EN_NAME = 'INSTRSERVE'"
      + "      AND ct.CODE_CONSTANT_ID = 'BusinessCycle'"
      + "  )"
      + "  AND bc.CYCLE_STATUS_FK = ("
      + "    SELECT code_pk FROM code_table ct"
      + "    JOIN CODE_CATEGORY_TABLE cct ON ct.CODE_CATEGORY_FK = cct.CODE_CATEGORY_PK"
      + "    WHERE cct.ATTRIBUTE_EN_NAME = 'CYCLESTAT'"
      + "      and ct.CODE_CONSTANT_ID = 'Operational'"
      + "  )"
      + "  AND i.INSTRUCTION_SERVICE_NAME = 'Root Instruction'", nativeQuery = true)
  Optional<BusinessCycle> getOpenBusinessCycle();

}
