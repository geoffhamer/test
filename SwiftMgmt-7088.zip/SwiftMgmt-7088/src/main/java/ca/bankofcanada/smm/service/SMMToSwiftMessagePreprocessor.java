package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.OUTGOING_MESSAGE_TYPE_HEADER_KEY;
import static ca.bankofcanada.smm.service.SMMBaseServiceActivator.SMM_MESSAGE_PK_HEADER_KEY;

import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.xml.DefaultXmlPayloadConverter;
import org.springframework.integration.xml.XmlPayloadConverter;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.xml.xpath.XPathExpression;
import org.springframework.xml.xpath.XPathExpressionFactory;
import org.w3c.dom.Node;


@Component("outMessagePreprocessor")
public class SMMToSwiftMessagePreprocessor {

  private final static XmlPayloadConverter xmlPayloadConverter = new DefaultXmlPayloadConverter();

  public Message<?> extractMessageKeyAndType(Message<?> inMsg){
    MessageBuilder<?> messageBuilder = MessageBuilder.fromMessage(inMsg);

    Node documentNode = xmlPayloadConverter.convertToDocument(inMsg.getPayload().toString());
    String messageKeyXPath = "/*[local-name()='Message']/*[local-name()='Header']/*[local-name()='MessageKey']";
    String messageTypeXPath = "/*[local-name()='Message']/*[local-name()='Header']/*[local-name()='MessageType']";

    XPathExpression messageKeyExp = XPathExpressionFactory.createXPathExpression(messageKeyXPath);
    XPathExpression messageTypeExp = XPathExpressionFactory.createXPathExpression(messageTypeXPath);

    String messageKey = messageKeyExp.evaluateAsString(documentNode);
    String messageType = messageTypeExp.evaluateAsString(documentNode);

    messageBuilder.setHeader(SMM_MESSAGE_PK_HEADER_KEY, messageKey);
    messageBuilder.setHeader(OUTGOING_MESSAGE_TYPE_HEADER_KEY, messageType);

    return messageBuilder.build();
  }

}
