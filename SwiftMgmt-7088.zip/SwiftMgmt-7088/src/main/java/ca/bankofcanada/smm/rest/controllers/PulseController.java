package ca.bankofcanada.smm.rest.controllers;

import ca.bankofcanada.smm.logging.SysLogNGLog;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pulse")
public class PulseController {

  @GetMapping
  @ResponseStatus(HttpStatus.OK)
  @Operation(
      summary = "Triggers a SysLogNG notification - USE WITH CARE!!!",
      description = "Triggers a SysLogNG notification.")
  public String pulse() {
    //This is temporary so log entries can be created in QA to test syslog ng
    SysLogNGLog.triggerNotificationWithResourceKey("1234", "rest.message.pulsecheck");
    return "Hello from SMM!";
  }

}
