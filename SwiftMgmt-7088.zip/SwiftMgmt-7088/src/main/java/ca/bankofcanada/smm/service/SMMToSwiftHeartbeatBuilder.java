package ca.bankofcanada.smm.service;

import static ca.bankofcanada.smm.common.CommonConstants.SMM_HEARTBEAT_EVT_DESC;
import static ca.bankofcanada.smm.config.SaaConfig.MESSAGETYPE_ADMI_004;

import ca.bankofcanada.smm.config.HeartbeatProperties;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class builds a heartbeat message (Admi004)
 *
 */
@Component
public class SMMToSwiftHeartbeatBuilder {
  private final HeartbeatProperties heartbeatProperties;

  @Autowired
  public SMMToSwiftHeartbeatBuilder(HeartbeatProperties heartbeatProperties) {
    this.heartbeatProperties = heartbeatProperties;
  }

  /**
   * creates an SMM heartbeat message (Admi004)
   *
   * @return a string representation of an XML document containing the SMM heartbeat message
   */
  public String buildSmmAdmi004Message() {
    DateTimeFormatter formatter = DateTimeFormatter
        .ofPattern("yyyy-MM-dd'T'hh:mm:ssxxx")
        .withZone(ZoneOffset.UTC);

    String creationTimestamp = formatter.format(Instant.now());

    String messageIdentifier = "HBT" + Instant.now().toEpochMilli();

    // TODO HPL-6755: replace this with building the message from the Admi004 data model class.
    return "<?xml version='1.0' encoding='UTF-8'?>\n"
        + "<Message xmlns='http://smm.bankofcanada.ca/model'>\n"
        + "  <Header>\n"
        + "    <CreationDate>" + creationTimestamp + "</CreationDate>\n"
        + "    <MessageKey>-999</MessageKey>\n"  // Unused by admi004 messages, placeholder placed.
        + "    <MessageType>" + MESSAGETYPE_ADMI_004 + "</MessageType>\n"
        + "  </Header>\n"
        + "  <Body>\n"
        + "    <AppHdr xmlns='urn:iso:std:iso:20022:tech:xsd:head.001.001.01'>\n"
        + "      <Fr>\n"
        + "        <FIId>\n"
        + "          <FinInstnId>\n"
        + "            <BICFI>" + heartbeatProperties.getBic() + "</BICFI>\n"
        + "          </FinInstnId>\n"
        + "        </FIId>\n"
        + "      </Fr>\n"
        + "      <To>\n"
        + "        <FIId>\n"
        + "          <FinInstnId>\n"
        + "            <BICFI>" + heartbeatProperties.getBic() + "</BICFI>\n"
        + "          </FinInstnId>\n"
        + "        </FIId>\n"
        + "      </To>"
        + "      <BizMsgIdr>" + messageIdentifier + "</BizMsgIdr>\n"
        + "      <MsgDefIdr>" + MESSAGETYPE_ADMI_004 + "</MsgDefIdr>\n"
        + "      <CreDt>" + creationTimestamp + "</CreDt>\n"
        + "    </AppHdr>\n"
        + "    <Document xmlns='urn:iso:std:iso:20022:tech:xsd:admi.004.001.02' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>\n"
        + "      <SysEvtNtfctn>\n"
        + "        <EvtInf>\n"
        + "          <EvtCd>FREE</EvtCd>\n"
        + "          <EvtDesc>" + SMM_HEARTBEAT_EVT_DESC + "</EvtDesc>\n"
        + "          <EvtTm>" + creationTimestamp + "</EvtTm>\n"
        + "        </EvtInf>\n"
        + "      </SysEvtNtfctn>\n"
        + "    </Document>\n"
        + "  </Body>\n"
        + "</Message>";
  }
}
