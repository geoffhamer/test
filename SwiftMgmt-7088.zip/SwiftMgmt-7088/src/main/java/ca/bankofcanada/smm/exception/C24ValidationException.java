package ca.bankofcanada.smm.exception;

import biz.c24.io.api.data.ValidationEvent;
import java.util.Arrays;
import java.util.List;

public class C24ValidationException extends Exception {

  private final List<ValidationEvent> validationEventList;

  public C24ValidationException(String message, ValidationEvent[] validationEvents){
    super(message);
    this.validationEventList = Arrays.asList(validationEvents);
  }

  public List<ValidationEvent> getValidationEventList() {
    return validationEventList;
  }
}
