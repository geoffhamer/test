/* 
 * This script is to create all SMM tables
 */

-- (This script has been tested in both SQL Server and H2)

/* 
 * TABLE: SMM.BANK_SITE 
 */

CREATE TABLE SMM.BANK_SITE(
                              BANK_SITE_PK              numeric(5, 0)    NOT NULL,
                              BANK_SITE_BID             varchar(80)      NOT NULL,
                              ACTIVE_IND                numeric(1, 0)    DEFAULT 1 NOT NULL,
                              LAST_UPDATED_TIMESTAMP    datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                              CONSTRAINT BANK_SITE_PK PRIMARY KEY (BANK_SITE_PK)
)
;

/* 
 * TABLE: SMM.BANK_SITE_LNG 
 */

CREATE TABLE SMM.BANK_SITE_LNG(
                                  BANK_SITE_LNG_PK          numeric(5, 0)    NOT NULL,
                                  BANK_SITE_FK              numeric(5, 0)    NOT NULL,
                                  LOCALE_ID                 varchar(80)      NOT NULL,
                                  NAME                      varchar(80)      NOT NULL,
                                  DESCRIPTION               varchar(255)     NOT NULL,
                                  LAST_UPDATED_TIMESTAMP    datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                  CONSTRAINT BANK_SITE_LNG_PK PRIMARY KEY (BANK_SITE_LNG_PK),
                                  CONSTRAINT BANK_SITE_LNG_FK_BANK_SITE FOREIGN KEY (BANK_SITE_FK)
                                      REFERENCES SMM.BANK_SITE(BANK_SITE_PK)
)
;

/* 
 * TABLE: SMM.HEARTBEAT 
 */

CREATE TABLE SMM.HEARTBEAT(
                              HEARTBEAT_PK               numeric(5, 0)    NOT NULL,
                              HEARTBEAT_TYPE             varchar(8)       DEFAULT 'SAA' NOT NULL,
                              LAST_SENT_TIMESTAMP        datetime         NOT NULL,
                              LAST_RECEIVED_TIMESTAMP    datetime         NULL,
                              LAST_UPDATED_TIMESTAMP     datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                              CONSTRAINT HEARTBEAT_PK PRIMARY KEY (HEARTBEAT_PK)
)
;

/* 
 * TABLE: SMM.INTERFACE_NODE 
 */

CREATE TABLE SMM.INTERFACE_NODE(
                                   INTERFACE_NODE_PK         numeric(5, 0)    NOT NULL,
                                   INTERFACE_NODE_BID        varchar(80)      NOT NULL,
                                   ACTIVE_IND                numeric(1, 0)    DEFAULT 1 NOT NULL,
                                   LAST_UPDATED_TIMESTAMP    datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                   CONSTRAINT INTERFACE_NODE_PK PRIMARY KEY (INTERFACE_NODE_PK)
)
;

/* 
 * TABLE: SMM.INTERFACE_NODE_LNG 
 */

CREATE TABLE SMM.INTERFACE_NODE_LNG(
                                       INTERFACE_NODE_LNG_PK     numeric(5, 0)    NOT NULL,
                                       INTERFACE_NODE_FK         numeric(5, 0)    NOT NULL,
                                       LOCALE_ID                 varchar(80)      NOT NULL,
                                       NAME                      varchar(80)      NOT NULL,
                                       DESCRIPTION               varchar(255)     NOT NULL,
                                       LAST_UPDATED_TIMESTAMP    datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                       CONSTRAINT INTERFACE_NODE_LNG_PK PRIMARY KEY (INTERFACE_NODE_LNG_PK),
                                       CONSTRAINT INTERFACE_NODE_LNG_FK_INTERFACE_NODE FOREIGN KEY (INTERFACE_NODE_FK)
                                           REFERENCES SMM.INTERFACE_NODE(INTERFACE_NODE_PK)
)
;

/* 
 * TABLE: SMM.INTERFACE_NODE_STATUS 
 */

CREATE TABLE SMM.INTERFACE_NODE_STATUS(
                                          INTERFACE_NODE_STATUS_PK     numeric(5, 0)    NOT NULL,
                                          INTERFACE_NODE_STATUS_BID    varchar(80)      NOT NULL,
                                          ACTIVE_IND                   numeric(1, 0)    DEFAULT 1 NOT NULL,
                                          LAST_UPDATED_TIMESTAMP       datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                          CONSTRAINT INTERFACE_NODE_STATUS_PK PRIMARY KEY (INTERFACE_NODE_STATUS_PK)
)
;

/* 
 * TABLE: SMM.INTERFACE_NODE_STATUS_LNG 
 */

CREATE TABLE SMM.INTERFACE_NODE_STATUS_LNG(
                                              INTERFACE_NODE_STATUS_LNG_PK    numeric(5, 0)    NOT NULL,
                                              INTERFACE_NODE_STATUS_FK        numeric(5, 0)    NOT NULL,
                                              LOCALE_ID                       varchar(80)      NOT NULL,
                                              NAME                            varchar(80)      NOT NULL,
                                              DESCRIPTION                     varchar(255)     NOT NULL,
                                              LAST_UPDATED_TIMESTAMP          datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                              CONSTRAINT INTERFACE_NODE_STATUS_LNG_PK PRIMARY KEY (INTERFACE_NODE_STATUS_LNG_PK),
                                              CONSTRAINT INTERFACE_NODE_STATUS_LNG_FK_INTERFACE_NODE_STATUS FOREIGN KEY (INTERFACE_NODE_STATUS_FK)
                                                  REFERENCES SMM.INTERFACE_NODE_STATUS(INTERFACE_NODE_STATUS_PK)
)
;

/* 
 * TABLE: SMM.MESSAGE 
 */

CREATE TABLE SMM.MESSAGE(
                            MESSAGE_PK                numeric(20, 0)    NOT NULL,
                            MESSAGE_IDENTIFIER        varchar(255)      NULL,
                            MESSAGE_CONTENT           text              NULL,
                            LAST_UPDATED_TIMESTAMP    datetime          DEFAULT CURRENT_TIMESTAMP NOT NULL,
                            CONSTRAINT MESSAGE_PK PRIMARY KEY (MESSAGE_PK)
)
;

/* 
 * TABLE: SMM.SYSTEM_INTERFACE_NODE 
 */

CREATE TABLE SMM.SYSTEM_INTERFACE_NODE(
                                          SYSTEM_INTERFACE_NODE_PK    numeric(5, 0)    NOT NULL,
                                          BANK_SITE_FK                numeric(5, 0)    NOT NULL,
                                          INTERFACE_NODE_FK           numeric(5, 0)    NOT NULL,
                                          INTERFACE_NODE_STATUS_FK    numeric(5, 0)    NOT NULL,
                                          SWITCH_SCRIPT_NAME          varchar(255)     NULL,
                                          SWITCH_RESULT               varchar(2000)    NULL,
                                          LAST_UPDATED_TIMESTAMP      datetime         DEFAULT CURRENT_TIMESTAMP NOT NULL,
                                          CONSTRAINT SYSTEM_INTERFACE_NODE_PK PRIMARY KEY (SYSTEM_INTERFACE_NODE_PK),
                                          CONSTRAINT SYSTEM_INTERFACE_NODE_FK_BANK_SITE FOREIGN KEY (BANK_SITE_FK)
                                              REFERENCES SMM.BANK_SITE(BANK_SITE_PK),
                                          CONSTRAINT SYSTEM_INTERFACE_NODE_FK_INTERFACE_NODE FOREIGN KEY (INTERFACE_NODE_FK)
                                              REFERENCES SMM.INTERFACE_NODE(INTERFACE_NODE_PK),
                                          CONSTRAINT SYSTEM_INTERFACE_NODE_FK_INTERFACE_NODE_STATUS FOREIGN KEY (INTERFACE_NODE_STATUS_FK)
                                              REFERENCES SMM.INTERFACE_NODE_STATUS(INTERFACE_NODE_STATUS_PK)
)
;


/* 
 * INDEX: HEARTBEAT_UK1 
 */

CREATE UNIQUE INDEX HEARTBEAT_UK1 ON SMM.HEARTBEAT(HEARTBEAT_TYPE)
;

/* 
 * INDEX: SYSTEM_INTERFACE_NODE_IX1 
 */

CREATE INDEX SYSTEM_INTERFACE_NODE_IX1 ON SMM.SYSTEM_INTERFACE_NODE(BANK_SITE_FK)
;

/* 
 * INDEX: SYSTEM_INTERFACE_NODE_IX2 
 */

CREATE INDEX SYSTEM_INTERFACE_NODE_IX2 ON SMM.SYSTEM_INTERFACE_NODE(INTERFACE_NODE_FK)
;

/* 
 * INDEX: SYSTEM_INTERFACE_NODE_IX3 
 */

CREATE INDEX SYSTEM_INTERFACE_NODE_IX3 ON SMM.SYSTEM_INTERFACE_NODE(INTERFACE_NODE_STATUS_FK)
;